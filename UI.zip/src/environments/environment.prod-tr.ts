import { addonEnvironment } from '@dis/settings/environments/environment.prod';

let keycloak_url = 'https://auth.localtest.me';

export const environment = {
  workOrderApiUrl: 'http://172.20.105.62:32705/api',
  routingApiUrl: 'http://172.20.105.62:32292/api',
  userApiUrl: 'http://172.20.105.62:30234/api',
  permissionApiUrl: 'http://172.20.105.62:32406/api',
  customerApiUrl: 'http://172.20.105.62:32003/api',
  productApiUrl: 'http://172.20.105.62:31137/api',
  saleOrderApiUrl: 'http://172.20.105.62:32438/api',

   locationURL: 'http://172.20.105.62:31966/api',
   shiftApiUrl: 'http://172.20.105.62:32720/api/Calendar',
   machineURL: 'http://172.20.105.62:30388/api',
   operationURL: 'http://172.20.105.62:30802/api/Operation',
   
  calendarApiUrl: 'http://172.20.105.62:32720/api/Calendar',
  settingsURL: 'http://172.20.105.62:32152/api',
  scheduleURL: 'http://172.20.105.62:30700/api',
  inventoryURL: 'http://172.20.105.62:32476/api',
  
  KEYCLOAK_URL: keycloak_url + '/auth',
  KEYCLOAK_REALM: 'demo1',
  KEYCLOAK_CLIENT: 'tr-rps-client',	//'DEMO_CLIENT',
  API_ROOT: 'http://172.20.105.61:31795/api/',  //don't change
  APP_ROOT: 'http://172.20.105.62:30376',  //frontend URL 
  APP_USER: 'app-user',   //don't change
  APP_ADMIN: 'app-admin', //don't change
  KEYCLOAK_GET_ALL_USERS_API: keycloak_url + '/auth/admin/realms/demo1/users',
  KEYCLOAK_CREATE_NEW_USER_API: keycloak_url + '/auth/admin/realms/demo1/users',
  KEYCLOAK_UPDATE_USER_API: keycloak_url + '/auth/admin/realms/demo1/users/',
  KEYCLOAK_DELETE_USER_API: keycloak_url + '/auth/admin/realms/demo1/users/',
  KEYCLOAK_GET_USER_REALM_ROLE_1: keycloak_url + '/auth/admin/realms/demo1/users/',
  KEYCLOAK_GET_USER_REALM_ROLE_2: '/role-mappings/realm',
  KEYCLOAK_GET_USER_GROUPS_1: keycloak_url + '/auth/admin/realms/demo1/users/',
  KEYCLOAK_GET_USER_GROUPS_2: '/groups',
  KEYCLOAK_GET_ALL_GROUPS: keycloak_url + '/auth/admin/realms/demo1/groups',
  KEYCLOAK_DELETE_GROUP_FOR_USER_1: keycloak_url + '/auth/admin/realms/demo1/users/',
  KEYCLOAK_DELETE_GROUP_FOR_USER_2: '/groups/',
  KEYCLOAK_ADD_GROUP_FOR_USER_1: keycloak_url + '/auth/admin/realms/demo1/users/',
  KEYCLOAK_ADD_GROUP_FOR_USER_2: '/groups/',
  KEYCLOAK_GET_REQUIRED_ACTION_URL: keycloak_url + '/auth/admin/realms/demo1/authentication/required-actions',
  KEYCLOAK_UPDATE_REQUIRED_ACTION: keycloak_url + '/auth/admin/realms/demo1/authentication/required-actions/',
  KEYCLOAK_DELETE_CREDENTIAL_FOR_USER_1: keycloak_url + '/auth/admin/realms/demo1/users/',
  KEYCLOAK_DELETE_CREDENTIAL_FOR_USER_2: '/credentials/',
  KEYCLOAK_GET_CREDENTIAL_BY_USER_1: keycloak_url + '/auth/admin/realms/demo1/users/',
  KEYCLOAK_GET_CREDENTIAL_BY_USER_2: '/credentials/',
  KEYCLOAK_GET_REALMROLES_BY_GROUPID_1: keycloak_url + '/auth/admin/realms/demo1/groups/',
  KEYCLOAK_GET_REALMROLES_BY_GROUPID_2: '/role-mappings',
  KEYCLOAK_GET_ALL_CLIENTS: keycloak_url + '/auth/admin/realms/demo1/clients',
  KEYCLOAK_GET_ALL_CLIENTS_ROLE: '/roles',
  KEYCLOAK_ROLEMAPPING_CLIENT: '/role-mappings/clients/',
  KEYCLOAK_GET_REALM_ROLES: keycloak_url + '/auth/admin/realms/demo1/roles',
  KEYCLOAK_REALM_MANAGEMENT: 'realm-management',
  DEV_TEST_USER: {},
  production: true,
  ...addonEnvironment
};