import { addonEnvironment } from '@dis/settings/environments/environment';

// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const KEYCLOAK_URL = 'http://localhost:8080/';

export const environment = {
  workOrderApiUrl: 'http://127.0.0.1:5118/api',
  routingApiUrl: 'http://127.0.0.1:5116/api',
  userApiUrl: 'http://127.0.0.1:5106/api',
  permissionApiUrl: 'http://127.0.0.1:5107/api',
  customerApiUrl: 'http://127.0.0.1:5108/api',
  productApiUrl: 'http://127.0.0.1:5110/api',
  saleOrderApiUrl: 'http://127.0.0.1:5112/api',
  locationURL: 'http://localhost:5117/api',

  calendarApiUrl: 'http://localhost:5114/api/Calendar',
  shiftApiUrl: 'http://localhost:5114/api/Calendar',
  machineURL: 'http://localhost:5113/api',
  operationURL: 'http://localhost:5115/api/Operation',
  settingsURL: 'http://localhost:5111/api',
  scheduleURL: 'http://localhost:5122/api',
  inventoryURL: 'http://localhost:5120/api',

  API_ROOT: 'http://localhost:5000',
  APP_ROOT: 'http://localhost:4200',
  APP_USER: 'app-user',
  APP_ADMIN: 'app-admin',
  KEYCLOAK_URL: KEYCLOAK_URL + 'auth',
  KEYCLOAK_REALM: 'demo1',
  KEYCLOAK_CLIENT: 'DEMO_CLIENT',
  KEYCLOAK_GET_ALL_USERS_API:
    'http://localhost:8080/auth/admin/realms/demo1/users',
  KEYCLOAK_CREATE_NEW_USER_API:
    'http://localhost:8080/auth/admin/realms/demo1/users',
  KEYCLOAK_UPDATE_USER_API:
    'http://localhost:8080/auth/admin/realms/demo1/users/',
  KEYCLOAK_DELETE_USER_API:
    'http://localhost:8080/auth/admin/realms/demo1/users/',
  KEYCLOAK_GET_USER_REALM_ROLE_1:
    'http://localhost:8080/auth/admin/realms/demo1/users/',
  KEYCLOAK_GET_USER_REALM_ROLE_2: '/role-mappings/realm',
  KEYCLOAK_GET_USER_GROUPS_1:
    'http://localhost:8080/auth/admin/realms/demo1/users/',
  KEYCLOAK_GET_USER_GROUPS_2: '/groups',
  KEYCLOAK_GET_ALL_GROUPS:
    'http://localhost:8080/auth/admin/realms/demo1/groups',
  KEYCLOAK_DELETE_GROUP_FOR_USER_1:
    'http://localhost:8080/auth/admin/realms/demo1/users/',
  KEYCLOAK_DELETE_GROUP_FOR_USER_2: '/groups/',
  KEYCLOAK_ADD_GROUP_FOR_USER_1:
    'http://localhost:8080/auth/admin/realms/demo1/users/',
  KEYCLOAK_ADD_GROUP_FOR_USER_2: '/groups/',
  KEYCLOAK_GET_REQUIRED_ACTION_URL:
    'http://localhost:8080/auth/admin/realms/demo1/authentication/required-actions',
  KEYCLOAK_UPDATE_REQUIRED_ACTION:
    'http://localhost:8080/auth/admin/realms/demo1/authentication/required-actions/',
  KEYCLOAK_DELETE_CREDENTIAL_FOR_USER_1:
    'http://localhost:8080/auth/admin/realms/demo1/users/',
  KEYCLOAK_DELETE_CREDENTIAL_FOR_USER_2: '/credentials/',
  KEYCLOAK_GET_CREDENTIAL_BY_USER_1:
    'http://localhost:8080/auth/admin/realms/demo1/users/',
  KEYCLOAK_GET_CREDENTIAL_BY_USER_2: '/credentials/',
  KEYCLOAK_GET_REALMROLES_BY_GROUPID_1:
    'http://localhost:8080/auth/admin/realms/demo1/groups/',
  KEYCLOAK_GET_REALMROLES_BY_GROUPID_2: '/role-mappings',
  KEYCLOAK_GET_ALL_CLIENTS:
    'http://localhost:8080/auth/admin/realms/demo1/clients',
  KEYCLOAK_GET_ALL_CLIENTS_ROLE: '/roles',
  KEYCLOAK_ROLEMAPPING_CLIENT: '/role-mappings/clients/',
  KEYCLOAK_GET_REALM_ROLES: 'http://localhost:8080/auth/admin/realms/demo1/roles',
  KEYCLOAK_REALM_MANAGEMENT: 'realm-management',
  DEV_TEST_USER: {
    id: 'Dev User 1',
    username: 'devuser1',
    email: 'devuser1@test.com',
    firstName: 'dev',
    lastName: 'user',
    enabled: false,
    emailVerified: true,
    totp: true
  },
  KEYCLOAK_GET_CLIENT_ROLES_1: KEYCLOAK_URL + 'auth/admin/realms/demo1/users/',
  KEYCLOAK_GET_CLIENT_ROLES_2: '/role-mappings/clients/',
  KEYCLOAK_GET_CLIENT_ROLES_3: '/composite',
  production: true,
  ...addonEnvironment,
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
