import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { Shift } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class ShiftService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<Shift[]> {
    return this.http.get<Shift[]>(
      `${environment.calendarApiUrl}/GetCalendars/?category=Shift`
    );
  }

  save(shift: any) {
    console.log('shift post');
    console.log(JSON.stringify(shift));
    return this.http.post(
      `${environment.calendarApiUrl}/AddCalendarItem`,
      shift
    );
  }

  update(params) {
    console.log('shift servie api update');
    console.log(params);
    return this.http.put(
      `${environment.calendarApiUrl}/UpdateCalendarItem`,
      params
    );
  }

  delete(id: string) {
    console.log('delete post');
    console.log(id);
    return this.http.delete(
      `${environment.calendarApiUrl}/DeleteCalendar?id=${id}`
    );
    // return this.http.delete(`${environment.mealApiUrl}/DeleteCalendar?id=${id}`);
  }
}
