import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { Calendar } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class calendarService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<Calendar[]> {
    return this.http.get<Calendar[]>(
      `${environment.calendarApiUrl}/GetCalendars/?category=Calendar`
    );
  }

  save(week: any) {
    console.log(week);
    return this.http.post(
      `${environment.calendarApiUrl}/AddCalendarItem`,
      week
    );
  }

  update(params) {
    console.log('calendar servie api update');
    console.log(params);
    return this.http.put(
      `${environment.calendarApiUrl}/UpdateCalendarItem`,
      params
    );
  }

  delete(id: any) {
    console.log('delete post');
    console.log(id);
    return this.http.delete(
      `${environment.calendarApiUrl}/DeleteCalendar?id=${id}`
    );
    // return this.http.delete(`${environment.mealApiUrl}/DeleteCalendar?id=${id}`);
  }
}
