import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { CalendarException } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class calendarExceptionService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<CalendarException[]> {
    return this.http.get<CalendarException[]>(
      `${environment.calendarApiUrl}/GetCalendars/?category=CalendarException`
    );
  }

  save(meal: any) {
    return this.http.post(
      `${environment.calendarApiUrl}/AddCalendarItem`,
      meal
    );
  }

  update(params) {
    console.log('calendar exception servie api update');
    console.log(params);
    return this.http.put(
      `${environment.calendarApiUrl}/UpdateCalendarItem`,
      params
    );
  }

  delete(id: any) {
    return this.http.delete(
      `${environment.calendarApiUrl}/DeleteCalendar?id=${id}`
    );
    // return this.http.delete(`${environment.mealApiUrl}/DeleteCalendar?id=${id}`);
  }
}
