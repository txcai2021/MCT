import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { KeycloakService } from 'keycloak-angular';
import { KeycloakApiService } from '@dis/services/keycloak-api/keycloak-api.service';


@Injectable({
  providedIn: 'root'
})
export class KeycloakUserApiService {

  clientData: any = null;
  clientSubject = new BehaviorSubject<any>(this.clientData);
  keyCloakClientData  = this.clientSubject.asObservable();

  realmRoleData: any[] = [];
  realmRoleSubject = new BehaviorSubject<any[]>(this.realmRoleData);
  keyCloakRealmRoleData  = this.realmRoleSubject.asObservable();

    constructor(private http: HttpClient,private keycloakApiService: KeycloakApiService) { }

    getAllClientRoles(clientId: String): Observable<any> {
        return this.http.get<any>(environment.KEYCLOAK_GET_ALL_CLIENTS +"/" + clientId + environment.KEYCLOAK_GET_ALL_CLIENTS_ROLE);
   }


   loadKeyCloakClientData() {
    this.getClientData()
    .subscribe(data => {
         this.clientData  =  data
         this.clientSubject.next(this.clientData)
    }); 
  }

  loadKeyCloakRealmRoleData() {
    this.getRealmRoles()
    .subscribe(data => {
         this.realmRoleData  =  data
         this.realmRoleSubject.next(this.realmRoleData)
    }); 
  }

  addClientRoleForUser(clientId: String, userId: String, clientRole: any) {
    return this.http.post<any>(environment.KEYCLOAK_GET_USER_GROUPS_1 + 
      userId + environment.KEYCLOAK_ROLEMAPPING_CLIENT + clientId, clientRole);
  }

  addRealmRoleForUser(userId: String, realmRole: any) {
    return this.http.post<any>(environment.KEYCLOAK_GET_USER_GROUPS_1 + 
      userId + environment.KEYCLOAK_GET_USER_REALM_ROLE_2 , realmRole);
  }

  getClientData(): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_ALL_CLIENTS + "?clientId=" + environment.KEYCLOAK_CLIENT);
  }

  getRealmRoles(): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_REALM_ROLES);
  }

  getClientRolesByUser(clientId: String, userId: String): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_USER_GROUPS_1 + 
      userId + environment.KEYCLOAK_ROLEMAPPING_CLIENT + clientId);
  }


  deleteClientRoleForUser(clientId: String, userId: String, clientRole: any) {

      const httpOptions = {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: clientRole
      };

      return this.http.delete<any>(environment.KEYCLOAK_GET_USER_GROUPS_1 + 
        userId + environment.KEYCLOAK_ROLEMAPPING_CLIENT + clientId, httpOptions );

  }


  deleteRealmRoleForUser(userId: string, realmRole: any) {


      const httpOptions = {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body:realmRole
      };
  
      return this.http.delete<any>(environment.KEYCLOAK_GET_USER_GROUPS_1 + 
        userId + environment.KEYCLOAK_GET_USER_REALM_ROLE_2 , httpOptions);

  }

  getUserById(userId: String): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_USER_GROUPS_1 + 
      userId);
  }

}