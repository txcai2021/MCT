import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Settings } from '@app/_models';
import { environment } from '@environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SettingsService {

  constructor(private http: HttpClient) { }

  getSettingsByName(name: string){
    return this.http.get<Settings>(`${environment.settingsURL}/Option/Name/${name}`);
  }

  update(setting){
    return this.http.put(`${environment.settingsURL}/Option/`, setting);
  }
}
