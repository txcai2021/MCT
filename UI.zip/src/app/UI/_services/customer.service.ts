import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from'rxjs/operators';
import { environment } from '@environments/environment';
import { Customer, DropdownModel } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class CustomerService {
    
    constructor(private http: HttpClient) {}

    public customerList: DropdownModel[] = [];

    getAll(): Observable<Customer[]> { 
        return this.http.get<Customer[]>(`${environment.customerApiUrl}/customer`);
    }

    save(customer: Customer) {
        customer.category = "Customer";
        return this.http.post(`${environment.customerApiUrl}/customer`, customer);
    }

    update(id, params) {
        return this.http.put(`${environment.customerApiUrl}/customer`, params);
    }

    delete(id: number) {
        return this.http.delete(`${environment.customerApiUrl}/customer/${id}`);
    }

   loadCustomerDropdownData() {
       return this.http.get(`${environment.customerApiUrl}/customer`)
       .pipe(map(data => {
            return (data as any).map(res => ({
                text: res.name,
                value: res.id,
                code: res.code
            }));
       }));
   }
}