﻿import { EventEmitter, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient} from '@angular/common/http';
import { BehaviorSubject, forkJoin, Observable, of, pipe } from 'rxjs';
import { map,mergeMap } from 'rxjs/operators';
import { environment } from '@environments/environment';
import { User } from '@app/_models';
import { KeycloakApiService } from '@dis/services/keycloak-api/keycloak-api.service';
import { KeycloakUserApiService } from './keycloak_user.service';
import { anyChanged } from '@progress/kendo-angular-common';
import { ReturnStatement, ThisReceiver } from '@angular/compiler';
import { KeycloakService } from 'keycloak-angular';


@Injectable({ providedIn: 'root' })
export class AccountService {

    userListChanged = new EventEmitter<User[]>();
    private userSubject: BehaviorSubject<User>;
    public user: Observable<User>;


    constructor(
        private router: Router,
        private http: HttpClient,
        private keycloakApiService: KeycloakApiService,
        private keycloakUserApiService: KeycloakUserApiService,
        private keycloakService: KeycloakService

    ) {
        this.userSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('user')));
        this.user = this.userSubject.asObservable();
    }

    public get userValue(): User {
        return this.userSubject.value;
    }

    login(username, password) {
        return this.http.post<User>(`${environment.userApiUrl}/user/login`, { username, password })
            .pipe(map(user => {
                // store user details and jwt token in local storage to keep user logged in between page refreshes
                localStorage.setItem('user', JSON.stringify(user));
                this.userSubject.next(user);
                return user;
            }));
    }

    logout() {
        // remove user from local storage and set current user to null
        // return this.http.post(`${environment.apiUrl}/user/logout`,null)
        // .pipe(map( response => {
            localStorage.removeItem('user');
            this.userSubject.next(null);
            this.router.navigate(['/account/login']);

       //  }));
    }

    getAll() {
        return this.http.get<User[]>(`${environment.userApiUrl}/user`);
    }

    getById(id: string) {
        return this.http.get<User>(`${environment.userApiUrl}/user/${id}`);
    }

    save(user: User, clientRole: any[], clientId: String, keyCloakRealmRole: any) {
      

        let params =  {
            "username": user.username,
            "enabled":true,
            "totp":false,
            "emailVerified":true,
            "firstName": user.firstName,
            "lastName":"",
            "email": user.email,
            "credentials": [{
                "type": "password",
                "value": user.password//minimum 10 characters
            }],
         
         } 

        let realmRoleParam = [{
            "id": keyCloakRealmRole.id,
            "name": keyCloakRealmRole.name
         }];

        return this.http.post(`${environment.userApiUrl}/user`, user)  //Create user in SMOM
            .pipe(mergeMap((res: any)=> this.keycloakApiService.createNewUsers(params))) //Create user in keycloak
            .pipe(mergeMap((y: any)=>  this.keycloakApiService.getAllUsers()))  //get all users to get saved user id
            .pipe(map( users => {
               const kuser = users.find(allusers => 
                allusers.username?.toLowerCase() === params.username?.toLowerCase());
               return kuser;
            }),
            mergeMap(kuser => {

                const assignRealmRoletoUser = this.keycloakUserApiService.addRealmRoleForUser(kuser.id, realmRoleParam) //assign realm role admin to user
                const asisngClientRoletoUser = this.keycloakUserApiService.addClientRoleForUser(clientId,kuser.id,clientRole)  //assign client role to user
              
                const joinRequests = []
                if(clientRole[0]?.name == "rps-administrator") {
                    joinRequests.push(assignRealmRoletoUser)
                    joinRequests.push(asisngClientRoletoUser)
                }
                else 
                {
                    joinRequests.push(asisngClientRoletoUser)
                }

                return forkJoin(joinRequests)
            }));

    }


    update(id, user, clientRole: any[], clientId: String, keyCloakRealmRole: any) {


        let params =  {
            "username": user.username,
            "enabled":true,
            "totp":false,
            "emailVerified":true,
            "firstName": user.firstName,
            "lastName":"",
            "email": user.email
       
         } 

        let realmRoleParam = [{
            "id": keyCloakRealmRole.id,
            "name": keyCloakRealmRole.name
         }]


         let kuser: any;
         let kuserRealmRole: [];
         let kuserClientRole: [];
         return this.http.put(`${environment.userApiUrl}/user`, user)  //Create user in SMOM
          //Create user in keycloak
         .pipe(mergeMap((y: any)=>  this.keycloakApiService.getAllUsers()))  //get all users to get saved user id
         .pipe(map(users => {
            kuser = users.find(allusers => allusers.username === params.username);
            return kuser;
         }),
         mergeMap(kuser => {
            return this.keycloakApiService.updateUser(params,kuser.id)
         }),
         mergeMap(x => this.keycloakApiService.getUserRealmRoles(kuser.id).pipe(map(roles => {
             kuserRealmRole = roles;
             return kuserRealmRole;
         }))),
         mergeMap(x => this.keycloakUserApiService.getClientRolesByUser(clientId,kuser.id).pipe(map(roles => {
            kuserClientRole = roles;
            return kuserClientRole;
        }))),
         mergeMap(x => {

            const deleteRealmRoletoUser = this.keycloakUserApiService.deleteRealmRoleForUser(kuser.id,kuserRealmRole) //delete realm role admin to user
            const deleteClientRoletoUser = this.keycloakUserApiService.deleteClientRoleForUser(clientId,kuser.id,kuserClientRole)  //delete client role to user.

            const joinRequests = []

            joinRequests.push(deleteClientRoletoUser)
            joinRequests.push(deleteRealmRoletoUser)

            return forkJoin(joinRequests)
         }),

         mergeMap(x => {
    
            const assignRealmRoletoUser = this.keycloakUserApiService.addRealmRoleForUser(kuser.id, realmRoleParam) //assign realm role admin to user
            const asisngClientRoletoUser = this.keycloakUserApiService.addClientRoleForUser(clientId,kuser.id,clientRole)  //assign client role to user

            const joinRequests = []

            if(clientRole[0].name == "rps-administrator") {
                joinRequests.push(assignRealmRoletoUser)
                joinRequests.push(asisngClientRoletoUser)
            }
            else 
            {
                joinRequests.push(asisngClientRoletoUser)
            }

             return forkJoin(joinRequests)
         }));

    }

    delete(id: number,username: string) {
        let kuser: any;
        return this.http.delete(`${environment.userApiUrl}/user/${id}`)
        .pipe(mergeMap((y: any)=>  this.keycloakApiService.getAllUsers()))  //get all users to get saved user id
        .pipe(map(users => {
           kuser = users.find(user => user.username?.toLowerCase() === username.toLowerCase());
           return kuser;
        }),
        mergeMap(kuser => {
           return kuser ? this.keycloakApiService.deleteUser(kuser.id) : of(null);
        }));
    }

    resetPW(id, params) {

        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('username', params.username);


        return this.http.post(`${environment.userApiUrl}/user/ResetPW` , urlSearchParams )
            .pipe(map(x => {
                // update stored user if the logged in user updated their own record
                alert("success")
                if (id == this.userValue.id) {
                    // update local storage
                    const user = { ...this.userValue, ...params };
                    localStorage.setItem('user', JSON.stringify(user));

                    // publish updated user to subscribers
                    this.userSubject.next(user);
                }
                return x;
            }));
    }

   // addGroupForUser(groupId: string, userId: string) {
    addRoleMappingToKeyClockUser(data: any,userId: string) {
        return this.http.post<any>(environment.KEYCLOAK_GET_ALL_GROUPS + 
            userId + environment.KEYCLOAK_GET_USER_REALM_ROLE_2, data);
    }
}