import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from'rxjs/operators';
import { environment } from '@environments/environment';
import { DropdownModel, Parts } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class PartsService {
    public dataList: DropdownModel[] = [];

    constructor(private http: HttpClient) {}

    getAll(): Observable<Parts[]> { 
        return this.http.get<Parts[]>(`${environment.productApiUrl}/Item/Part`);
    }

    save(part: Parts) {

        console.log(JSON.stringify(part));
        return this.http.post(`${environment.productApiUrl}/Item/AddPart`, part);
    }

    update(id, params) {
        return this.http.put(`${environment.productApiUrl}/Item/UpdatePart`, params);
    }

    delete(id: number) {
        return this.http.delete(`${environment.productApiUrl}/Item/${id}`);
    }
   
    loadDropdownData() {
        return this.http.get<Parts[]>(`${environment.productApiUrl}/Item/Part`)
        .pipe(map(data => {
            return data.map(res => ({
                 text: res.description,
                 value: res.id,
                 code: res.name
            }));
        }));
    }

    getAllComponents(customerId: number,partName: String): Observable<Parts[]> { 
        return this.http.get<any[]>(`${environment.productApiUrl}/Item/Part/Search/${customerId}/${partName}`);
    }

    getIndependentParts(customerId: number): Observable<Parts[]> {
        return this.http.get<any[]>(`${environment.productApiUrl}/Item/IndependendParts/${customerId}`);
    }

    getPartsByAssemblyId(assemblyId: number): Observable<Parts[]> { 
        return this.http.get<any[]>(`${environment.productApiUrl}/Item/Parts/${assemblyId}`);
    }
}