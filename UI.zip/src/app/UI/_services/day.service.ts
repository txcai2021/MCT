import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { Day } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class DayService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<Day[]> {
    return this.http.get<Day[]>(
      `${environment.calendarApiUrl}/GetCalendars/?category=Day`
    );
  }

  save(day: any) {
    console.log('shift post');
    console.log(JSON.stringify(day));
    return this.http.post(`${environment.calendarApiUrl}/AddCalendarItem`, day);
  }

  update(params) {
    console.log('shift servie api update');
    console.log(params);
    return this.http.put(
      `${environment.calendarApiUrl}/UpdateCalendarItem`,
      params
    );
  }

  delete(id: string) {
    return this.http.delete(
      `${environment.calendarApiUrl}/DeleteCalendar?id=${id}`
    );
  }
}
