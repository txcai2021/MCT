import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { Meal, MealAdd } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class MealService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<Meal[]> {
    return this.http.get<Meal[]>(
      `${environment.calendarApiUrl}/GetCalendars/?category=Meal`
    );
  }

  save(meal: any) {
    console.log('post');
    console.log(JSON.stringify(meal));
    return this.http.post(`${environment.calendarApiUrl}/AddMeal`, meal);
  }

  update(params) {
    console.log('beforeupmeal');
    console.log(JSON.stringify(params));
    return this.http.put(`${environment.calendarApiUrl}/UpdateMeal`, params);
  }

  delete(id: string) {
    return this.http.delete(
      `${environment.calendarApiUrl}/DeleteCalendar?id=${id}`
    );
    // return this.http.delete(`${environment.mealApiUrl}/DeleteCalendar?id=${id}`);
  }
}
