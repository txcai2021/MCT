import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {  Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { RawMaterial } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class RawMaterialService {
    
    constructor(private http: HttpClient) {}
    getAll(): Observable<RawMaterial[]> { 
        return this.http.get<RawMaterial[]>(`${environment.productApiUrl}/Item/Material`);
    }

    getById(id: number): Observable<RawMaterial>{
        return this.http.get<RawMaterial>(`${environment.productApiUrl}/Item/Material/${id}`);
    }

    save(rawMaterial: RawMaterial) {
        return this.http.post(`${environment.productApiUrl}/Item/AddRawMaterial`, rawMaterial);
    }

    update(id, params) {
        return this.http.put(`${environment.productApiUrl}/Item/UpdateRawMaterial`, params);
    }

    delete(id: number) {
        return this.http.delete(`${environment.productApiUrl}/Item/${id}`);
    }

}