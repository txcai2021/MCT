import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@environments/environment';
import { Observable } from 'rxjs';

import { WorkOrderCreation, WorkOrder } from '@app/_models';

@Injectable({
  providedIn: 'root'
})
export class WorkOrderService {

  constructor(private http: HttpClient) { }

  getAll(): Observable<WorkOrder[]> {
    return this.http.get<WorkOrder[]>(`${environment.workOrderApiUrl}/WorkOrder`); 
  }

  getById(id: number): Observable<WorkOrder> {
    return this.http.get<WorkOrder>(`${environment.workOrderApiUrl}/WorkOrder/${id}`);
  }

  delete(id: number): Observable<any>  {
    return this.http.delete(`${environment.workOrderApiUrl}/WorkOrder/${id}`); 
  }

  generateWorkOrder(workOrderInfo: WorkOrderCreation): Observable<any> {
    return this.http
      .post(`${environment.workOrderApiUrl}/WorkOrder/Generation`, workOrderInfo);
  }

  releaseWorkOrder(
    username: string, 
    payload: Array<{ workOrderId: number, status: number, releasedDate: Date }>
  ): Observable<any> {
    return this.http
      .put(`${environment.workOrderApiUrl}/WorkOrder/Release/${username}`, payload);
  }

  getChildWorkOrders(id: number): Observable<WorkOrder[]> {
    return this.http.get<WorkOrder[]>(`${environment.workOrderApiUrl}/WorkOrder/ChildWorkOrders/${id}`);
  }
}
