import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {  Observable } from 'rxjs';
import { delay } from 'rxjs/operators';
import { environment } from '@environments/environment';
import { Menu, Role } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class MenuService {
    public menu: Observable<Menu>;

    constructor(
        private http: HttpClient
    ) {

    }

    getMenu(RoleName, ModuleName): Observable<Menu[]> {
        return this.http.post<Menu[]>(`${environment.permissionApiUrl}/Role/menus`, { "RoleName" : RoleName, "ModuleName": ModuleName })
            .pipe(delay(1000));
    }

    getRole(): Observable<Role[]> { 
        return this.http.get<Role[]>(`${environment.permissionApiUrl}/Role`)
        .pipe(delay(1000));
    }

    getRoleByName(roleName: string): Observable<Role> {
        return this.http.get<Role>(`${environment.permissionApiUrl}/Role`)
        .pipe(delay(1000));
    }

   
}