import { TestBed } from '@angular/core/testing';

import { Routing } from '@app/_models';
import { RoutingService } from './routing.service';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';

describe('RoutingService', () => {
  let service: RoutingService,
      httpSpy: HttpClient,
      httpSpyMethods = ['get', 'delete', 'put', 'post', 'request'];

  beforeEach(() => {

    httpSpy = jasmine.createSpyObj('HttpClient', httpSpyMethods);

    TestBed.configureTestingModule({
      providers:[
        RoutingService,
        {provide: HttpClient, useValue: httpSpy}
      ]
    });
    service = TestBed.inject(RoutingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call http get with specified url when invoke getAll()', () => {
    const result = service.getAll();

    expect(httpSpy.get).toHaveBeenCalledOnceWith(`${environment.routingApiUrl}/Route`);
  });

  it('should call http get with specified url when invoke getById()', ()=>{
    const id = 1;
    const result = service.getById(id);

    expect(httpSpy.get).toHaveBeenCalledOnceWith(`${environment.routingApiUrl}/Route/${id}`);
  });

  it('should call http post with specified url when invoke save()', () => {

    const data = {} as Routing;
    const result = service.save(data);

    expect(httpSpy.post).toHaveBeenCalledOnceWith(`${environment.routingApiUrl}/Route`, data);
  });

  it('should call http put with specified url when invoke update()', () => {
    const data = {id: 1} as Routing
    const result = service.update(data);

    expect(httpSpy.put).toHaveBeenCalledOnceWith(`${environment.routingApiUrl}/Route/${data.id}`, data);
  });
  
  it('should call http delete with specified url when invoke deleteRoute()', () => {
    const id = 1;
    const result = service.delete(id);

    expect(httpSpy.delete).toHaveBeenCalledOnceWith(`${environment.routingApiUrl}/Route/${id}`);
  });

  it('should call http put with specified url when invoke updateProductRoute()', ()=>{
    const routeId = 1;
    const partIds = ["1","2","3","4"];
    const result = service.updateProductRoute(routeId, partIds);

    expect(httpSpy.put).toHaveBeenCalledOnceWith(`${environment.routingApiUrl}/Route/Product/${routeId}`, partIds);
  });

  it('should call http request with delete method and specified url when invoke resetProductRoutes()', ()=>{
    const partIds = ["1","2","3","4"];
    const result = service.resetProductRoutes(partIds);

    expect(httpSpy.request).toHaveBeenCalledOnceWith('DELETE', `${environment.routingApiUrl}/Route/Product/Reset`, {body: partIds});
  });

  it('should call http request with post method and specified url when invoke copyRoute', ()=>{
    const id = 1;
    const result = service.copyRoute(id);

    expect(httpSpy.request).toHaveBeenCalledOnceWith('POST', `${environment.routingApiUrl}/Route/Copy/${id}`);
  });

  it('should call http put with specified url when invoke updateRouteOperationInstruction()', ()=>{
    const route_id = 1;
    const data = {};

    service.updateRouteOperationInstruction(route_id, data);

    expect(httpSpy.put).toHaveBeenCalledOnceWith(`${environment.routingApiUrl}/Route/Instruction/${route_id}`, data);
  });

});
