import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {  Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { Assembly, Parts, RawMaterial } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class ProductService {
    
    constructor(private http: HttpClient) {}

    getPartById(id): Observable<Parts> {
        return this.http.get<any>(`${environment.productApiUrl}/Item/PartId/${id}`);
    }

    getAssemblyById(id: number): Observable<Assembly> {
        return this.http.get<any>(`${environment.productApiUrl}/Item/AssemblyId/${id}`);
    }

    getPartFamilies(): Observable<string[]> { 
        return this.http.get<string[]>(`${environment.productApiUrl}/Item/PartFamilies`);
    }

    getAssemblyPartFamilies(): Observable<string[]> { 
        return this.http.get<string[]>(`${environment.productApiUrl}/Item/AssemblyFamilies`);
    }

    getProductFamilies(): Observable<string[]>{
        return this.http.get<string[]>(`${environment.productApiUrl}/Item/ProductFamilies`);
    }

    getProductFamilyProductList(productFamily: string): Observable<Array<any>>{
        return this.http.get<string[]>(`${environment.productApiUrl}/Item/ProductFamilies/${productFamily}`);
    }

    getProductListWithRouting(): Observable<Array<any>> {
        return this.http.get<Array<any>>(`${environment.productApiUrl}/Item/ProductRoute`);
    }

    getProductBomById(id: number): Observable<Array<any>> {
        return this.http.get<Array<any>>(`${environment.productApiUrl}/BOM/GetBillofMaterialsByProductId/${id}/M`);
    }

    getFGDimensions(): Observable<string[]> { 
        return this.http.get<string[]>(`${environment.productApiUrl}/Item/FGDimensions`);
    }

    getAllMaterials(): Observable<RawMaterial[]> {
        return this.http.get<RawMaterial[]>(`${environment.productApiUrl}/Item/Material`);
    }

    getRawMaterialType(): Observable<string[]> { 
        return this.http.get<string[]>(`${environment.productApiUrl}/Item/Material/MaterialTypes`);
    }

    getMaterialGrade(): Observable<string[]> { 
        return this.http.get<string[]>(`${environment.productApiUrl}/Item/Material/Grades`);
    }

    getLinkParts(): Observable<string[]> { 
        return this.http.get<string[]>(`${environment.productApiUrl}/Item/Material/LinkedParts`);
    }

    getUoms(): Observable<string[]> { 
        return this.http.get<string[]>(`${environment.productApiUrl}/Item/Material/Uoms`);
    } 

    updateProductRawMaterial(
    productId: number, 
    data: {
        productAssemblyId: number;
        componentId: number;
        bomLevel: number;
        perAssemblyQuantity: number;
        remarks: string; 
    }[]): Observable<any> {
        return this.http
            .put(`${environment.productApiUrl}/Item/UpdateProductRawMaterial/${productId}`, data);
    }

    deleteProductRawMaterial(productId: number): Observable<any> {
        return this.http.delete(`${environment.productApiUrl}/Item/DeleteProductRawMaterial/${productId}`);
    }
}