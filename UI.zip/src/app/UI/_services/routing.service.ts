import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Routing } from '@app/_models';
import { environment } from '@environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RoutingService {

  constructor(private http: HttpClient) { }

  getAll(): Observable<Routing[]> {     
    return this.http.get<any>(`${environment.routingApiUrl}/Route`);
  }

  getById(id: number): Observable<Routing> {
    return this.http.get<Routing>(`${environment.routingApiUrl}/Route/${id}`);
  }

  save(route: Routing): Observable<Routing[]> {
    return this.http.post<Routing[]>(`${environment.routingApiUrl}/Route`, route);
  }

  update(route: Routing): Observable<any> {
    return this.http.put(`${environment.routingApiUrl}/Route/${route.id}`, route);
  }

  delete(id: number): Observable<any>{
    return this.http.delete(`${environment.routingApiUrl}/Route/${id}`);
  }

  updateProductRoute(id: number, partIds: string[]): Observable<any>{
    return this.http.put(`${environment.routingApiUrl}/Route/Product/${id}`, partIds);
  }

  resetProductRoutes(partIds: string[]): Observable<any> {
    return this.http.request('DELETE', `${environment.routingApiUrl}/Route/Product/Reset`, {body: partIds});
  }

  copyRoute(id: number): Observable<any>{
    return this.http.request('POST', `${environment.routingApiUrl}/Route/Copy/${id}`);
  }

  updateRouteOperationInstruction(route_id: number, data): Observable<any> {
    return this.http.put(`${environment.routingApiUrl}/Route/Instruction/${route_id}`, data);
  }
}
