import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { Location } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class LocationService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<Location[]> {
    console.log('get location');
    console.log(`${environment.locationURL}/location`);
    return this.http.get<Location[]>(`${environment.locationURL}/location`);
  }

  save(meal: any) {
    console.log('post');
    console.log(meal);
    console.log(JSON.stringify(Location));
    return this.http.post(`${environment.locationURL}/location`, meal);
  }

  update(id, params) {
    console.log('update params location');
    console.log(JSON.stringify(params));
    return this.http.put(`${environment.locationURL}/Location/`, params);
  }

  delete(id: string) {
    return this.http.delete(`${environment.locationURL}/location/${id}`);
    // return this.http.delete(`${environment.mealApiUrl}/DeleteCalendar?id=${id}`);
  }
}
