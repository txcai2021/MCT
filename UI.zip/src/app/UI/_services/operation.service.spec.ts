import { HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';

import { OperationService } from './operation.service';
import { environment } from '@environments/environment';

describe('OperationService', () => {

  let service: OperationService,
      httpSpy: HttpClient;

  beforeEach(() => {

    httpSpy = jasmine.createSpyObj('HttpClient', ['get', 'post', 'put', 'delete']);

    TestBed.configureTestingModule({
      providers:[
        OperationService,
        {provide: HttpClient, useValue: httpSpy}
      ]
    });
    service = TestBed.inject(OperationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call http get with specified url when invoke getAll()', ()=>{
    const result = service.getAll();

    expect(httpSpy.get).toHaveBeenCalledOnceWith(`${environment.operationURL}`);
  });

  it('should call http post with specified url when invoke save()', ()=>{

    const someObject = {};
    const result = service.save(someObject);

    expect(httpSpy.post).toHaveBeenCalledOnceWith(`${environment.operationURL}`, someObject);
  });

  it('should call http put with specified url when invoke update()', ()=>{

    const id = 1;
    const someObject = {};
    const result = service.update(id, someObject);

    expect(httpSpy.put).toHaveBeenCalledOnceWith(`${environment.operationURL}/${id}`, someObject);
  });

  it('should call http delete with specified url when invoke delete()', ()=>{

    const id = "1";
    const result = service.delete(id);

    expect(httpSpy.delete).toHaveBeenCalledOnceWith(`${environment.operationURL}/${id}`);
  });

  it('should call http get with specified url when invoke getProcessTimeByRouteId()', ()=>{
    const routeId = 1;
    service.getProcessTimeByRouteId(routeId);
    expect(httpSpy.get).toHaveBeenCalledOnceWith(`${environment.operationURL}/Rate/${routeId}`);
  });

  it('should call http put with specified url when invoke updateProcessTimeByRouteId()', ()=>{
    const routeId = 1;
    const data = {};
    service.updateProcessTimeByRouteId(routeId, data);
    expect(httpSpy.put).toHaveBeenCalledOnceWith(`${environment.operationURL}/Rate/${routeId}`, data);
  });

});
