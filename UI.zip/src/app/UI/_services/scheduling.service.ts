import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Schedule, WorkOrder } from '@app/_models';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { map } from 'rxjs/operators';

interface ScheduleParameter {
  locationName: string;
  startDate: string;
  endDate: string;
  dispatchRule: string;
  objective: string;
  wip: boolean;
  command: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class SchedulingService {

  constructor(private http: HttpClient) { }

  getAllSchedule(): Observable<Schedule[]> {
    return this.http.get<any>(`${environment.scheduleURL}/Schedule`);
  }

  getById(id: number): Observable<Schedule> {
    return this.http.get<any>(`${environment.scheduleURL}/Schedule/${id}`);
  }

  getWorkOrdersByLocationId(unitId: number): Observable<WorkOrder[]> {
    return this.http.get<any>(`${environment.scheduleURL}/Schedule/WorkOrders/${unitId}`);
  }

  getObjectives(): Observable<{
    id: number;
    name: string;
    description: string;
    category: string;
    linkedRuleId: number;
  }[]> {
    return this.http.get<any>(`${environment.scheduleURL}/Schedule/Objectives`);
  }

  getRules(): Observable<{
    id: number;
    name: string;
    description: string;
    category: string;
    linkedRuleId: number;
  }[]> {
    return this.http.get<any>(`${environment.scheduleURL}/Schedule/Rules`);
  }

  runSchedule(data: ScheduleParameter): Observable<any> {
    return this.http.post(`${environment.scheduleURL}/Schedule/RunSchedule`, data);
  }

  runSIMlab(fileName: string): Observable<any> {
    return this.http.post(`${environment.scheduleURL}/Schedule/RunSimlab/${fileName}`, {});
  }

  runGAP(fileName: string): Observable<any> {
    return this.http.post(`${environment.scheduleURL}/Schedule/RunGAP/${fileName}`, {});
  }

  deleteSchedule(id: number): Observable<any> {
    return this.http.delete(`${environment.scheduleURL}/Schedule/${id}`);
  }

  confirmSchedule(id: number): Observable<any> {
    return this.http.put(`${environment.scheduleURL}/Schedule/ConfirmSchedule/${id}`, {});
  }

}
