import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { Machine } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class MachineService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<Machine[]> {
    return this.http.get<Machine[]>(`${environment.machineURL}/resource`);
  }

  save(params: any) {
    return this.http.post(`${environment.machineURL}/resource`, params);
  }

  update(id, params) {
    return this.http.put(`${environment.machineURL}/resource/${id}`, params);
  }

  delete(id: string) {
    return this.http.delete(`${environment.machineURL}/Resource/${id}`);
  }
}
