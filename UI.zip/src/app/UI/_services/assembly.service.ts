import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from'rxjs/operators';
import { environment } from '@environments/environment';
import { Assembly, DropdownModel } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class AssemblyService {
    
    public dataList: DropdownModel[] = [];

    constructor(private http: HttpClient) {}

    getAll(): Observable<Assembly[]> { 
        return this.http.get<Assembly[]>(`${environment.productApiUrl}/Item/Assembly`);
    }

    save(assembly: Assembly,components: []) {
        assembly.components = components;
        console.log(JSON.stringify(assembly));
        return this.http.post(`${environment.productApiUrl}/Item/AddAssembly`, assembly);
    }

    update(id, params) {
        console.log(JSON.stringify(params));
        return this.http.put(`${environment.productApiUrl}/Item/UpdateAssembly`, params);
    }

    delete(id: number) {
        return this.http.delete(`${environment.productApiUrl}/Item/${id}`);
    }

    loadDropdownData() {
        return this.http.get(`${environment.productApiUrl}/Item/Assembly`)
        .pipe(map(data => {
            return (data as any).map(res => ({
                text: res.description,
                value: res.id,
                code: res.name
            }));
        }));
 
    }


    getBillOfMaterialsbyAssemblyId(id: number): Observable<any[]> { 
        return this.http.get<any[]>(`${environment.productApiUrl}/BOM/GetBillOfMaterialsbyAssemblyId/${id}`);
    }
}