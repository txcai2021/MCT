import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {  Observable } from 'rxjs';
import { delay } from 'rxjs/operators';
import { environment } from '@environments/environment';
import { Customer } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class SupplierService {
    
    constructor(private http: HttpClient) {}


    getAll(): Observable<Customer[]> { 
        return this.http.get<Customer[]>(`${environment.customerApiUrl}/Supplier`);
    }

    save(customer: Customer) {
        customer.category = "Supplier";
        return this.http.post(`${environment.customerApiUrl}/Supplier`, customer);
    }

    update(id, params) {
        params.id = id;
        return this.http.put(`${environment.customerApiUrl}/Supplier`, params);
    }

    delete(id: number) {
        return this.http.delete(`${environment.customerApiUrl}/Supplier/${id}`);
    }

}