import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {  Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { SaleOrder, SaleOrderLines } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class SaleOrderService {
    
    constructor(private http: HttpClient) {}
    getAll(): Observable<SaleOrder[]> { 
        return this.http.get<SaleOrder[]>(`${environment.saleOrderApiUrl}/SalesOrder`);
    }

    getById(id: number): Observable<SaleOrder> { 
        return this.http.get<SaleOrder>(`${environment.saleOrderApiUrl}/SalesOrder/${id}`);
    }

    save(params) {
        // saleOrder.salesOrderNumber = saleOrder.purchaseOrderNumber;
        // saleOrder.salesOrderLines = salesLines;
      //  console.log(JSON.stringify(saleOrder));
        return this.http.post(`${environment.saleOrderApiUrl}/SalesOrder`, params);
    }

    update(params) {

        return this.http.put(`${environment.saleOrderApiUrl}/SalesOrder`, params);
    }

    delete(id: number) {
        return this.http.delete(`${environment.saleOrderApiUrl}/SalesOrder/${id}`);
    }

}