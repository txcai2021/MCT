import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { Week } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class weekService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<Week[]> {
    return this.http.get<Week[]>(
      `${environment.calendarApiUrl}/GetCalendars/?category=Week`
    );
  }

  save(week: any) {
    console.log(week);
    return this.http.post(
      `${environment.calendarApiUrl}/AddCalendarItem`,
      week
    );
  }

  update(params) {
    console.log('week servie api update');
    console.log(params);
    return this.http.put(
      `${environment.calendarApiUrl}/UpdateCalendarItem`,
      params
    );
  }

  delete(id: any) {
    console.log('delete post');
    console.log(id);
    return this.http.delete(
      `${environment.calendarApiUrl}/DeleteCalendar?id=${id}`
    );
    // return this.http.delete(`${environment.mealApiUrl}/DeleteCalendar?id=${id}`);
  }
}
