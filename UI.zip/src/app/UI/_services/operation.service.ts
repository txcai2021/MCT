import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import { Operation } from '@app/_models';
import { map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class OperationService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<Operation[]> {
    return this.http.get<any>(`${environment.operationURL}`);
  }

  save(params: any) {
    console.log('post request');
    console.log(params);
    return this.http.post(`${environment.operationURL}`, params);
  }

  update(id, params) {
    console.log('before update');
    console.log(id);
    console.log(JSON.stringify(params));
    return this.http.put(`${environment.operationURL}/${id}`, params);
  }

  delete(id: string) {
    console.log('delete id');
    console.log(id);
    return this.http.delete(`${environment.operationURL}/${id}`);
    // return this.http.delete(`${environment.mealApiUrl}/DeleteCalendar?id=${id}`);
  }

  getProcessTimeByRouteId(routeId: number): Observable<any> {
    return this.http.get<any>(`${environment.operationURL}/Rate/${routeId}`);
  }

  updateProcessTimeByRouteId(routeId: number, rates): Observable<any> {
    return this.http.put(`${environment.operationURL}/Rate/${routeId}`, rates);
  }
}
