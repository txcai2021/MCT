import { BehaviorSubject, Observable } from "rxjs";

export class SubjectObservablePair<T> {

    subject: BehaviorSubject<T>;
    observable: Observable<T>;

    constructor(initialValue: T){
        this.subject = new BehaviorSubject<T>(initialValue);
        this.observable = this.subject.asObservable();
    }
}