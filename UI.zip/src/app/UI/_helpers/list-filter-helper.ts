export class ListFilterHelper<T> {

    cachedWordList: T[];
    filterWord: T;

    private filterStrategy: (cachedWordList: T[], filterWord: T) => T[];
    private findIndexStrategy: (filterWord: T) => ((word: T) => any);

    constructor(
        filter: {
            findIndexStrategy: (filterWord) => ((word: T) => any),
            filterStrategy: (cachedWordList: T[], filterWord: T) => T[],
            cachedWordList?: T[]
        }
    ) {
        this.cachedWordList = filter.cachedWordList ?? [];
        this.filterStrategy = filter.filterStrategy;
        this.findIndexStrategy = filter.findIndexStrategy;
    }

    public tryAddWordToCache(fiterWord?: T): boolean {

        this.filterWord = fiterWord ?? this.filterWord;
        const filter = this.filterWord;

        if(!filter) return;

        //Check if filterFor exists and isArray
        if(!this.cachedWordList) return;
        if(!Array.isArray(this.cachedWordList)) return;

        if(!this.filterWordDoesNotExist(filter)) return;

        this.cachedWordList.push(filter);
        return true;
    }

    public getFilterdArray(fiterWord?: T): T[] {

        this.filterWord = fiterWord ?? this.filterWord;
        const filterWord = this.filterWord;

        if(!this.cachedWordList) return;

        if(!filterWord || !this.filterStrategy) return this.cachedWordList;
        
        return this.filterStrategy(this.cachedWordList, filterWord);
    }

    private filterWordDoesNotExist(filter: T): boolean {
        //Check if findIndex Strategy exists
        const findIndex = this.findIndexStrategy;
        if(!findIndex) return;

        //Execute findIndex
        if(this.cachedWordList.findIndex(findIndex(filter))>-1) return;

        return true;
    }

    //Helper method for to check if should render Footer Add Button for Comboboxes
    public checkRenderAddButtonCondition(array): boolean {
        if(!array || !Array.isArray(array)) return;

        const filter = this.filterWord;

        if(!filter) return;

        // If array.length === 0 we'll just render No Data Found Add Button
        if(array.length>0 && this.filterWordDoesNotExist(filter)) return true;
    }
}