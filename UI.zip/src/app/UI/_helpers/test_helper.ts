import { DebugElement, Type } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';

export class JasmineTestHelper<T> {

    componentType: Type<T>;

    fixture: ComponentFixture<T>;
    debugElement: DebugElement;
    component: T;

    services: { [service: string]: any };

    constructor(componentType: Type<T>)
    {
        this.componentType = componentType;
        this.services= {};
    }   
        
    initializeComponent(
        data: {
            schemas?: any[],
            declarations: any[], 
            imports: any[],
            providers: any[]
        }
    ){
        return TestBed.configureTestingModule(data).compileComponents();
    }

    createFixture(){

        const fixture = TestBed.createComponent(this.componentType);
    
        this.fixture = fixture;
        this.component = fixture.componentInstance;
        this.debugElement = fixture.debugElement;
    }

    injectServices(data: {
        [serviceName: string]: {
            class: any
        }
    }) {
        Object.keys(data).forEach(service => {
            this.services[service] = TestBed.inject(data[service].class);
        });
    }

    resetFunctionCalls(data: {
        [serviceName: string]: {name: string}[]
    }) {
        Object.keys(data).forEach(service => {
            data[service].forEach(func => {
                this.services[service][func.name].calls.reset();
            });
        });
    }

    setFunctionReturnValues(data: {
        [serviceName: string]: {name: string, value}[]
    }) {
        Object.keys(data).forEach(service => {
            data[service].forEach(func => {
                this.services[service][func.name].and.returnValue(func.value);
            });
        });
    }
}