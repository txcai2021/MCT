import { Pipe, PipeTransform } from '@angular/core';
import { SalesOrderStatus } from '@app/_models';

@Pipe({
  name: 'salesOrderStatus'
})
export class SalesOrderStatusPipe implements PipeTransform {

  transform(value: number): unknown {
    return value in SalesOrderStatus ? SalesOrderStatus[value]: "Unknown";
  }

}
