import { Pipe, PipeTransform } from '@angular/core';
import { SaleOrderLinesStatus } from '@app/_models';

@Pipe({
  name: 'salesOrderLineStatus'
})
export class SalesOrderLineStatusPipe implements PipeTransform {

  transform(value: number): string {
    return value in SaleOrderLinesStatus ? SaleOrderLinesStatus[value]: "Unknown";     
  }

}
