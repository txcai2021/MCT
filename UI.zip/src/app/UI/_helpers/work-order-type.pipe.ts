import { Pipe, PipeTransform } from '@angular/core';

enum WorkOrderType {
  Assembly = 0,
  Independent = 1,
  Dependent = 2
}

@Pipe({
  name: 'workOrderType'
})
export class WorkOrderTypePipe implements PipeTransform {

  transform(value: number): string {
    return value in WorkOrderType ? WorkOrderType[value] : "Unknown Type";
  }

}
