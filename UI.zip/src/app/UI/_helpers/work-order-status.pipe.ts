import { Pipe, PipeTransform } from '@angular/core';
import { WorkOrderStatus } from '@app/_models';

@Pipe({
  name: 'workOrderStatus'
})
export class WorkOrderStatusPipe implements PipeTransform {

  transform(value: number): string {
    return value in WorkOrderStatus ? WorkOrderStatus[value] : "Unknown";
  }

}
