export class Schedule {

    id: number;
    unitId: string;
    version: number;
    startDate: Date;
    endDate: Date;

    objective: string;
    jobRules: string;
    isConfirmed: boolean;
    lateJobs: string;

    unassignedJobs: string;
    changeoverTimes: number;
    remarks: string;
    createdOn: Date;
    createdBy: string;

    scheduleDetails: any;
}