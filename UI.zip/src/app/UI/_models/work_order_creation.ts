export class WorkOrderCreation {
    salesOrderId: number 
    customerId: number
    requestedBy: string
    details: Array<{ salesOrderDetailId: number; quantity: number; }>
}