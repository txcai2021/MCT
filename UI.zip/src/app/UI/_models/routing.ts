export interface Routing {
    id: number;
    name: string;

    type: number;
    locationId: number;
    locationName: string;

    active: boolean;
    traceLevel: number;
    trackLevel: boolean;

    description: string;
    comment: string;
    createdDate: Date;

    modifiedDate: Date;
    createdBy: string;
    modifiedBy: string;

    version: number;
    operations: number;
    subroutes: number;

    productFamily: string;
    partName: string;
    noofParts: number;
    
    operationList: string;
    partList: any;
    routeOperationPMs: any;
}