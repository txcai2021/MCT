export class SaleOrderLines {

     id: number;
     salesOrderId: number;
     lineNumber: number;
     productId: number;
     productNo: string;
     productName: string;
     revision: string;
     quantity: number;
     unitPrice : number;
     currency: string;
     dueDate: string;
     urgentFlag: any;
     remarks: string;
     status: number;
     salesOrderNumber: string;
     assemblyId: number;
     lotSize: number;
     workOrderNumber: string;
     woStatus: number;
     balanceQuantity: number;
     uom: string;

	constructor(properties: { lineNumber: number, productId: number, productNo: string, productName: string, revision: string, quantity: number, unitPrice: number,
         currency: string, dueDate: string, urgentFlag: string, remarks: string, status: number, salesOrderNumber: string, assemblyId: number, uom: string }) 
     {
          this.lineNumber = properties.lineNumber;
          this.productId = properties.productId;
		this.productNo = properties.productNo;
		this.productName = properties.productName;
		this.revision = properties.revision;
		this.quantity = properties.quantity;
		this.unitPrice = properties.unitPrice;
		this.currency = properties.currency;
		this.dueDate = properties.dueDate;
		this.urgentFlag = properties.urgentFlag;
		this.remarks = properties.remarks;
          this.status = properties.status;
          this.salesOrderNumber = properties.salesOrderNumber;
          this.assemblyId = properties.assemblyId;
          this.uom = properties.uom;
	}
	
}