export class Meal {
  id_: string;
  id: number;
  name: string;
  type: string;
  category: string;
  description: string;
  defaultValue: any;
  startTime: string;
  endTime: string;
  startDate: any;
  endDate: any;
  createdDate: string;
  modifiedDate: string;
  isStaggered: any;
  calendarDetails: any;
}

export class MealAdd {
  Id: string;
  Name: string;
  Category: string;
  Description: string;
  StartTime: string;
  EndTime: string;
}
