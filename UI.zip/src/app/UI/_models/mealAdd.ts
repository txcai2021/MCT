export class MealAdd {
  Id: string;
  Name: string;
  Category: string;
  Description: string;
  StartTime: string;
  EndTime: string;
}
