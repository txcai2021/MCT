export class Menu {
        toolbarActions: [];
        buttonText: string;
        setting: string;
}

export const role: Array<{ text: string, value: number }> = [
        { text: 'ADMINISTRATOR', value: 66 },
        { text: 'DEVELOPER', value: 27 },
        { text: 'SUPERVISOR', value: 73 }
    ];