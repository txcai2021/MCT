export class Settings {

  optionName: string;
  description: string;
  moduleName: string;
  category: string;
  dataType: string;

  defaultSetting: string;

  userPreferences: {
    $id: number,
    $values: Array<any>
  }

  id: number;
  createdOn: Date;
  createdBy: Date
  modifiedBy: Date;
  modifiedOn: Date;
}