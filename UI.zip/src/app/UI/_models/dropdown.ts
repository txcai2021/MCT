export class DropdownModel {
    text: string; value: number; code: string 
}