import { SaleOrderLines } from "./sale_order_lines";

export class SaleOrder {
    id: number;
    salesOrderNumber: string;
    orderType: number;
    purchaseOrderNumber: string;
    orderDate: string;
    dueDate: string;
    status: string;
    customerId: number;
    salesPersonName: string;
    contactPersonName: string;
    contactNo: string;
    locationId: number;
    totalItems: number;
    comment: string;
    amount: number;
    quantity: number;
    balanceQuantity: number;
    balanceAmount: number;
    combinedStatus: boolean;
    billingNo: string;
    createdBy: string;
    salesOrderLines: SaleOrderLines[];
}