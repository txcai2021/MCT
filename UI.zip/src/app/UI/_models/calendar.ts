export class Calendar {
  id_: string;
  id: number;
  name: string;
  type: string;
  category: string;
  description: string;
  defaultValue: any;
  startTime: string;
  endTime: string;
  startDate: any;
  endDate: any;
  createdDate: string;
  modifiedDate: string;
  isStaggered: any;
  calendarDetails: any;
  calendarChilds: any[];
}
