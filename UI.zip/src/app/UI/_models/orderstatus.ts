//0:Pending, 10:WorkOrderIssued, 30: Closed
export enum SaleOrderLinesStatus {
  Cancelled = 0, 
  Pending = 10,
  WorkOrderIssued = 20,
  Scheduled = 24,
  Completed = 30,
  Closed = 40
}

export enum WorkOrderStatus {
    Unknown = 1,
    Pending = 0,
    Released = 10,
    Dispatched = 100,
    Queuing = 110,
    Processing = 120,
    Scrapped = 200,
    Discard = 210,
    ReturnUnclean = 220,
    Completed = 230,
    Charged = 240,
    SCRGenerated = 255
}

export enum SalesOrderStatus {
  New = 0,
  Pending = 10,
  Approved = 20,
  Scheduled = 24,
  Processing = 26,
  Completed = 30,
  Closed = 40
}