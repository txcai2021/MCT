export class Role {
    $value: [];
    roleId: number;
    name: string;
}