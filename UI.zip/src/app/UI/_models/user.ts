﻿export class User {
    id: number;
    name: string;
    username: string;
    roles: [];
    modules: [];
    token: String;
    loginId: string;
    firstName: string;
    lastName: string;
    mobile: string;
    email: string;
    password: string;
    isLockedOut: true;
    lastLoginDate:string;
    comment: string;
    roleID: number;
}

