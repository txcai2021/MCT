export class WorkOrder {
    id: number;
    workOrderNumber: string;
    productId: number;
    quantity: number;
    orderType: number;
    issueDate: Date;

    dueDate: Date;

    status: number;
    locationId: number;
    customerId: number;
    routeId: number;
    remarks: string;

    urgentFlag: number;

    releasedDate: Date;
    materialList: string;
    isMaterialAllocated: boolean;

    createdBy: string;
    releasedBy: string;

    customer: {
        id: number;
        name: string;
        description: string;
        value: string;
    };

    location: {
        id: number;
        name: string;
        description: string;
        value: any;
    };

    noofChildWOs: number;
    workOrderMaterials: Array<any>;

    productNo: string;
    productName: string;
    productFamily: string;
    assemblyNo: string;
    assemblyName: string;
    poNumbers: string;
    poRemarks: string;
    lineNo: number;

    committedDeliveryDate: string;

    routeName: string;

    buyList: string[];
    fileName: string;
    contactPersonName: string;
    contactNo: string;
}