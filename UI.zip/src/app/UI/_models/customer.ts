export class Customer {
    id: number;
    code: string;
    name: string;
    site: string;
    department: string;
    group: string;
    contactPerson: string;
    phone: string;
    email: string; 
    address: string;
    billingAddress: string;
    priority: number;
    description: string;
    currency: string;
    creditTerm: string;
    category: string;
}
