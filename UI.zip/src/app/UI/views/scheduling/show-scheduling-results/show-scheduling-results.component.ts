import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { SubjectObservablePair } from '@app/_helpers';

@Component({
  selector: '[app-show-scheduling-results]',
  templateUrl: './show-scheduling-results.component.html',
  styleUrls: ['./show-scheduling-results.component.scss']
})
export class ShowSchedulingResultsComponent implements OnInit, OnDestroy {

  results = new SubjectObservablePair<any[]>([]);

  @Output() closeWindow = new EventEmitter<boolean>();

  constructor() {}

  ngOnInit(): void {}

  convertFromDBToResultsVM(result) {

  }

  onClose(): void {
    this.closeWindow.emit(true);
  }

  ngOnDestroy(): void {
    this.closeWindow.unsubscribe();
  }

}
