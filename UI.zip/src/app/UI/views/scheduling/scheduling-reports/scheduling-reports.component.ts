import { Component, OnInit } from '@angular/core';
import { SchedulingService } from '@app/_services/scheduling.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { ToastService } from '@dis/services/message/toast.service';
import { RemoveEvent } from '@progress/kendo-angular-grid';
import { BehaviorSubject, forkJoin } from 'rxjs';

import { SubjectObservablePair } from '@app/_helpers';
import { SettingsService } from '@app/_services';

interface ScheduleVM {

  id: number;
  location: string;
  version: number;
  startDate: Date;
  endDate: Date;

  objective: string;
  rule: string;
  isConfirmed: boolean;
  noOfLateJobs: string;

  noOfUnassignedJobs: string;
  changeoverTime: number;
  remarks: string;
  scheduledDate: Date;
  scheduledBy: string;
}

@Component({
  selector: 'app-scheduling-reports',
  templateUrl: './scheduling-reports.component.html',
  styleUrls: ['./scheduling-reports.component.scss']
})
export class SchedulingReportsComponent implements OnInit {

  gridViewSelection: number[] = [];

  gridView = new SubjectObservablePair<ScheduleVM[]>([]);

  showViewByResourceSubject = new SubjectObservablePair<boolean>(false);
  viewByOption = new SubjectObservablePair<string>('machine');

  showResults = new SubjectObservablePair<boolean>(false);
  renderShowResultsButton: boolean = false;

  constructor(
    private settingsService: SettingsService,
    private schedulingService: SchedulingService,
    private customDialog: CustomDialogService,
    private toastr: ToastService
  ) { 

  }

  ngOnInit(): void {
    this.settingsService.getSettingsByName('EnableGAP')
    .subscribe(res => {

      if(!res) return;

      this.renderShowResultsButton = res.defaultSetting === "T";

    });

    this.refreshUI();
  }

  refreshUI(): void {
    this.schedulingService.getAllSchedule()
    .subscribe(res=>{

      if(!res) return;

      //Temporarily Hard-coded to not show preceding year's data
      res = res.filter(schedule => 
        new Date(schedule.createdOn).getFullYear()>2021); 

      this.gridView.subject.next(
        res.map(this.convertToScheduleVM)
        );
    });
  }

  convertToScheduleVM(data): ScheduleVM {
    return {
      id: data.id,
      location: data.unitId,
      version: data.version,
      startDate: data.startDate,
      endDate: data.endDate,

      objective: data.objective,
      rule: data.jobRules,
      isConfirmed: data.isConfirmed,
      noOfLateJobs: data.lateJobs,

      noOfUnassignedJobs: data.unassignedJobs,
      changeoverTime: data.changeoverTimes,
      remarks: data.remarks,
      scheduledDate: data.createdOn,
      scheduledBy: data.createdBy
    } as ScheduleVM;
  }

  onDeleteClick(event: RemoveEvent): void {

    this.customDialog.confirm()
    .subscribe(res=>{
      if(res.primary){
        //Remove Item
        this.schedulingService
            .deleteSchedule(event.dataItem.id)
            .subscribe(res=>{
              if(res){
                this.toastr.success('Your data has been deleted successfully');
                this.refreshUI();
              }
            });
      }
    });
  }

  onViewByWorkOrderClick(): void {
    if(this.gridViewSelection.length>0){
      this.viewByOption.subject.next('workorder');
      this.showViewByResourceSubject.subject.next(true);
    }
  }

  onViewByMachineClick(): void {
    if(this.gridViewSelection.length>0){
      this.viewByOption.subject.next('machine');
      this.showViewByResourceSubject.subject.next(true);
    }
  }
  
  onShowResultsClick(): void {
    this.showResults.subject.next(true);
  }
  
  onDeleteButtonClick(): void {
    if(this.gridViewSelection?.length>0){
      this.customDialog.confirm().subscribe(res=>{
        if(res.primary){
          forkJoin(this.gridViewSelection.map(id=>
            this.schedulingService.deleteSchedule(id)))
          .subscribe(res=>{
            if(res.filter(result=>!result).length===0){
              this.toastr.success('Your data has been deleted successfully');
            }
            this.gridViewSelection = [];
            this.refreshUI();
          });
        }
      });  
    }
  }

  onConfirmScheduleClick(): void {
    if(this.gridViewSelection?.length>0){
      this.customDialog.confirm().subscribe(res=>{
        if(res.primary){
          this.schedulingService.confirmSchedule(this.gridViewSelection[0])
            .subscribe(res=>{
              if(res){
                this.refreshUI();
                this.toastr.success('Schedule Confirm has been Executed Successfully.');
              }
            });
        }
      });
    }
  }

  closeWindow(window: string): void {
    switch(window){
      case 'viewByResource':
        this.showViewByResourceSubject.subject.next(false);
        break;
      case 'showResults':
        this.showResults.subject.next(false);
        break;
    }
  }

}
