import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Settings } from '@app/_models';
import { SettingsService } from '@app/_services';
import { ToastService } from '@dis/services/message/toast.service';
import { formatDate } from '@progress/kendo-angular-intl';
import { forkJoin } from 'rxjs';

interface ScheduleSettingsVM {
  id: number;
  optionName: string;
  defaultSetting: any;
  dataType: string;
  isDirty: boolean;
}

enum SettingsMap {
  systemDate = 'DPS_SystemDate',
  scheduleStartDate = 'DPS_ScheduleStartDate',
  scheduleDays = 'DPS_ScheduleWorkingDays',
  scheduleVersionMax = 'DPS_ScheduleMaxVersions',
  scheduleFrozenPeriod = 'Schedule_FrozenPeriod',
  assemblyAtLastOperation = 'AssemblyAtLastOperation',
  //partialDispatch = 'DPSPartialDispatch',
  showAllWIP = 'CanShowWIPinGrid',
  enableGAP = 'EnableGAP'
}

@Component({
  selector: 'app-scheduling-settings',
  templateUrl: './scheduling-settings.component.html',
  styleUrls: ['./scheduling-settings.component.scss']
})
export class SchedulingSettingsComponent implements OnInit {

  readonly SettingsMap = SettingsMap;

  data = {
    systemDate: new Date(),
    resetSystemDate: true,
    scheduleStartDate: new Date(),
    resetScheduleStartDate: false,
    scheduleDays: 0,
    scheduleVersionMax: 0,
    scheduleFrozenPeriod: 0,
    assemblyAtLastOperation: false,
    partialDispatch: false,
    showAllWIP: false,
    enableGAP: false
  };

  formGroup: FormGroup;

  cachedSettings: {
    [name:string]: ScheduleSettingsVM
  } = {};

  constructor(
    private settingsService: SettingsService,
    private toastr: ToastService
  ) { 
    const formGroupControls = 
      Object.keys(this.data).reduce((prev, cur)=>({
        ...prev, [cur]: new FormControl(this.data[cur], Validators.required)
      }), {});

    this.formGroup = new FormGroup(formGroupControls);
  }

  ngOnInit(): void {

    const settingsName = Object.values(SettingsMap);

    forkJoin(settingsName.map(name=>this.settingsService.getSettingsByName(name)))
    .subscribe(res=>{

      if(res){
        const settingsVMs = 
          res.map(this.convertSettingsToScheduleVM)
             .map(this.convertDefaultSettingTypeByDataType);

        this.cachedSettings = settingsName.reduce((prev, cur, index)=>{
          let current = settingsVMs[index].id ? {[cur]: settingsVMs[index]} : {};
          return {...prev, ...current}; 
        }, {});

        const formPatch = Object.keys(SettingsMap).reduce((prev, cur)=>{
          let cachedValue = this.cachedSettings[SettingsMap[cur]];
          let setting = cachedValue?.id ? { [cur]: cachedValue.defaultSetting } : {};
          return {...prev, ...setting};
        }, {});

        this.formGroup.patchValue(formPatch);
        this.disableFormControlsWithNonExistentSettingsInDB(Object.keys(formPatch));

      }

    });
  }

  disableFormControlsWithNonExistentSettingsInDB(settingsThatExist: string[]){

    const allSettings = Object.keys(SettingsMap);
    const toDisable = allSettings
      .filter(key => !settingsThatExist.includes(key));

    toDisable.forEach(key =>{
      this.formGroup.get(key)?.disable();
    });

  }

  onSaveClick(): void {
    forkJoin(
      Object.values(this.cachedSettings)
      .filter(setting=>setting.isDirty)
      .map(this.convertScheduleSettingsVMForUpdate)
      .map(setting=>this.settingsService.update(setting))
    ).subscribe(res=>{
      if(res){
        this.resetAllSettingsDirtyStatus();
        this.toastr.success('Your data has been saved successfully.');
      }
    });
  }

  convertSettingsToScheduleVM(settings: Settings): ScheduleSettingsVM {
    return <ScheduleSettingsVM>(settings ? {
      id: settings?.id,
      optionName: settings?.optionName,
      defaultSetting: settings?.defaultSetting,
      isDirty: false,
      dataType: settings?.dataType
    } : {});
  }

  convertDefaultSettingTypeByDataType(settings: ScheduleSettingsVM): ScheduleSettingsVM {
   
    if(settings.id){

      switch(settings.dataType?.trim()){
        
        case "Datetime":   
          switch(settings.defaultSetting){
            case "Today": 
            case "":
              settings.defaultSetting = new Date();
              break;
            default:
              settings.defaultSetting = new Date(settings.defaultSetting);
          }
          break;

        case "string":
          switch(settings.defaultSetting){
            case "T":
            case "F":
              settings.defaultSetting = settings.defaultSetting === "T";
              break;
          }
          break;

        case "int":
        case "double":
          settings.defaultSetting = parseFloat(settings.defaultSetting);
          break;
      }
    }

    return settings;
  }

  convertScheduleSettingsVMForUpdate(settings: ScheduleSettingsVM) {
    return {
      id: settings.id,
      defaultSetting: settings.defaultSetting
    };
  }

  onInputValueChange(inputField: string, input: any): void {
    let defaultSetting;
    switch(inputField){
      case SettingsMap.systemDate:
      case SettingsMap.scheduleStartDate:
        defaultSetting = formatDate(input ? new Date(input) : new Date(), 's');
        break;
      case SettingsMap.scheduleDays:
      case SettingsMap.scheduleVersionMax:
      case SettingsMap.scheduleFrozenPeriod:
        defaultSetting = input?.toString();
        break;
      case SettingsMap.assemblyAtLastOperation:
      //case SettingsMap.partialDispatch:
      case SettingsMap.showAllWIP:
      case SettingsMap.enableGAP:
        defaultSetting = input.target.checked ? "T" : "F";
        break;
    }

    if(this.cachedSettings.hasOwnProperty(inputField)){
      this.cachedSettings[inputField].defaultSetting = defaultSetting;
      this.cachedSettings[inputField].isDirty = true;
    }
    else {
      this.toastr.error(`The setting ${SettingsMap[inputField] ?? inputField} was not retrieved successfully previously`);
    }
  }

  resetAllSettingsDirtyStatus(): void {
    Object.keys(this.cachedSettings).forEach(key=>{
      this.cachedSettings[key] = {...this.cachedSettings[key], isDirty: false};
    });
  }

  resetDate(inputField: string, input: boolean): void {
    switch(inputField){
      case SettingsMap.scheduleStartDate:

        let date = this.formGroup.get('scheduleStartDate')?.value;

        date = input || !date ? new Date() : date;

        this.formGroup.patchValue({
          scheduleStartDate: date,
          resetScheduleStartDate: input
        });
        this.onInputValueChange(inputField, date);
        break;
    }
  }

}
