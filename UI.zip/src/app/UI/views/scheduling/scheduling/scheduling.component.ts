import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { WorkOrder } from '@app/_models';
import { LocationService, SettingsService } from '@app/_services';
import { SchedulingService } from '@app/_services/scheduling.service';
import { ToastService } from '@dis/services/message/toast.service';
import { BehaviorSubject, forkJoin, Observable, of, throwError } from 'rxjs';
import { map } from 'rxjs/operators';
import { addDays } from "@progress/kendo-date-math";
import { formatDate } from '@telerik/kendo-intl';

interface WorkOrderVM {
  id: number;
  woNumber: string;
  releasedDate: Date;
  customerCode: string;
  productNo: string;
  productName: string;
  productFamily: string;
  poNumber: string;
  lineNo: number;
  quantity: number;
  status: number;
  currentOperation: string;
  routeName: string;
  requestedDeliveryDate: Date;
  materialList: string;
  orderType: number;
  drawingA: string;
  drawingB: string;
  drawingC: string;
  poRemarks: string;
  specialRequest: string;
  buyList: string[];
  unit: string;
  createdDate: Date;
  createdBy: string;
}

@Component({
  selector: 'app-scheduling',
  templateUrl: './scheduling.component.html',
  styleUrls: ['./scheduling.component.scss']
})
export class SchedulingComponent implements OnInit {

  gridViewSubject = new BehaviorSubject<WorkOrderVM[]>([]);
  gridView$ = this.gridViewSubject.asObservable();

  gridViewSelection: number[] = [];

  data = {
    unit: {text: '', value: -1},
    startDate: new Date(),
    endDate: new Date(),
    objectives: {text: '', value: -1},
    rules: {text: '', value: -1},
    jobsScheduled: false,
    gapOption: {text: '', value: -1}
  }

  formGroup: FormGroup;

  unitList: {text: string; value: number}[] = [];

  openGenerateScheduleWindowSubject = new BehaviorSubject<boolean>(false);
  openGenerateScheduleWindow$ = this.openGenerateScheduleWindowSubject.asObservable();

  rulesSubject = new BehaviorSubject<{text: string; value: number}[]>([]);
  rules$ = this.rulesSubject.asObservable();
  cachedRules: {
    [id: number]: {
      id: number;
      name: string;
      description: string;
      category: string;
      linkedRuleId: number;
  }
  } = {};

  objectivesSubject = new BehaviorSubject<{text: string; value: number}[]>([]); 
  objectives$ = this.objectivesSubject.asObservable();
  cachedObjectives: {
    [id: number]: {
      id: number;
      name: string;
      description: string;
      category: string;
      linkedRuleId: number;
  }
  } = {};

  gapOptions = [
    {
      text: 'SMOM', 
      value: 0,
      algorithm: this.getSMOMAlgorithm
    },
    {
      text: 'GAP Analysis', 
      value: 1,
      algorithm: this.getGAPAlgorithm
    },
    {
      text: 'Performance Prediction', 
      value: 2,
      algorithm: this.getSIMLabAlgorithm
    }
  ];
  gapOptionsSubject = new BehaviorSubject<{text: string, value: number}[]>(this.gapOptions);
  gapOptions$ = this.gapOptionsSubject.asObservable();

  enableGapDropdownSubject = new BehaviorSubject<boolean>(false);
  enableGapDropdown$ = this.enableGapDropdownSubject.asObservable();

  constructor(
    private locationService: LocationService,
    private schedulingService: SchedulingService,
    private toastr: ToastService,
    private settingsService: SettingsService
  ) { 

    const formGroupControls = Object.keys(this.data)
    .reduce((prev, cur)=>({
      ...prev, [cur]: new FormControl(this.data[cur])
    }), {});

    this.formGroup = new FormGroup(formGroupControls);
  }

  ngOnInit(): void {
    this.refreshGridViewAndLocationDropdown();
  }

  refreshGridViewAndLocationDropdown(): void {
    this.getValuesForLocationDropdown()
    .subscribe(res=>{

      if(!res || res.length<=0) return;

      this.unitList = res;

      const locationId = res[0].value;

      this.formGroup.patchValue({ unit: res[0] });

      this.getDataForGridByLocationId(locationId)
      .subscribe(res=>this.gridViewSubject.next(res ?? [])); 
    });
  }

  getAndSetValuesForRunSchedulerForm(){
    forkJoin([
      this.getEnableGapDropdownSettings(),
      this.getScheduleStartDateSettings(),
      this.getScheduleOffsetSettings()
    ])
    .pipe(map(res=>({ 
      enableGAPDropdown: res[0] ,
      scheduleStartDate: res[1],
      scheduleOffset: res[2]
    })))
    .subscribe(res=>{

      this.enableGapDropdownSubject.next(res.enableGAPDropdown ?? false);

      this.formGroup.patchValue({
        gapOption: this.gapOptions[0],
        startDate: res.scheduleStartDate,
        endDate: addDays(res.scheduleStartDate, res.scheduleOffset)
      });
    });
  }

  getEnableGapDropdownSettings(): Observable<boolean> {
    return this.settingsService.getSettingsByName("EnableGAP")
      .pipe(map(res => res?.defaultSetting === "T"));
  }

  getScheduleStartDateSettings(): Observable<Date> {

    return this.settingsService.getSettingsByName("DPS_ScheduleStartDate")
      .pipe(map(res => {

          if(!res) {
            console.error('Setting DPS_ScheduleStartDate does not exist');
            return new Date();
          }

          let date = new Date(res.defaultSetting);

          if(isNaN(date.getTime())) {
            console.error('Invalid date format for DPS_ScheduleStartDate:', res.defaultSetting);
            return new Date();
          }

          return date;

      }));
  }

  getScheduleOffsetSettings(): Observable<number> {

    return this.settingsService.getSettingsByName("DPS_ScheduleWorkingDays")
      .pipe(map(res => {

        if(!res) {
          console.error('Setting DPS_ScheduleWorkingDays does not exist');
          return 0;
        }

        let result = parseInt(res.defaultSetting);
        return isNaN(result) ? 0 : result;
      }));
  }

  getValuesForLocationDropdown(): Observable<{text: string; value: number;}[]> {

    return this.locationService.getAll().pipe(map(res=>{

      let result = [];

      if(res && res.length>0){
        result = res.map(unit=>({
          text: unit.name,
          value: unit.id
        }));
      }

      return result;
      
    }));
  }

  getDataForGridByLocationId(locationId: number): Observable<any> {
    return this.schedulingService.getWorkOrdersByLocationId(locationId)
    .pipe(map(res => res.map(this.convertWorkOrderDataToSchedulingVM)));
  }

  convertWorkOrderDataToSchedulingVM(data: WorkOrder): WorkOrderVM {
    return {
      id: data.id,
      woNumber: data.workOrderNumber,
      releasedDate: new Date(data.releasedDate),
      customerCode: data.customer?.name,
      productNo: data.productNo,
      productName: data.productName,
      productFamily: data.productFamily,
      poNumber: data.poNumbers,
      lineNo: data.lineNo,
      quantity: data.quantity,
      status: data.status,
      //currentOperation: data.currentOperation,
      routeName: data.routeName,
      requestedDeliveryDate: new Date(data.dueDate),
      materialList: data.materialList,
      orderType: data.orderType,
      //drawingA: data.drawingA,
      //drawingB: data.drawingB,
      //drawingC: data.drawingC,
      poRemarks: data.poRemarks,
      //specialRequest: data.specialRequest,
      buyList: data.buyList,
      unit: data.location?.name,
      createdDate: new Date(data.issueDate),
      createdBy: data.createdBy
    } as WorkOrderVM;
  }

  onRunSchedulerClick(): void {

    this.getAndSetValuesForRunSchedulerForm();

    forkJoin([
      this.schedulingService.getObjectives(),
      this.schedulingService.getRules()
    ])
    .pipe(map(res=>({
      objectives: res[0],
      rules: res[1]
    })))
    .subscribe(res=>{

      if(!res.objectives || !res.rules) return;

      const _objectivesArray = res.objectives.map(objective=>({
        text: objective.name, 
        value: objective.id
      }));

      this.objectivesSubject.next(_objectivesArray);
        
      this.cachedObjectives = res.objectives.reduce((prev, cur)=>({
        ...prev, [cur.id]: cur
      }), {});
  
      this.rulesSubject.next(
        res.rules.map(rule=>({
          text: rule.name, 
          value: rule.id
        }))
      );

      this.cachedRules = res.rules.reduce((prev, cur)=>({
        ...prev, [cur.id]: cur
      }), {});

      this.openGenerateScheduleWindowSubject.next(true);

      if(_objectivesArray.length<=0) return;

      this.formGroup.patchValue({
        objectives: _objectivesArray[0]
      });

      this.onObjectiveChange(_objectivesArray[0]);
  
    });
    
  }

  onGenerateScheduleRunClick(): void {

    const formGroup = this.formGroup.value;
    const gapOption = parseInt(formGroup.gapOption?.value);

    const data = {
      locationName: formGroup.unit.text,
      startDate: formatDate(formGroup.startDate, 's'),
      endDate: formatDate(formGroup.endDate, 's'),
      dispatchRule: formGroup.rules.text,
      objective: formGroup.objectives.text,
      wip: formGroup.jobsScheduled,
      command: false
    };

    this.executeSchedulingAlgorithmByGapOption({ data: data, gapOption: gapOption })
    .subscribe(res=>{
      this.openGenerateScheduleWindowSubject.next(false);
    }, this.scheduleAlgorithmErrorResponse(gapOption));
  }

  executeSchedulingAlgorithmByGapOption(params: { data: any, gapOption: number }): Observable<any> {

    let option = this.gapOptions.find(_gapOption => _gapOption.value === params.gapOption);

    if(!option) {
      return throwError("Error Occured While Selecting Scheduler Algorithm to Execute");
    }

    return option.algorithm.apply(this, [params]);
  }

  getSMOMAlgorithm(params: { data: any, gapOption: number }) {
    return this.schedulingService.runSchedule(params.data)
      .pipe(map(this.scheduleAlgorithmResponse(params.gapOption)));
  }

  getGAPAlgorithm(params: { data: any, gapOption: number }){
    return this.schedulingService.runGAP("GAPSMOM")
      .pipe(map(res => {

        this.scheduleAlgorithmResponse(params.gapOption)(res);

        if(!res) return; 

        alert(JSON.stringify(res)); 
        
      }));
  }

  getSIMLabAlgorithm(params: { data: any, gapOption: number }){
    return this.schedulingService.runSchedule(params.data)
    .pipe(map(res => {

      if(res){

        this.schedulingService.runSIMlab("DSimLab")
          .subscribe(res => {

            this.scheduleAlgorithmResponse(params.gapOption)(res);

            if(!res) return;

            alert(JSON.stringify(res)); 
            
          }, 
          this.scheduleAlgorithmErrorResponse(params.gapOption));
      }
      else { 
        this.scheduleAlgorithmResponse(0)(false); 
      }

    }));
  }

  onUnitChange(input): void {

    if(input.value<=0) return;

    this.getDataForGridByLocationId(input.value).subscribe(res=>{
      this.gridViewSubject.next(res);
    });
  }

  scheduleAlgorithmResponse(gapOption): (res: any) => void {
    return res => {
      if(res){
        this.toastr.success(`${this.gapOptions[gapOption]?.text} Has Been Successfully Executed.`);
      }
      else { 
        this.toastr.error(`Error occured when running ${this.gapOptions[gapOption]?.text}`); 
      }
    };
  }

  scheduleAlgorithmErrorResponse(gapOption): (res: any) => void  {
    return err => {
      this.toastr.error(`Unable to Generate Schedule for ${this.gapOptions[gapOption]?.text} Algorithm`);
      console.error(err);
    };
  }

  onObjectiveChange(input: { text, value }): void {

    if(!this.cachedObjectives.hasOwnProperty(input.value)) return;

    const objective = this.cachedObjectives[input.value];

    if(!this.cachedRules.hasOwnProperty(objective.linkedRuleId)) return;

    const rule = this.cachedRules[objective.linkedRuleId];

    this.formGroup.patchValue({
      rules: {
        text: rule.name,
        value: rule.id
      }
    });
    
  }

  closeWindow(window: 'generateSchedule'): void {
    switch(window){
      case 'generateSchedule':
        this.openGenerateScheduleWindowSubject.next(false);
        break;
    }
  }

}
