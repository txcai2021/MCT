import { Component, Input, OnDestroy, EventEmitter, Output } from '@angular/core';
import { SchedulerView, TimelineMonthViewComponent, ToolbarService } from '@progress/kendo-angular-scheduler';

@Component({
    selector: '[gantt-chart-navigation]',
    template: `
    <div style="display:flex;">
        <kendo-buttongroup>
            <button kendoButton (click)="prev()">
                <span class="k-icon k-i-arrow-60-left"></span>
            </button> 
            <button kendoButton (click)="next()">
                <span class="k-icon k-i-arrow-60-right"></span>
            </button>
            </kendo-buttongroup>
        <div class="m-2">
            <kendo-datepicker [value]="selectedDate" (valueChange)="changeDate($event)"></kendo-datepicker>
            <span class="m-1">
                {{ selectedDate | date: "MMMM d, y" }} - {{ endDate | date: "MMMM d, y" }}
            </span>
        </div>
    </div>
    `,
    styleUrls: ['./gantt-chart-navigation.scss']
})
export class GanttChartNavigation implements OnDestroy {
    
    @Input() public selectedView: TimelineMonthViewComponent;
    @Input() public selectedDate: Date = new Date();
    @Input() public endDate: Date = new Date();

    @Output() public dateChange = new EventEmitter<Date>();

    constructor(public toolbarService: ToolbarService) {}

    public next(): void {
        this.toolbarService.navigate({
            type: 'next',
        });
    }

    public prev(): void {
        this.toolbarService.navigate({
            type: 'prev',
        });
    }

    public changeDate(date: Date = this.selectedDate): void {
        this.toolbarService.navigate({
            type: 'select-date',
            date: date
        });
    }

    public changeTimeline(view?: SchedulerView): void {
        this.toolbarService.navigate({
            'type': 'view-change',
            'view': view ?? this.selectedView
        });
    }

    ngOnDestroy(): void {
        this.dateChange.unsubscribe();
    }
}