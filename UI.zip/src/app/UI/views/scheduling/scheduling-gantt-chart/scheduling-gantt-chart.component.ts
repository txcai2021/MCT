import { Component, OnDestroy, OnInit, DoCheck, Output, EventEmitter, Input, ChangeDetectorRef, ViewChild } from '@angular/core';
import { formatDate } from '@telerik/kendo-intl';
import { SchedulingService } from '@app/_services/scheduling.service';
import { EventStyleArgs, DateChangeEvent, TimelineMonthViewComponent, SchedulerComponent } from "@progress/kendo-angular-scheduler";
import { BehaviorSubject, Subject } from 'rxjs';
import { getDate, addWeeks, addDays } from "@progress/kendo-date-math";
import { orderBy } from '@progress/kendo-data-query';
import { GanttChartNavigation } from './gantt-chart-navigation';

import { SubjectObservablePair } from '../../../_helpers/subject-observable-pair';
import { Schedule } from '@app/_models';

interface ScheduleVM {
  id: number;
  resourceId: number;
  start: Date;
  startTimezone: string
  end: Date;
  endTimezone: string
  isAllDay: boolean
  title: string;
  //description: string;
  color: string;
  scheduleType: string;
  tooltip: {
    sequenceAndQuantity: string
    duration: string;
    partName: string;
    operation: string;
  }
}

@Component({
  selector: '[app-scheduling-gantt-chart]',
  templateUrl: './scheduling-gantt-chart.component.html',
  styleUrls: ['./scheduling-gantt-chart.component.scss']
})
export class SchedulingGanttChartComponent implements OnInit, OnDestroy, DoCheck {

  @Output() closeWindow = new EventEmitter<boolean>();
  @Input() scheduleId: number = -1;
  @Input() viewBy: string =  'machine';

  @ViewChild("scheduler", { static: true }) scheduler: SchedulerComponent;
  @ViewChild("ganttChartNavigation") ganttChartNavigation: GanttChartNavigation;

  @ViewChild("timeline_weekly", { static: true }) timeline_weekly: TimelineMonthViewComponent;
  @ViewChild("timeline_day", { static: true }) timeline_day: TimelineMonthViewComponent;
  @ViewChild("timeline_hourly", { static: true }) timeline_hourly: TimelineMonthViewComponent;

  group = new SubjectObservablePair<{ resources: any[], orientation: string }>({
    resources: [],
    orientation: 'vertical'
  });

  endDate = new Date();

  cachedXAxisValues: ScheduleVM[];
  xAxis = new SubjectObservablePair<any[]>([]);
  yAxis = new SubjectObservablePair<any[]>([]);
  scrollTime = new SubjectObservablePair<Date>(new Date());

  cachedSchedulesById: {
    [id: number]: any;
  }

  colorRecord: {scheduleType: string, color: string}[] = [];

  timelineScale = new SubjectObservablePair<number>(16);
  columnWidth = new SubjectObservablePair<number>(50);

  dataChangeSubject: Subject<any> = new Subject();

  getEventStyles = (args: EventStyleArgs) => ({
    backgroundColor: args.event.dataItem.color,
    border: '2px solid white'
  });

  views = {
    'hourly': {
      selected: true,
      columnWidth: 50,
      timelineScale: 16,
      minTimelineScale: 1,
      maxTimelineScale: 32
    },
    'day': {
      selected: false,
      columnWidth: 50,
      timelineScale: 16,
      minTimelineScale: 1,
      maxTimelineScale: 32
    },
    'weekly': {
      selected: false,
      columnWidth: 100,
      timelineScale: 16,
      minTimelineScale: 1,
      maxTimelineScale: 32
    },
    'init': {}
  };

  scheduleType = {
    'X': {
      defaultName: '',
      color: ''
    },
    'C':{
      defaultName: 'Changeover',
      color: ''
    },
    'M': {
      defaultName: 'Meal',
      color: ''
    },
    'T':{
      defaultName: 'Transit',
      color: ''
    },
    'B': {
      defaultName: 'Blockout',
      color: ''
    },
  }

  constructor(
    private schedulingService: SchedulingService,
    private cd: ChangeDetectorRef
  ) { 
    this.dataChangeSubject
    .subscribe(res=>{
      this.ganttChartNavigation.changeDate(res);
    });
  }

  ngOnInit(): void {

    this.initializeViewByNoOfWeek(this.timeline_weekly, 5);
    this.initializeViewByNoOfWeek(this.timeline_day, 2);
    this.initializeViewByNoOfDays(this.timeline_hourly, 2);

    this.schedulingService.getById(this.scheduleId)
    .subscribe(res=>{
      switch(this.viewBy){
        case 'machine':
          this.viewByMachine(res);
          break;
        case 'workorder':
          this.viewByWorkOrder(res);
          break;
      }
    });
  }

  viewByMachine(schedule: Schedule): void {
    this.populateScheduler({
      ...this.createScheduleViewByMachine(schedule.scheduleDetails),
      resourceToAdd: 'Machine'
    });
  }

  viewByWorkOrder(schedule: Schedule): void {
    this.populateScheduler({
      ...this.createScheduleViewByWorkOrder(schedule.scheduleDetails),
      resourceToAdd: 'Work Order'
    });
  }

  populateScheduler(
    data: { 
      x_axis: ScheduleVM[], 
      y_axis: {text: string, value: number}[], 
      resourceToAdd: string 
    }
  ) {
   
    const earliestStartDate = this.findEarliestStartDate(data.x_axis);
    const yAxisObject = this.createYAxis(data.resourceToAdd, data.y_axis);

    this.yAxis.subject.next([yAxisObject]);

    this.group.subject.next({
      ...this.group.subject.value,
      resources: [data.resourceToAdd]
    });

    this.cachedXAxisValues = data.x_axis;

    this.dataChangeSubject.next(earliestStartDate);
    //this.ganttChartNavigation.changeTimeline(this.getTimelineViewByName('init'));
  }
  
  createYAxis(
    resourceName: string, 
    data: {text: string, value: number}[]
  ){
    return {
      name: resourceName,
      data: data,
      field: "resourceId",
      valueField: "value",
      textField: "text",
      colorField: "color"
    };
  }

  initializeViewByNoOfDays(monthView: TimelineMonthViewComponent, numberOfDays: number): void {
    
    monthView.getStartDate = (selectedDate: Date): Date => getDate(selectedDate);
    monthView.getEndDate = (selectedDate: Date): Date => addDays(monthView.getStartDate(selectedDate), numberOfDays);
    monthView.getNextDate = (date: Date, count: number): Date => addDays(date, count * numberOfDays);
  }

  initializeViewByNoOfWeek(monthView: TimelineMonthViewComponent, numberOfWeeks: number): void {

    monthView.getStartDate = (selectedDate: Date): Date => selectedDate;
    monthView.getEndDate = (selectedDate: Date): Date => addWeeks(monthView.getStartDate(selectedDate), numberOfWeeks);
    monthView.getNextDate = (date: Date, count: number): Date => addWeeks(date, count * numberOfWeeks);
  }

  createScheduleViewByMachine(scheduleDetails: any[]): {
    y_axis: {text: string; value: number}[],
    x_axis: ScheduleVM[]
  } {

    if(!scheduleDetails || scheduleDetails.length<=0){
      return { x_axis: [], y_axis: [] };
    }

    scheduleDetails = 
      this.convertScheduleDetailDateStringToDateObjects(scheduleDetails);

    const schedulesByEquipmentId = 
      this.convertScheduleIntoScheduleVMForMachinesAndGroupByEquipmentId(scheduleDetails);

    this.cachedSchedulesById = schedulesByEquipmentId;

    const allScheduleVMs = Object.values(schedulesByEquipmentId)
      .reduce((prev, cur) => [...prev, ...cur], []);

    return {
      y_axis: this.getMachinesSortedByEarliestStartDate(scheduleDetails),
      x_axis: allScheduleVMs
    };
  }

  convertScheduleDetailDateStringToDateObjects(scheduleDetails: any[]){
    return scheduleDetails.map(scheduleDetail=>({
      ...scheduleDetail,
      startDate: new Date(scheduleDetail.startDate),
      endDate: new Date(scheduleDetail.endDate)
    }));
  }

  convertScheduleIntoScheduleVMForMachinesAndGroupByEquipmentId(scheduleDetails){

    const schedulesByEquipmentId: {[id:number]: ScheduleVM[]} = {};

    scheduleDetails.forEach(scheduleDetail=>{

      if(!schedulesByEquipmentId.hasOwnProperty(scheduleDetail.equipmentId)){
        schedulesByEquipmentId[scheduleDetail.equipmentId] = [];
      }

      const scheduleVM = this.createScheduleVMForMachinesFromScheduleDetail(scheduleDetail);

      schedulesByEquipmentId[scheduleDetail.equipmentId].push(scheduleVM);

    });

    return schedulesByEquipmentId;
  }

  convertScheduleIntoScheduleVMForWorkOrdersAndGroupByWorkOrderId(scheduleDetails){
    const schedulesByWorkOrderId: {[id:number]: ScheduleVM[]} = {};

    scheduleDetails.forEach(scheduleDetail=>{

      if(!schedulesByWorkOrderId.hasOwnProperty(scheduleDetail.workOrderId)){
        schedulesByWorkOrderId[scheduleDetail.workOrderId] = [];
      }

      const scheduleVM = this.createScheduleVMForWorkOrdersFromScheduleDetail(scheduleDetail);

      schedulesByWorkOrderId[scheduleDetail.workOrderId].push(scheduleVM);

    });

    return schedulesByWorkOrderId;
  }

  getMachinesSortedByEarliestStartDate(scheduleDetails): any[] {

    const equipmentIdStore: {[id: number]: any} = {}, machines: any[] = [];

    scheduleDetails.forEach(scheduleDetail=>{
      if(!equipmentIdStore.hasOwnProperty(scheduleDetail.equipmentId)){
        equipmentIdStore[scheduleDetail.equipmentId] = true;
        machines.push({
          text: scheduleDetail.equipmentName,
          value: scheduleDetail.equipmentId,
          earliestStartDate: scheduleDetail.startDate
        });
      }
      else {
        //Check & Change the Earliest Start Date so that we can sort all Machines by their Start Date 
        const machineIndex = machines.findIndex(machine=>machine.value === scheduleDetail.equipmentId);

        if(machines[machineIndex].earliestStartDate.getTime() > scheduleDetail.startDate.getTime()){
          machines[machineIndex].earliestStartDate = scheduleDetail.startDate;
        }
      }
    });

    return orderBy(machines, [{field: 'earliestStartDate', dir: 'asc'}]);
  }

  getWorkOrderSortedByEarliestStartDate(scheduleDetails): any[] {
    const workOrderIdStore: {[id: number]: any} = {}, workOrders: any[] = [];

    scheduleDetails.forEach(scheduleDetail=>{
      if(!workOrderIdStore.hasOwnProperty(scheduleDetail.workOrderId)){
        workOrderIdStore[scheduleDetail.workOrderId] = true;
        workOrders.push({
          text: scheduleDetail.workOrderNumber,
          value: scheduleDetail.workOrderId,
          earliestStartDate: scheduleDetail.startDate
        });
      }
      else {
        const workOrderIndex = workOrders.findIndex(wo=>wo.value === scheduleDetail.workOrderId);

        if(workOrders[workOrderIndex].earliestStartDate.getTime() > scheduleDetail.startDate.getTime()){
          workOrders[workOrderIndex].earliestStartDate = scheduleDetail.startDate;
        }
      }
    });

    return orderBy(workOrders, [{field: 'earliestStartDate', dir: 'asc'}]);
  }

  createScheduleVMForMachinesFromScheduleDetail(scheduleDetail: any): ScheduleVM {
    return {
      resourceId: scheduleDetail.equipmentId, 
      title: this.createMachineTooltipNameByScheduleType(scheduleDetail),   
      tooltip: {
        sequenceAndQuantity: `
          Sequence - ${scheduleDetail.sequence}\xA0
          Quantity - ${scheduleDetail.quantity}
        `,
        duration: `\xA0\xA0
          ${formatDate(scheduleDetail.startDate, 'G')} - 
          ${formatDate(scheduleDetail.endDate, 'G')}
        `,
        partName: `Part - ${scheduleDetail.itemName}`, 
        operation: ''
      },
      ...this.getDefaultScheduleVMProperties(scheduleDetail)
    };
  }

  createScheduleVMForWorkOrdersFromScheduleDetail(scheduleDetail: any): ScheduleVM {
    return {
      resourceId: scheduleDetail.workOrderId,
      title: this.createWorkOrderTooltipNameByScheduleType(scheduleDetail),
      tooltip: {
        sequenceAndQuantity: `
          Sequence - ${scheduleDetail.sequence}\xA0
          Quantity - ${scheduleDetail.quantity}
        `,
        duration: `\xA0\xA0
          ${formatDate(scheduleDetail.startDate, 'G')} - 
          ${formatDate(scheduleDetail.endDate, 'G')}
        `,
        partName: `Part - ${scheduleDetail.itemName}`, 
        operation: `Operation: ${scheduleDetail.operationName}`
      },
      ...this.getDefaultScheduleVMProperties(scheduleDetail)
    };
  }

  getDefaultScheduleVMProperties(scheduleDetail: any) {
    return {
      id: scheduleDetail.id,
      start: scheduleDetail.startDate,
      startTimezone: null,
      end: scheduleDetail.endDate,
      endTimezone: null, 
      isAllDay: false,
      scheduleType: scheduleDetail.scheduleType,
      color: this.allocateColorByScheduleType({ scheduleType: scheduleDetail.scheduleType })
    }
  }

  createMachineTooltipNameByScheduleType(scheduleDetail: any): string {

    const scheduleType = scheduleDetail.scheduleType

    if(scheduleType === 'X') return scheduleDetail.workOrderNumber;

    if(this.scheduleType.hasOwnProperty(scheduleType)){
      return this.scheduleType[scheduleType].defaultName;
    }

    return '';
  }

  createWorkOrderTooltipNameByScheduleType(scheduleDetail: any): string {
    const scheduleType = scheduleDetail.scheduleType

    if(scheduleType === 'X') return scheduleDetail.equipmentName;

    if(this.scheduleType.hasOwnProperty(scheduleType)){
      return this.scheduleType[scheduleType].defaultName;
    }

    return '';
  }

  createScheduleViewByWorkOrder(scheduleDetails: any[]): {
    y_axis: {text: string; value: number}[],
    x_axis: ScheduleVM[]
  } {

    if(!scheduleDetails || scheduleDetails.length<=0){
      return { x_axis: [], y_axis: [] };
    }

    scheduleDetails = 
      this.convertScheduleDetailDateStringToDateObjects(scheduleDetails);

    const schedulesByWorkOrderId = 
      this.convertScheduleIntoScheduleVMForWorkOrdersAndGroupByWorkOrderId(scheduleDetails);

    const allScheduleVMs = Object.values(schedulesByWorkOrderId)
      .reduce((prev, cur) => [...prev, ...cur], []);

    return {
      y_axis: this.getWorkOrderSortedByEarliestStartDate(scheduleDetails),
      x_axis: allScheduleVMs
    }
  }

  allocateColorByScheduleType(
    scheduleDetail: { scheduleType: string }
  ): string {

    let result: string;

    let existingColorsByScheduleType = 
      this.colorRecord.filter(record => record.scheduleType === scheduleDetail.scheduleType);

    if(existingColorsByScheduleType.length===0){
        
        result = this.generateNewRandomColor();

        this.colorRecord.unshift({
          scheduleType: scheduleDetail.scheduleType,
          color: result
        });
    }
    else {
      result = this.colorRecord
        .find(record => record.scheduleType === scheduleDetail.scheduleType).color;
    }

    return result;
  }

  generateNewRandomColor(): string {

    let color;
 
    do {
      color = `#${Math.floor(Math.random()*16777215).toString(16)}`;
    } while(this.colorRecord.filter(record => record.color === color).length>0);

    return color;
  }

  onDateChange(args: DateChangeEvent): void {
    
    let filteredXAxisData = 
      this.getFilteredXAxisByStartAndEndDate(args.dateRange.start, args.dateRange.end);

    if(!filteredXAxisData) return;
    
    filteredXAxisData = 
      orderBy(filteredXAxisData, [{field: 'start', dir: 'asc'}]);

    if(filteredXAxisData?.length>0){
      this.scrollTime.subject.next(filteredXAxisData[0].start);
    }

    this.endDate = addDays(args.dateRange.end, -1);
    this.xAxis.subject.next(filteredXAxisData);
    
    this.cd.detectChanges();

  }

  getFilteredXAxisByStartAndEndDate(startDate: Date, endDate: Date): ScheduleVM[] {
    return this.cachedXAxisValues?.filter(value=>(
      this.checkDateStartAndEndWithinBounds({
        xAxisObject: value, 
        startDate: startDate, 
        endDate: endDate
      })
    ));
  }

  checkDateStartAndEndWithinBounds(
    data: { xAxisObject: ScheduleVM,  startDate: Date,  endDate: Date }
  ) {

    try {
      return data.xAxisObject.start.getTime() >= data.startDate.getTime() && 
        data.xAxisObject.end.getTime() <= data.endDate.getTime();
    }
    catch(e){
      console.error(e, data);
      return false;
    }
  }

  changeTimelineView(view: 'hourly' | 'day' | 'weekly' | 'init'): void {

    if(!this.views.hasOwnProperty(view)) return;

    if(view !== 'init'){
      this.timelineScale.subject.next(this.views[view].timelineScale);
      this.columnWidth.subject.next(this.views[view].columnWidth);
      
      Object.keys(this.views)
        .filter(_view => _view !== view)
        .forEach(_view => {
          this.views[_view].selected = false;
        });

      this.views[view].selected = true; 
    }
    else {
      view = 'hourly';
    }
     
    this.ganttChartNavigation.changeTimeline(this[`timeline_${view}`]);

  }

  getNameOfSelectedTimelineView(): string {
    const views = Object.keys(this.views);
    for(let view in views) {
      const viewName = views[view];
      if(this.views[viewName].selected){
        return viewName;
      }
    }
  }

  getTimelineViewByName(viewName: string) {
    return this[`timeline_${this.getNameOfSelectedTimelineView()}`];
  }

  findEarliestStartDate(data: ScheduleVM[]): Date {

    let earliestDate: Date, date: Date;

    data.forEach(res=>{

      date = new Date(res.start);

      if(!earliestDate || date.getTime()<earliestDate.getTime()){
        earliestDate = date;
      }

    });

    return earliestDate ?? new Date();
  }

  doubleClickScheduleItem(dataItem: ScheduleVM): void {
    console.log(dataItem);
  }

  onClose(): void {
    this.closeWindow.emit(true);
  }

  ngDoCheck() {

  }

  ngOnDestroy(): void {
    this.closeWindow.unsubscribe();
  }

}
