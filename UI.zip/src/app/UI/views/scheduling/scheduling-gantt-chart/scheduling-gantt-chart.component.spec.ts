import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SchedulingGanttChartComponent } from './scheduling-gantt-chart.component';

describe('SchedulingGanttChartComponent', () => {
  let component: SchedulingGanttChartComponent;
  let fixture: ComponentFixture<SchedulingGanttChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SchedulingGanttChartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SchedulingGanttChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
