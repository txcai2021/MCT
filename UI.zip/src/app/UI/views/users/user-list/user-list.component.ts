import {Component, OnInit, ViewChild} from '@angular/core';
import {DataBindingDirective, EditEvent, RemoveEvent} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import {FormBuilder, FormGroup,  Validators} from '@angular/forms';
import {BehaviorSubject, Observable} from 'rxjs';
import {ToastService} from '@dis/services/message/toast.service';
import {CustomDialogService} from '@dis/services/message/custom-dialog.service';
import { AccountService, MenuService } from '@app/_services';
import { Menu, User } from '@app/_models';
import { KeycloakUserApiService } from '@app/_services/keycloak_user.service';
import { MustMatch } from '@app/_helpers/must-match.validator';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {

  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;

  gridDataSubject = new BehaviorSubject<User[]>([]);
  gridView = this.gridDataSubject.asObservable();

  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  editedRowIndex: number;

  public roles: { text: string; value: string; }[];
  public selectedRole: { text: string; value: string; };
  public phoneNumberValue: string = '';
  public phoneNumberMask: string = '0000-0000';

  public data: any = {
    username: '',
    roleID: 0,
    role: '',
    firstName: '',
    mobile: this.phoneNumberValue,
    email: '',
    comment: '',
    password: '',
    confirmPassword: ''
  };

  keyCloakClientData;
  keyCloakRealmRole;
  clientRoles;
  realmRoles;

  buttonsList: Menu[] = [];

  constructor(
    private toastr: ToastService, 
    private customDialog: CustomDialogService,
    private accountService: AccountService,
    private menuService: MenuService, 
    private keyckoakUserService: KeycloakUserApiService,
    private formBuilder: FormBuilder, 
    private route: ActivatedRoute
  ) {
        
    this.formGroup = this.formBuilder.group({
      username: [this.data.username, Validators.required],
      roleID:[this.data.roleID, Validators.required],
      firstName: [this.data.firstName, Validators.required],
      mobile: [this.data.mobile],
      email: [this.data.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")],
      comment: [this.data.comment],
      password: [this.data.password,[Validators.required,Validators.minLength(10)]],
      confirmPassword: [this.data.confirmPassword, [Validators.required]]
      },
      {
        validator: MustMatch('password','confirmPassword')
      }
    );    
  }

  onFilter(inputValue: string): void {

    const filters = ['loginId', 'firstName', 'mobile', 'email'].map(field=>({
      field: field,
      operator: 'contains',
      value: inputValue
    }));

    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: filters,
      }
    }).data;

    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }

  ngOnInit(): void {
    this.loadItems();
  }

  onAddNewClick(): void {
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
  }

  onEditClick(event: EditEvent): void {

    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;
   
    event.dataItem.password = "1234567890";
    event.dataItem.confirmPassword = "1234567890"
    this.formGroup.reset(event.dataItem);

    this.selectedRole = {
      value: event.dataItem.roleID,
      text: event.dataItem.roles
    }  
    this.editedRowIndex = event.rowIndex;

  }

  closeWindow(): void {
    this.isWindowOpened = false;
    this.formGroup.reset();
    this.mySelection = [];
  }

  submitWindow(item): void {

    this.isWindowOpened = false;

    if(!this.isNew){
      const items = this.gridDataSubject.value;
      item.id = items[this.editedRowIndex].id;
    }
    
    this.saveItem(item);
  }

  public saveItem(item) : void {

    if(!this.keyCloakClientData) return;
    if(!this.clientRoles) return;

    if (this.isNew) {

      this.formGroup.value.roleID = this.selectedRole.value;

      var clientRolesParam = []
      var selectedClientRoles = this.clientRoles.filter((cRole) => cRole.name == "rps-" + this.selectedRole.text.toLocaleLowerCase()) ?? "";
      
      if(selectedClientRoles?.length>0) { 
        clientRolesParam.push(selectedClientRoles[0]);
      }
      
      this.accountService
      .save(this.formGroup.value, clientRolesParam, this.keyCloakClientData.id, this.keyCloakRealmRole)
      .subscribe({
        next: () => {
          this.refreshUserGrid()
          this.resetForm()
          this.toastr.success('Your data has been saved sucessfully.');
        }
      });
    }
    else {

      let user: User = {
        ...item,
        roleID: item.roleID.value
      };
      
      var clientRolesParam = [];
      var selectedClientRoles = this.clientRoles.filter((cRole) => cRole.name == "rps-" + this.selectedRole.text.toLocaleLowerCase()) ?? "";
      
      if(selectedClientRoles) { 
        clientRolesParam.push(selectedClientRoles[0]);
      }

      this.accountService
        .update(user.id, user, clientRolesParam, this.keyCloakClientData.id, this.keyCloakRealmRole)
        .subscribe(() => {
            this.refreshUserGrid();
            this.resetForm();
            this.toastr.success('Your data has been updated sucessfully.');
          }
        );
    }
  }

  onDeleteClick(event: RemoveEvent ): void {
    this.editedRowIndex = event.rowIndex;
    this.customDialog.confirm().subscribe(res => {
      if (res.primary){
        this.removeItem();
      }
    });
  }



  removeItem(): void {

    const item = this.gridDataSubject.value[this.editedRowIndex];

    this.accountService
    .delete(item.id, item.username)
    .subscribe(res => {

        if(res) {
          this.toastr.success('Your data has been removed sucessfully.');
        }

        this.refreshUserGrid();
      }
    );
  }

   callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void {
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }

  loadItems() {
    this.refreshUserGrid(); 
    this.refreshRolesDropdownData();
    this.getAndSetKeyCloakClientRoles();
    this.getAndSetKeyCloakRealmRole();
  }

  refreshUserGrid(): void {
    this.accountService.getAll().subscribe((result) => {
      if(result) {
        result =  orderBy(result, [{ field: 'id', dir: 'desc' }]);
        this.gridDataSubject.next(result);
      }
    });
  }

  refreshRolesDropdownData(): void {
    this.menuService.getRole().subscribe((data) => {
      if(data) {
        this.roles  = data.map(res => ({
          text: res.name,
          value: res.roleId.toString()
        }));
      }
    });
  }

  getAndSetKeyCloakClientRoles(): void {
    this.keyckoakUserService.getClientData().subscribe(data => {
      if(data?.length>0) {
        this.keyCloakClientData = data[0];
        this.keyckoakUserService.getAllClientRoles(this.keyCloakClientData.id)
        .subscribe(res => {
          this.clientRoles = res;
        });
      }   
    });
  }

  getAndSetKeyCloakRealmRole(): void {
    this.keyckoakUserService.getRealmRoles().subscribe( data => {
      if(data) {
        this.keyCloakRealmRole = data.filter((cRole) => cRole.name == "app-admin");
        if(this.keyCloakRealmRole) {
          this.keyCloakRealmRole = this.keyCloakRealmRole[0];
        }
      }
    });
  }

  delay(ms: number) {
    return new Promise( resolve => setTimeout(resolve, ms) );
  }

  resetForm(){
    this.formGroup.reset();
  }

}
