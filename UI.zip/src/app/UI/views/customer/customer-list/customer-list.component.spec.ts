import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ComponentFixture, fakeAsync, flush, TestBed, waitForAsync } from '@angular/core/testing';

import { CustomerListComponent } from './customer-list.component';
import * as test_helper from '../../../_helpers/test_helper';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GridModule } from '@progress/kendo-angular-grid';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { LabelModule } from '@progress/kendo-angular-label';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { of } from 'rxjs';
import { ToastService } from '@dis/services/message/toast.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { CustomerService } from '@app/_services';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { ButtonsModule } from '@progress/kendo-angular-buttons';

describe('CustomerListComponent', () => {

    let component: CustomerListComponent;
    let fixture: ComponentFixture<CustomerListComponent>;
    let debugElement: DebugElement;

    let customerServiceDefaultReturnValueOfGetAll = [{

    }];

    let servicesAndMethods = {
        toastr: {
            class: ToastService,
            methods: {
                success: undefined,
                info: undefined
            }
        },
        customDialog: {
            class: CustomDialogService,
            methods: {
                confirm: of({
                    primary: true
                })
            }
        },
        customerService: {
            class: CustomerService,
            methods: {
                save: of({}),
                update: of({}),
                delete: of({}),
                getAll: of(customerServiceDefaultReturnValueOfGetAll)
            }
        }
    };

    let spies = Object.keys(servicesAndMethods)
        .reduce((prev, cur)=>({
        ...prev, 
        [cur]: jasmine.createSpyObj(
            typeof servicesAndMethods[cur].class, 
            Object.keys(servicesAndMethods[cur].methods)
        )
    }), {});

    let injectedServices: any;

    let testComponentReference = {
        component: component,
        fixture: fixture,
        debugElement: debugElement,
        customerServiceDefaultReturnValueOfGetAll: customerServiceDefaultReturnValueOfGetAll,
        servicesAndMethods: servicesAndMethods,
        spies: spies, 
        services: injectedServices
    };


    function defaultInitializeComponent(){
        return test_helper.initializeComponent({
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            declarations: [CustomerListComponent],
            imports: [
                FormsModule,
                ReactiveFormsModule,
                GridModule,
                DropDownsModule,
                InputsModule,
                LabelModule,
                LayoutModule,
                WindowModule,
                ButtonsModule,
                BrowserModule,
                BrowserAnimationsModule
            ],
            providers: Object.keys(servicesAndMethods).map(service => ({
                provide: servicesAndMethods[service].class,
                useValue: spies[service]
            }))
        });
    }


    function createFixture(){
        test_helper.createFixture.apply(testComponentReference, [CustomerListComponent]);
    }


    function defaultInjectServices(){
        test_helper.injectServices.apply(testComponentReference, [servicesAndMethods]);
    }


    function defaultResetFunctionCalls(){

        let arg = Object.keys(servicesAndMethods).reduce((prev, cur) =>  ({
            ...prev, 
            [cur]: Object.keys(servicesAndMethods[cur].methods).map(name=>({name: name}))
        }), {});

        test_helper.resetFunctionCalls.apply(testComponentReference, [arg]);
    }


    function setDefaultFunctionReturnValues(){

        let arg = Object.keys(servicesAndMethods).reduce((prev, cur) =>  ({
            ...prev, 
            [cur]: Object.keys(servicesAndMethods[cur].methods).map(name=>({
                name: name,
                value: servicesAndMethods[cur].methods[name]
            }))
        }), {});

        test_helper.setFunctionReturnValues.apply(testComponentReference, [arg]);
    }


    function defaultDescribeBeforeAndAfterEach(){
        beforeEach(waitForAsync(()=>{

            defaultInitializeComponent()
            .then(()=>{
              createFixture();
              defaultInjectServices();
              setDefaultFunctionReturnValues();
            });
  
          }));
      
          afterEach(defaultResetFunctionCalls);
    }


    describe('Initialize Component', ()=>{

        defaultDescribeBeforeAndAfterEach();
    
        it('should create', () => {
          expect(testComponentReference.component).toBeTruthy();
        });
        
    });

    describe('onAddNewClick', ()=>{

        defaultDescribeBeforeAndAfterEach();

        it('should open up the UI', ()=>{

        });

    });

    describe('onEditClick', ()=>{

    });

    describe('onFilter', ()=>{

    });

    describe('onImportClick', ()=>{

    });

    describe('onExportClick', ()=>{

    });

});