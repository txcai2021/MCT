import { Injectable } from "@angular/core";  
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";  
import { Observable } from "rxjs";  
import { Menu, User } from '@app/_models';
import { MenuService, AccountService } from '@app/_services';

@Injectable()
export class AssemblyResolve implements Resolve<Menu[]>  {
    user: User;
    constructor(private menuService: MenuService, private accountService: AccountService) {
        this.user = this.accountService.userValue;
    }

    resolve(route: ActivatedRouteSnapshot): Observable<Menu[]> {  
        return   this.menuService.getMenu(this.user.roles.toString(), "Product");
      } 

}