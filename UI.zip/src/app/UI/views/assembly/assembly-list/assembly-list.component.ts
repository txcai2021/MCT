import {Component, OnInit, ViewChild} from '@angular/core';
import {DataBindingDirective, EditEvent, GridComponent, RemoveEvent, SelectableSettings} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {BehaviorSubject, Observable} from 'rxjs';
import {ToastService} from '@dis/services/message/toast.service';
import {CustomDialogService} from '@dis/services/message/custom-dialog.service';
import { AssemblyService, CustomerService, PartsService, ProductService } from '@app/_services';
import { first } from 'rxjs/operators';
import { Assembly, Menu, Parts } from '@app/_models';
import { ActivatedRoute } from '@angular/router';
import { ListFilterHelper } from '../../../_helpers';

import * as _ from 'lodash';

const createFormGroup = (dataItem) =>
new FormGroup({
    name: new FormControl(dataItem.name),
    revision: new FormControl(dataItem.revision),
    Quantity: new FormControl(dataItem.Quantity,  Validators.compose([Validators.required, Validators.pattern('^[0-9]{1,3}')])),
    Description: new FormControl(dataItem.Description),
});

const is = (fileName: string, ext: string) =>
new RegExp(`.${ext}\$`).test(fileName);


@Component({
  selector: 'app-assembly-list',
  templateUrl: './assembly-list.component.html',
  styleUrls: ['./assembly-list.component.scss']
})
export class AssemblyListComponent implements OnInit {

  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;

  gridDataSubject = new BehaviorSubject<Assembly[]>([]);
  gridView : Observable<Assembly[]> = this.gridDataSubject.asObservable();

  public selectableSettings: SelectableSettings = {
    mode: "single"
  };

  mySelection: string[] = [];

  isWindowOpened = false;
  isDialogOpen = false;
  isHierarchyOpened = false;
  isNew = false;
  formGroup: FormGroup;
  selectedPartsFormGroup: FormGroup;
  editedRowIndex: number;

  selectedRowIndex: number;

  buttonsList: Menu[] = [];
 
  public treeNodes: any[] = [];
  public expandedKeys: any[] = [];
  //public selectedSaleOrderLines :  Parts[] = [];

  public availablePartsGrid: any[] = [] ;
  public selectedPartsGrid: any[]= [] ;

  public customerList: Array<{ text: string; value: number }>;

  public partFamilies: Array<{ text: string }>;
  partFamilyFilter: ListFilterHelper<{ text: string }>;

  fgDimensions: string[];
  fgDimensionFilter: ListFilterHelper<string>;
 
  @ViewChild(GridComponent)
  private grid: GridComponent;

  defaultData: any = {
    name: '',
    description: '',
    revision: '',
    partFamily: '',
    customerId: 0,
    thumbnailImageFileName: '',
    remarks: '',
    fgDimension: '',
    qtyPerLot: 0,
    productionYield: 0,
    priority: 1,
    unitofMeasure: '',
    buyFlag: false,
    inactive: false,
    availableParts: ''
  };

  public data: any = _.cloneDeep(this.defaultData);

  isInEditMode = false;

  assignRawMaterialWindowProductIdSubject = new BehaviorSubject<number>(-1);
  assignRawMaterialWindowProductId$ = this.assignRawMaterialWindowProductIdSubject.asObservable();
  openAssignRawMaterialWindowSubject = new BehaviorSubject<boolean>(false);
  openAssignRawMaterialWindow$ = this.openAssignRawMaterialWindowSubject.asObservable();

  constructor(
    private toastr: ToastService, 
    private customDialog: CustomDialogService, 
    private assemblyService: AssemblyService,
    private partService: PartsService,
    private customerService: CustomerService,
    private productService: ProductService,
    private route: ActivatedRoute
  ) {

        this.formGroup = new FormGroup({
          name: new FormControl(this.data.name, Validators.required),
          description: new FormControl(this.data.description, Validators.required),
          revision: new FormControl(this.data.revision),
          partFamily: new FormControl(this.data.partFamily),
          customerId: new FormControl(this.data.customerId),
          thumbnailImageFileName: new FormControl(this.data.thumbnailImageFileName),
          remarks: new FormControl(this.data.remarks),
          fgDimension: new FormControl(this.data.fgDimension),
          qtyPerLot: new FormControl(this.data.qtyPerLot),
          productionYield: new FormControl(this.data.productionYield),
          priority: new FormControl(this.data.priority),
          unitofMeasure: new FormControl(this.data.unitofMeasure),
          buyFlag: new FormControl(this.data.buyFlag),
          inactive: new FormControl(this.data.inactive),
          availableParts: new FormControl(this.data.availableParts),
        });

        this.fgDimensionFilter = new ListFilterHelper<string>({
          findIndexStrategy: filterWord => (word => word === filterWord),
          filterStrategy: (cachedWordList, filterWord) => 
            cachedWordList.filter(word => {
              const text = word?.toLowerCase();
              const input = filterWord?.toLowerCase();
              return text?.includes(input);
            })
        });

        this.partFamilyFilter = new ListFilterHelper<{ text: string }>({
          findIndexStrategy: filterWord => (wordObj => wordObj?.text === filterWord),
          filterStrategy: (cachedWordObjList, filterWordObj) =>
            cachedWordObjList.filter(wordObj => {
              const text = wordObj?.text?.toLowerCase();
              const input = filterWordObj?.text?.toLowerCase();
              return text?.includes(input);
            })
        });
    
     }


  onFilter(inputValue: string): void {
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          }
        ],
      },
    }).data;

    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }



  ngOnInit(): void {
    this.loadItems();
  }

  onAddNewClick(): void {
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
  }

  onEditClick(event: EditEvent): void {
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;
    this.formGroup.reset(event.dataItem);
    this.editedRowIndex = event.rowIndex;

    this.selectedPartsGrid = event.dataItem.components;

    let customerId = this.formGroup.value.customerId;
    if(!customerId) customerId = 0;
    let emptyStr: String = "%20";

    this.partService.getAllComponents(customerId,emptyStr).subscribe((result) => {
      if(result) result =  orderBy(result, [{ field: 'id', dir: 'desc' }]);
      this.availablePartsGrid = result;

      this.selectedPartsGrid.forEach(element => {
        var removeIndex = this.availablePartsGrid.map(function(item) { return item.id; }).indexOf(element.id);
        this.availablePartsGrid.splice(removeIndex,1);
      });

     
    });

  //  console.log(event.dataItem);
  }

  closeWindow(window: 'form' | 'assignRawMaterial'): void {
    switch(window){
      case 'form':
        this.resetForm();
        this.isWindowOpened = false;
        break;
      case 'assignRawMaterial':
        this.openAssignRawMaterialWindowSubject.next(false);
        break;
    }  
  }

  submitWindow(item): void {

    this.isWindowOpened = false;

    if(!this.isNew){
      const items = this.gridDataSubject.value;
      item.id = items[this.editedRowIndex].id;
    }

    item.components =  this.selectedPartsGrid;

    this.saveItem(item);
  }

  public saveItem(item) : void {

    if (this.isNew) {
      this.assemblyService
        .save(this.formGroup.value, item.components)
        .pipe(first())
        .subscribe({
          next: () => {
            this.resetForm();
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {
          
          },
        });
    }
    else {

      let data: Assembly = item;
      data.id = item.id;

      this.assemblyService
        .update(item.id, data)
        .pipe(first())
        .subscribe({
          next: () => {
            this.resetForm();
            this.loadItems();
            this.toastr.success('Your data has been updated sucessfully.');
          },
          error: (error) => {
          },
        });
    }
  }

  onDeleteClick(event: RemoveEvent ): void {
    this.editedRowIndex = event.rowIndex;
    this.customDialog.confirm().subscribe(res => {
      // Primary (Yes) button is clicked
      if (res.primary){
          this.removeItem();
      }
    });
  }



  removeItem(): void {
    // do you processing and close window
    let items = this.gridDataSubject.value;

    // success should be in resolve of subscribe method
    this.assemblyService
      .delete(items[this.editedRowIndex].id)
      .pipe(first())
      .subscribe({
        next: () => {
          this.gridDataSubject.next(items);
          this.toastr.success('Your data has been removed sucessfully.');
        },
        error: (error) => {},
      });

      
    items.splice(this.editedRowIndex, 1);

    // array isnt updating
    // Retrieve backend data to update
    const temp = [...items];
    // noinspection JSUnusedAssignment
    items = [];
    items = [...temp];

    

  }

   callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void{
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.name}`);
  }

  loadItems() {

    this.assemblyService.getAll().subscribe((result) => {
      if(result) {
        result =  orderBy(result, [{ field: 'id', dir: 'desc' }]);
        this.gridDataSubject.next(result);
      }
    });

    this.productService.getAssemblyPartFamilies().subscribe((data) => {
      if(!data) {
        this.partFamilies = this.partFamilyFilter.cachedWordList = [];
        return;
      }
      this.partFamilyFilter.cachedWordList = data.map(res=>({ text: res }));
      this.partFamilies = this.partFamilyFilter.cachedWordList;
    });

    this.customerService.getAll().subscribe((data) => {
      if(data) {
        this.customerList  = data.map(res => ({
          text: res.name,
          value: res.id
        }));
      }
    });

    this.productService.getFGDimensions().subscribe((data) => {
      if(!data) return;
      this.fgDimensions = this.fgDimensionFilter.cachedWordList = data;
    });

  }

  public onSearchAvailableParts() {

    let customerId = this.formGroup.value.customerId;
    if(!customerId) customerId = 0;
    let emptyStr: String = "%20";

    this.partService.getAllComponents(customerId,emptyStr).subscribe((result) => {
      if(result) result =  orderBy(result, [{ field: 'id', dir: 'desc' }]);
      this.availablePartsGrid = result;
    });
  }

  onGridAddClick(dataItem): void{
    // Do some action with view
    var removeIndex = this.availablePartsGrid.map(function(item) { return item.id; }).indexOf(dataItem.id);
    this.availablePartsGrid.splice(removeIndex,1);

    var temp = { id: 0, productAssemblyId: 0, componentId: dataItem.id,uomCode: '',bomLevel: 0,  perAssemblyQuantity: 1,productName: dataItem.name, remarks: '', sequence: this.selectedPartsGrid.length, description: dataItem.description  };
    this.selectedPartsGrid.push(temp);
  
  }

  onGridDeleteClick(dataItem): void{
    // Do some action with view
    var removeIndex = this.selectedPartsGrid.map(function(item) { return item.id; }).indexOf(dataItem.id);
    this.selectedPartsGrid.splice(removeIndex,1);
   
    this.availablePartsGrid.push(dataItem);
    this.availablePartsGrid =  orderBy(this.availablePartsGrid, [{ field: 'id', dir: 'desc' }]);
  
  }



  public cellClickHandler({ isEdited, dataItem, rowIndex }): void {

    console.log("Cell on click");
   this.isInEditMode = true;
  }


  public cellCloseHandler(args: any) {
    this.isInEditMode = false;
  }

  resetForm(){
    this.formGroup.reset(this.defaultData);
    this.selectedPartsGrid = [];
    this.availablePartsGrid = [];
  }

  openProductHierarchy(){
    this.isHierarchyOpened = true

    if(this.selectedRowIndex) {

      const items = this.gridDataSubject.value;
      let dataItem = items.filter(item=> item.id === this.selectedRowIndex)[0];

      const text = `${dataItem.name} / ${dataItem.description}`;

      this.getAssemblyBOMFromAPIAndCreateBOMTree(text);
      
    }

  }

  getAssemblyBOMFromAPIAndCreateBOMTree(assemblyName: string): void {

    let root = {
      text: assemblyName,
      items: [],
      type: "assembly"
    }

    this.expandedKeys.push(assemblyName);

    this.assemblyService.getBillOfMaterialsbyAssemblyId(this.selectedRowIndex).subscribe((result) => {

      this.traverseAndTransformBOMTreeNodes(result);

      root.items.push(...result);
      this.treeNodes.push(root);

      this.expandedKeys = this.expandedKeys.slice();
      this.treeNodes = this.treeNodes.slice();

    });
  }

  traverseAndTransformBOMTreeNodes(BOMTree): void {

    let queue = [...BOMTree];

    while(queue.length>0){
      let node = queue.shift();
      this.mutateBOMNodeByCategory(node);
      if(node.items?.length>0){
        queue = [...queue, ...node.items];
      }
    }
  }

  mutateBOMNodeByCategory(node){

    if(!node) return;

    const text = `${node.productName} (x${node.perAssemblyQuantity})`;

    switch(node.category){
      case 'ProductHierarchyLevelR':
        node.items = node.components ?? [];
        node.text = text;
        node.type = 'assembly';
        break;
      case 'ProductHierarchyLevelB':
        node.items = node.components ?? [];
        node.text = text;
        node.type = 'parts';
        break;
      case 'RawMaterial':
        node.text = text;
        node.type = 'rawMat';
        break;
    }

    delete node.components;
  }

  closeProductHierarchy() {
    this.isHierarchyOpened = false;
    this.treeNodes = []
    this.expandedKeys = []
    this.selectedRowIndex = undefined
    this.mySelection = []
  }

  selectedKeysChange(rows: number[]) {
     if(rows.length != 0) {
      this.selectedRowIndex = rows[0];
     }
  }

  public iconClass({ text, type, items  }: any): any {
    return {

      "assembly": type === "assembly",
      "parts": type === "parts",
      "rawMat": type === "rawMat",
      "k-icon": true,
    };
  }

  onAssignRawMaterialClick(): void {
    this.assignRawMaterialWindowProductIdSubject.next(parseInt(this.mySelection[0]));
    this.openAssignRawMaterialWindowSubject.next(true);
  }

  addNewPartFamily(): void {
    if(!this.partFamilyFilter.tryAddWordToCache()) return;
    this.partFamilies = this.partFamilyFilter.cachedWordList;
  }

  addNewFgDimension(): void {
    if(!this.fgDimensionFilter.tryAddWordToCache()) return;
    this.fgDimensions = this.fgDimensionFilter.cachedWordList;
  }

  handleFilter(filterFor: 'partFamily'|'fgDimension', filter: string): void {
    switch(filterFor){
      case 'partFamily':
        this.partFamilies = this.partFamilyFilter.getFilterdArray({ text: filter });
        break;
      case 'fgDimension':
        this.fgDimensions = this.fgDimensionFilter.getFilterdArray(filter);
        break;
    }
  }
}
