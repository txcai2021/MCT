import { Component, OnInit, OnDestroy, EventEmitter, Output, Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { SaleOrder, SaleOrderLines, WorkOrderCreation } from '@app/_models';
import { ProductService, SaleOrderService, WorkOrderService } from '@app/_services';
import { BehaviorSubject, forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import * as _ from 'lodash';
import { AuthKeycloakService } from '@dis/auth/auth-keycloak.service';

interface WorkOrderSalesOrderLineModel {
  index: number;
  salesOrderLine: SaleOrderLines;
  workOrderQuantity: number;
}

interface SalesOrderDetails {
  customerId: number;
  customerName: string;
  orderDate: Date;
  salesPersonName: string;
  contactPersonName: string;
  contactNo: string;
  purchaseOrderNumber: string;
  comment: string;
  salesOrderLines: WorkOrderSalesOrderLineModel[]
}

@Component({
  selector: '[app-create-work-order]',
  templateUrl: './create-work-order.component.html',
  styleUrls: ['./create-work-order.component.scss']
})
export class CreateWorkOrderComponent implements OnInit, OnDestroy {

  data: SalesOrderDetails = {
    customerId: -1,
    customerName: "",
    orderDate: new Date(),
    salesPersonName: "",
    contactPersonName: "",
    contactNo: "",
    purchaseOrderNumber: "",
    comment: "",
    salesOrderLines: new Array<WorkOrderSalesOrderLineModel>()
  };

  formGroup: FormGroup;

  gridDataSubject = new BehaviorSubject<WorkOrderSalesOrderLineModel[]>([]);
  gridView = this.gridDataSubject.asObservable();

  gridViewSelection: number[] = [];

  @Input() salesOrderId: number = -1;
  @Output() closeWindow = new EventEmitter<boolean>(false);

  constructor(
    private saleOrderService: SaleOrderService, 
    private productService: ProductService,
    private workOrderService: WorkOrderService,
    private _keycloakAuth: AuthKeycloakService,
  ) { 

    const formData = _.omit(this.data, ['salesOrderLines']);
    const formDataKeys = Object.keys(formData);
    
    const propertiesToDisable = formDataKeys.filter(property=>property!='customerId');

    const formControls = formDataKeys
      .reduce((prev, cur)=>{

        let formControlObject: any =  { value: this.data[cur] };
        
        if(propertiesToDisable.includes(cur))
          formControlObject = { ...formControlObject, disabled: true }; 

        return {
          ...prev, 
          ...{ [cur]: new FormControl(...[ formControlObject, Validators.required ]) }
        }
      }, {});

    this.formGroup = new FormGroup(formControls);
  }

  ngOnInit(): void {
    this.refreshGridView();
  }

  onCreateAllWOButtonClick(): void {
    if(this.gridViewSelection.length>0){
      const selectedSalesOrderLines: WorkOrderSalesOrderLineModel[] = [];

      this.gridViewSelection.forEach(index=>{
        selectedSalesOrderLines.push(this.gridDataSubject.value[index]);
      });

      this._keycloakAuth.getUserDetails()
        .then(user=>{

          const woCreation = this.createWorkOrderCreationFromWorkOrderSalesOrderLineModels(
            selectedSalesOrderLines, 
            user.id
          );

          this.workOrderService
            .generateWorkOrder(woCreation)
            .subscribe(res=>{
              if(res)
                console.log("Work order was generated successfully", res);
              this.gridViewSelection = [];
              this.refreshGridView();
            });

        }).catch((err)=>{
          console.error('Error in onCreateAllWOButtonClick Promise', err);
        });

    }
  }

  createWorkOrderCreationFromWorkOrderSalesOrderLineModels(
    woSalesOrderLineModels: WorkOrderSalesOrderLineModel[],
    requestedBy: string
  ): WorkOrderCreation {

    return {
      salesOrderId: this.salesOrderId,
      customerId: this.formGroup.get("customerId").value,
      requestedBy: requestedBy,
      details: woSalesOrderLineModels
        .map(woSalesOrderLine=>{
          return {
            salesOrderDetailId: woSalesOrderLine.salesOrderLine.id,
            quantity: woSalesOrderLine.workOrderQuantity
          };
        })
    };
  }

  refreshGridView(): void {

    if(this.salesOrderId != -1){

      this.saleOrderService.getById(this.salesOrderId)
        .subscribe(res=>{

          const salesOrders = res;
          
          const relevantFormDataKeysInSalesOrderDetails = 
            Object.keys(salesOrders).filter(key => key!=="salesOrderLines");

          const salesOrderDetails = 
            this.createSalesOrderDetailsObjectUsingFormControlNames(
              relevantFormDataKeysInSalesOrderDetails,
              salesOrders
            );
            
          this.formGroup.reset(salesOrderDetails);

          salesOrderDetails.salesOrderLines = 
            this.appendAndReturnWOSalesOrderLinesWithAdditionalInfo(
              this.convertSalesOrderLinesToWOSalesOrderLineModel(salesOrders.salesOrderLines)
            );

          this.data.salesOrderLines = salesOrderDetails.salesOrderLines;
          this.gridDataSubject.next(this.data.salesOrderLines);

        });
    }
  }

  createSalesOrderDetailsObjectUsingFormControlNames(
    controlNames: string[], 
    salesOrders: SaleOrder
  ): SalesOrderDetails {

    const salesOrderDetails = controlNames.reduce((prev, cur)=>({
        ...prev, [cur]:salesOrders[cur]
      }), {}) as SalesOrderDetails;

    if(salesOrderDetails.orderDate)
      salesOrderDetails.orderDate = new Date(salesOrderDetails.orderDate);

    return salesOrderDetails;
  }

  convertSalesOrderLinesToWOSalesOrderLineModel(
    salesOrderLines: SaleOrderLines[]
  ): WorkOrderSalesOrderLineModel[] {

    return salesOrderLines.map(salesOrderLine=>{
      return {
        salesOrderLine: salesOrderLine,
        workOrderQuantity: 
          salesOrderLine.balanceQuantity >= 0 ? salesOrderLine.balanceQuantity : 0,
      } as WorkOrderSalesOrderLineModel;
    });

  }

  appendAndReturnWOSalesOrderLinesWithAdditionalInfo(
    workOrderSalesOrderLines: WorkOrderSalesOrderLineModel[]): WorkOrderSalesOrderLineModel[] {
      let index = 0;
      return workOrderSalesOrderLines
          .map(woSalesOrderLine=>{
              woSalesOrderLine.index = index++;
              return woSalesOrderLine;
          });
  }

  getProductListDictionaryObservable(): Observable<{[key: number]: { name: string; description: string; }}> 
  {
    return this.productService.getProductListWithRouting()
    .pipe(
      map(res=>{
        return res.reduce((cur, prev)=>{
          return {
            ...cur,
            ...{
                  [prev.id]: {
                    name: prev.name,
                    description: prev.description,
                    lotSize: prev.lotSize
                  }
                }
          }
        }, {});
      })
    )
  }

  onWOQuantityChange(rowIndex: number, input: string): void {
    const getIntegerValue = parseInt(input);
    if(getIntegerValue)
      this.data.salesOrderLines[rowIndex].workOrderQuantity = getIntegerValue;
  }

  onCancelClick(): void {
    this.closeWindow.emit(true);
  }

  onClose(): void {
    this.closeWindow.emit(true);
  }

  ngOnDestroy(): void {
    this.closeWindow.unsubscribe();
  }

  disableCheckbox(checkInput: any): boolean {
    const convertInputToInteger = parseInt(checkInput);
    const result = !(convertInputToInteger>0);
    return result;
  }
}
