import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { DataBindingDirective, EditEvent, RemoveEvent, RowClassArgs } from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, forkJoin, Observable } from 'rxjs';
import { ToastService } from '@dis/services/message/toast.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { AssemblyService, CustomerService, PartsService, SaleOrderService, SettingsService } from '@app/_services';
import { first, map } from 'rxjs/operators';
import { DropdownModel, SaleOrder, SaleOrderLines, SaleOrderLinesStatus } from '@app/_models';
import { DialogService } from '@progress/kendo-angular-dialog';
import { addDays } from "@progress/kendo-date-math";

import * as _ from 'lodash';
import { SalesOrderLineStatusPipe } from '@app/_helpers';

@Component({
  selector: 'app-sale-order-list',
  templateUrl: './sale-order-list.component.html',
  styleUrls: ['./sale-order-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SaleOrderListComponent implements OnInit {

  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;

  gridDataSubject: BehaviorSubject<SaleOrder[]> = new BehaviorSubject<SaleOrder[]>([]);
  gridView : Observable<SaleOrder[]> = this.gridDataSubject.asObservable();

  mySelection: string[] = [];
  public extractDataItems;

  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  
  isEditSaleOrderLine = false;
  formGroup: FormGroup;
  saleOrderFormGroup: FormGroup;

  editedRowIndex: number;
  editedSaleOrderLinesRowIndex: number;

  customerNameModel: any;
  customerCodeModel: any;

  assemblyNameModel: DropdownModel;
  assemblyCodeModel: DropdownModel;

  partNameModel: DropdownModel;
  partNumberModel: DropdownModel;

  public availablePartsData: any[];
  public availablePartsGridView: any[];

  public customerList;
  public partFamilies: Array<{ text: string; value: number; code: string }>;
  public assemblyFamilies;

  public saleOrderLines : SaleOrderLines[] = [];
  public gridData: SaleOrderLines[] = [];

  public priorityItems: Array<string> = ["Standard", "Urgent", "Very Urgent"];
  public selectedPriority = "Standard";

  showCreateWOWindow = new BehaviorSubject<boolean>(false);
  showCreateWOWindow$ = this.showCreateWOWindow.asObservable();
  createWOWindowSalesOrderIdParam: number;
  
  public defaultData = {
    customerId: 0,
    customerName: '',
    purchaseOrderNumber: '',
    orderDate: new Date(),
    contactPersonName: '',
    contactNo: '',
    salesPersonName: '',
    billingNo: '',
    comment: '',
    salesOrderNumber: '',
    dueDate: new Date()
  };

  public data: any = _.cloneDeep(this.defaultData);

  public defaultSaleOrderData = {
    id: -1,
    salesOrderId: -1,
    productId: -1,
    assemblyNo: undefined,
    assemblyName: undefined,
    partNumber: undefined,
    partName: undefined,
    revision: '',
    quantity: 1,
    uom: '',
    unitPrice: 0,
    currency: 'SGD',
    dueDate: new Date(),
    lineNumber: 1,
    urgentFlag: this.priorityItems[0],
    remarks: '',
    status: SaleOrderLinesStatus.Pending
  };

  public saleOrderData = _.cloneDeep(this.defaultSaleOrderData);

  formatGridRowClass = (context: RowClassArgs) => {
    return this.formatClass.apply(this, [context.dataItem]);
  }

  formatClass(dataItem) {
    if(dataItem.orderType === 2){
      return {
        'sales-order-list-scrap-order': true,
      };
    }
  }

  constructor(
    private toastr: ToastService, 
    private customDialog: CustomDialogService,
    private customerService: CustomerService,
    private partService: PartsService,
    private assemblyService: AssemblyService,
    private saleOrderService: SaleOrderService,
    private dialogService: DialogService,
    private settingsService: SettingsService
  ) {

    this.initializeFormGroup();
    
  }

  initializeFormGroup(): void {

    const nestedGridItems = Object.keys(this.defaultSaleOrderData)
      .reduce((prev, cur)=>{       
        const formcontrol = [this.data[cur]];
        return { ...prev, [cur]: new FormControl(...formcontrol) };     
    }, {});

    const formGroupControls = Object.keys(this.defaultData)
      .reduce((prev, cur)=>({
        ...prev, [cur]: new FormControl(this.data[cur])
    }), {});

    this.formGroup = new FormGroup({
      ...formGroupControls,
      nestedGridItems: new FormGroup(nestedGridItems)
    });
  }

  salesOrderLineFormGroupIsValid(): boolean {

    const formGroup = this.formGroup.getRawValue();
    const nestedFormGroup = formGroup.nestedGridItems;

    const noAssemblyExtraCondition = 
      nestedFormGroup.assemblyNo?.value <= 0 ? nestedFormGroup.partNumber : true;

    const condition = (
      formGroup.orderDate &&
      nestedFormGroup.assemblyNo && 
      nestedFormGroup.assemblyName &&
      nestedFormGroup.lineNumber &&
      nestedFormGroup.quantity && 
      noAssemblyExtraCondition
    );

    return condition;
  }

  checkDeliveryDateMoreThanReceivedDate(): boolean {

    const formGroup = this.formGroup.getRawValue();
    const nestedFormGroup = formGroup.nestedGridItems;

    return (
      nestedFormGroup?.dueDate?.getTime() > 
      formGroup?.orderDate?.getTime()
    );
  }

  onFilter(inputValue: string): void {
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          }
        ],
      },
    }).data;

    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }

  ngOnInit(): void {

    this.loadItems();

    this.customerService.loadCustomerDropdownData()
    .subscribe(data => {
      this.customerList = data;
    });

    this.populateAssemblyDropdown();

    this.settingsService.getSettingsByName('LT_External')
    .subscribe(res=>{

      if(!res) return;

      let daysToAdd = parseInt(res.defaultSetting);

      if(isNaN(daysToAdd)){
        daysToAdd = 0;
      }

      this.defaultSaleOrderData.dueDate = addDays(new Date(), daysToAdd); 

    });
  }

  populateAssemblyDropdown(): void {
    this.assemblyService.loadDropdownData().subscribe(data => {

      const addNoneOption = {
        text: 'None',
        code: 'None',
        value: 0
      };

      this.assemblyFamilies = [...data, addNoneOption];

    });
  }

  populatePartsDropdownByAssemblyDropdownSelection(assemblyOption: {value: number}) {

    if(!assemblyOption || assemblyOption?.value < 0) return;

    this.partNameModel = this.partNumberModel = undefined;

    const transformPartsToDropdownModel = 
      map((data: any[]) => data.map(res=>({
        text: (res.description?.length>0) ? res.description : res.name,
        value: res.id,
        code: res.name
      })));

    let parts$;

    switch(assemblyOption.value){
      case 0:
        parts$ = this.partService.getIndependentParts(this.customerCodeModel)
        .pipe(transformPartsToDropdownModel)
        break;
      default:
        parts$ = this.partService.getPartsByAssemblyId(assemblyOption.value)
        .pipe(transformPartsToDropdownModel)
    }

    return parts$;
  }

  onAddNewClick(): void {
    this.isWindowOpened = !this.isWindowOpened;
    this.resetForm();
    this.isNew = true;
  }

  onEditClick(event: EditEvent): void {
    if(event.dataItem) {

      this.isWindowOpened = !this.isWindowOpened;
      this.isNew = false;

      if(event.dataItem.customerId) {
        this.customerCodeModel = event.dataItem.customerId;
        this.customerNameModel = event.dataItem.customerName;
      }

      if(event.dataItem.orderDate) {
        event.dataItem.orderDate = new Date(event.dataItem.orderDate);
      }

      if(event.dataItem.salesOrderLines){

        forkJoin([
          this.partService.loadDropdownData()
        ])
        .pipe(map(res=>({ 
            parts: res[0] 
          })
        ))
        .subscribe(res=>{
          this.saleOrderLines = event.dataItem.salesOrderLines.map(salesOrderLine=>{
            const part = res.parts.filter(part=>part.value==salesOrderLine.productId);
  
            if(part.length>0){
              salesOrderLine.productName = part[0].text;
              salesOrderLine.productNo = part[0].code;
            }
  
            return salesOrderLine;
  
          });
  
          this.gridData = this.saleOrderLines;
        });
      }

      this.formGroup.reset(event.dataItem);
      this.formGroup.get('nestedGridItems').reset(this.defaultSaleOrderData);

      this.editedRowIndex = event.rowIndex;
    }
  }

  

  closeWindow(window: 'form' | 'createWO'): void {
    
    switch(window){
      case 'form':
        this.isWindowOpened = false;
        this.resetForm();
        break;
      case 'createWO':
        this.showCreateWOWindow.next(false);
        break;
    }
  }

  submitWindow(item): void {

    if(this.saleOrderLines.length == 0) 
      return;

    this.isWindowOpened = false;

    if(!this.isNew){
      const items = this.gridDataSubject.value;
      item.id = items[this.editedRowIndex].id;
    }

    this.saveItem(item);
  }

  public saveItem(item) : void {

    this.formGroup.value.salesOrderNumber = this.formGroup.value.purchaseOrderNumber;

    if(this.saleOrderLines.length != 0) {
       let maxDateItem = this.saleOrderLines.reduce((a, b) => {
        return new Date(a.dueDate) > new Date(b.dueDate) ? a : b;
      });

      this.formGroup.value.dueDate = maxDateItem.dueDate;
    }
    
    this.formGroup.value.salesOrderLines = this.saleOrderLines.map(saleOrderLine=>{
      if(saleOrderLine.id == -1) delete saleOrderLine.id;
      if(saleOrderLine.salesOrderId == -1) delete saleOrderLine.salesOrderId;

      const urgentFlag = this.priorityItems.indexOf(saleOrderLine.urgentFlag);
      saleOrderLine.urgentFlag = urgentFlag > -1 ? urgentFlag : 0;

      return saleOrderLine;
    });

    let items = this.formGroup.value;
    delete items.nestedGridItems;
   
    if (this.isNew) {
      this.addNewSalesOrderToDB(items);
    }
    else {

      let data: SaleOrder = {
        ...item,
        id: item.id,
        salesOrderNumber: item.purchaseOrderNumber
      };

      this.updateExistingSalesOrderToDB(data);
    }
  }

  addNewSalesOrderToDB(items): void {
    this.saleOrderService
        .save(items)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
  }

  updateExistingSalesOrderToDB(data): void {
    this.saleOrderService
        .update(data)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been updated sucessfully.');
          },
          error: (error) => {},
        });
  }

  onDeleteClick(event: RemoveEvent ): void {
    this.editedRowIndex = event.rowIndex;
    this.customDialog.confirm().subscribe(res => {
      if (res.primary){
        this.removeItem();
      }
    });
  }


  removeItem(): void {
    let items = this.gridDataSubject.value;
    
    this.saleOrderService
      .delete(items[this.editedRowIndex].id)
      .pipe(first())
      .subscribe({
        next: () => {
          items.splice(this.editedRowIndex, 1);
          this.gridDataSubject.next([...items]);
          this.toastr.success('Your data has been removed sucessfully.');
        },
        error: (error) => {},
      });
  }

   callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void{
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }

  loadItems() {
    this.saleOrderService.getAll()
    .subscribe((result) => {
      if(result) {
        result =  orderBy(result, [{ field: 'id', dir: 'desc' }]);
        result = result.map(res=>({
          ...res,
          salesOrderLines: res.salesOrderLines.map(soLine => ({ 
            ...soLine, 
            urgentFlag: this.priorityItems[soLine.urgentFlag] 
          })),
          status: this.getUniqueSalesOrderLineStatus(res.salesOrderLines).join('; ')
        }));
        this.gridDataSubject.next(result);
      }
    });
  }

  getUniqueSalesOrderLineStatus = (() => {

    const pipe = new SalesOrderLineStatusPipe();

    return (salesOrderLines) => {

      const getSalesOrderLineStatus = salesOrderLines
        .reduce((prev, cur)=>[...prev, cur.status], []);

      return [...new Set(getSalesOrderLineStatus)].map(pipe.transform);
    }

  })();

  public AddToGrid() {

    if(!this.checkDeliveryDateMoreThanReceivedDate()){
      this.toastr.error('Delivery Date must be more than Received Date');
      return;
    }

    const productId = this.partNumberModel?.value ?? this.assemblyCodeModel.value,
          productNo = this.partNumberModel?.code ?? this.assemblyCodeModel.code,
          productName = this.partNameModel?.text ?? this.assemblyCodeModel.text;

    let salesLines = this.createSalesOrderLineObject({
      productId: productId,
      productNo: productNo,
      productName: productName
    });

    if(this.lineNumberAlreadyExists(salesLines.lineNumber)){
      this.toastr.error(`Sales Order Line With Line Number "${salesLines.lineNumber}" Already Exist`);
      return;
    }

    this.saleOrderLines.push(salesLines);
    this.gridData = this.saleOrderLines;
  }

  public UpdateToGrid() {

    if(!this.checkDeliveryDateMoreThanReceivedDate()){
      this.toastr.error('Delivery Date must be more than Received Date');
      return;
    }

    const productId = this.partNumberModel?.value ?? this.assemblyCodeModel.value,
          productNo = this.partNumberModel?.code ?? this.assemblyCodeModel.code,
          productName = this.partNameModel?.text ?? this.assemblyCodeModel.text,
          status = this.formGroup.get("nestedGridItems.status").value;

    const statusToUse = { 
      status: status ?? SaleOrderLinesStatus.Pending
    };

    let salesLines = this.createSalesOrderLineObject({
      productId: productId,
      productNo: productNo,
      productName: productName,
      ...statusToUse
    });

    salesLines.salesOrderId = this.formGroup.get("nestedGridItems.salesOrderId")?.value ?? -1;;
    salesLines.id = this.formGroup.get("nestedGridItems.id")?.value ?? -1;

    this.saleOrderLines[this.editedSaleOrderLinesRowIndex] = salesLines;
    this.gridData = this.saleOrderLines;
    this.isEditSaleOrderLine = false;

    this.formGroup.get('nestedGridItems.lineNumber')?.enable();
  }

  createSalesOrderLineObject(addOrSubstituteObjectProperties): SaleOrderLines {
    const properties = {
      lineNumber: this.formGroup.get("nestedGridItems.lineNumber").value ?? 1,
      productId: -1,
      productNo:"",
      productName: "",
      revision: this.formGroup.get("nestedGridItems.revision").value ?? '',
      quantity: this.formGroup.get("nestedGridItems.quantity").value ?? 1,
      unitPrice: this.formGroup.get("nestedGridItems.unitPrice").value ?? 0,
      currency: this.formGroup.get("nestedGridItems.currency").value,
      dueDate: this.formGroup.get("nestedGridItems.dueDate").value,
      urgentFlag: this.formGroup.get("nestedGridItems.urgentFlag").value,
      remarks: this.formGroup.get("nestedGridItems.remarks").value,
      uom: this.formGroup.get("nestedGridItems.uom").value,
      status: SaleOrderLinesStatus.Pending,
      salesOrderNumber: this.formGroup.value.purchaseOrderNumber,
      assemblyId: this.assemblyCodeModel?.value ?? -1,
      ...addOrSubstituteObjectProperties
    };

    return new SaleOrderLines(properties);
  }

  public CancelGrid(): void {

    this.isEditSaleOrderLine = false;
    
    this.formGroup.get('nestedGridItems').reset(this.defaultSaleOrderData);
    this.formGroup.get('nestedGridItems.lineNumber')?.enable();

    this.changeAssemblyModelValues(undefined);
    this.changePartModelValues(undefined);
  }

  public onSearchAvailableParts() {
    this.partService.getAll().subscribe((result) => {
      if(result)
      {
        this.availablePartsData = orderBy((result as any), [{ field: 'id', dir: 'asc' }]);
        this.availablePartsGridView = this.availablePartsData;
      }
    
    });
  }

  /* Customer Dropdown Selection*/ 
  public oncustomerCodeSelectionChange(value: any){
    this.customerNameModel = value?.text ?? null;
    this.customerCodeModel = value?.value ?? "";

    this.changeAssemblyModelValues(undefined);
    this.changePartModelValues(undefined);
  }

  public oncustomerNameSelectionChange(value: any){
    this.customerCodeModel = value?.value ?? "";
    this.customerNameModel = value?.text ?? null;

    this.changeAssemblyModelValues(undefined);
    this.changePartModelValues(undefined);
  }

  /** Assembly Dropdown Selection */
  public onassemblyCodeSelectionChange(value: any){

    this.changeAssemblyModelValues(value);

    if(!value){
      this.partFamilies = null;
      this.changePartModelValues(undefined);
      return;
    }

    this.populatePartsDropdownByAssemblyDropdownSelection(value)
    .subscribe(res=>{
      this.partFamilies = res;
    });

    if(this.isEditSaleOrderLine) return;
    this.updateSalesOrderLineNumber();

  }

  public onassemblyNameSelectionChange(value: any){

    this.changeAssemblyModelValues(value);

    if(!value){
      this.partFamilies = null;
      this.changePartModelValues(undefined);
      return;
    }

    this.populatePartsDropdownByAssemblyDropdownSelection(value)
    .subscribe(res=>{
      this.partFamilies = res;
    });

    if(this.isEditSaleOrderLine) return;
    this.updateSalesOrderLineNumber();

  }

  changeAssemblyModelValues(value): void {
    if(!value){
      this.assemblyCodeModel = this.assemblyNameModel = value;
    }

    if(typeof value === 'object'){
      this.assemblyCodeModel = value;
      this.assemblyNameModel = value;
    }
  }

  updateSalesOrderLineNumber(): void {
    if(this.gridData?.length <=0) return;

    const lastItem = this.gridData[this.gridData.length-1];
    this.formGroup.get('nestedGridItems.lineNumber').setValue(lastItem.lineNumber+1);
  }

  /** part Dropdown Selection */
  public onpartCodeSelectionChange(value: any){
    this.changePartModelValues(value);
  }

  public onpartNameSelectionChange(value: any){
    this.changePartModelValues(value);
  }

  changePartModelValues(value): void {
    if(!value){
      this.partNameModel = this.partNumberModel = value;
    }
    
    if(typeof value === 'object'){
      this.partNameModel = value;
      this.partNumberModel = value;
    }
  }

  lineNumberAlreadyExists(optionalLineNumberToCheck?: number): boolean {

    const checkLineNumber = optionalLineNumberToCheck ?? 
      this.formGroup.get('nestedGridItems.lineNumber').value;

    return this.gridData.findIndex(soLine => soLine.lineNumber === checkLineNumber) > -1;

  }

  onDeleteSaleOrderLineClick(event: RemoveEvent ): void {
    var removeIndex = event.rowIndex;
    this.saleOrderLines.splice(removeIndex, 1);
  }

  resetForm() {

    this.editedRowIndex = undefined;
    this.saleOrderLines = [];
    this.mySelection = [];
    this.gridData = [];

    this.isEditSaleOrderLine = false;
    this.isNew = false;

    this.changeAssemblyModelValues(undefined);
    this.changePartModelValues(undefined);

    this.formGroup.reset(this.defaultData);
    this.formGroup.get('nestedGridItems').reset(this.defaultSaleOrderData);
  }

  onEditSaleOrderLineClick(event: EditEvent): void {

    this.isEditSaleOrderLine = true;
    this.editedSaleOrderLinesRowIndex = event.rowIndex;
   
    const formReset: any = Object
      .keys(this.defaultSaleOrderData)
      .reduce((prev, cur)=>({ ...prev, [cur]: event.dataItem[cur] ?? null }), {});

    const editAssemblyId = event.dataItem.assemblyId
    const assembly = this.assemblyFamilies.filter(assembly=>assembly.value===editAssemblyId);

    if(assembly.length>0){
      formReset.assemblyNo = formReset.assemblyName = assembly[0];
    }

    this.populatePartsDropdownByAssemblyDropdownSelection({value: editAssemblyId ?? 0})
    .subscribe(res=>{   

      if(!res) return;

      this.partFamilies = res;

      const editProductId = event.dataItem.productId;
      const part = this.partFamilies.filter(part=>part.value===editProductId);

      formReset.dueDate = new Date(formReset.dueDate);

      if(part.length>0){
        formReset.partNumber = formReset.partName = part[0];
      }

      this.formGroup.get("nestedGridItems").reset(formReset);
      this.formGroup.get('nestedGridItems.lineNumber')?.disable();

    });
  }

  openCreateWOWindow(): void {
    if(this.mySelection.length>0){
      const selectedId = parseInt(this.mySelection[0]);
      const selectedSalesOrder = 
        this.gridDataSubject.value.filter(saleOrder=>saleOrder.id===selectedId)[0];

      this.createWOWindowSalesOrderIdParam = selectedSalesOrder?.id ?? -1;
      this.showCreateWOWindow.next(true);
    }
  }

}
