import { Component, OnInit, Output, EventEmitter, OnDestroy, Input } from '@angular/core';
import { RawMaterial } from '@app/_models';
import { InventoryService, RawMaterialService } from '@app/_services';
import { BehaviorSubject, forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

interface WorkOrderVM {
  workOrderNumber: string;
  poNumber: string;
  quantity: number;
  createdDate: Date;
  status: string;
  materialRatio: number;
  requiredMaterialQuantity: number;
  allocated: boolean;
  allocatedQuantity: number;
  locked: boolean;
}

@Component({
  selector: '[app-allocate-raw-materials]',
  templateUrl: './allocate-raw-materials.component.html',
  styleUrls: ['./allocate-raw-materials.component.scss']
})
export class AllocateRawMaterialsComponent implements OnInit, OnDestroy {

  @Output() closeWindow = new EventEmitter<boolean>();
  @Input() rawMaterialId: number;
  @Input() selectedRawMaterial: RawMaterial;

  rawMaterialName: string = '';

  gridDataSubject = new BehaviorSubject<WorkOrderVM[]>([]);
  gridData$ = this.gridDataSubject.asObservable();

  summaryCardDetails: string[] = [];

  allocationTypeDropdownData = {
    'Consumed': ()=>{

    },
    'Allocated': ()=>{

    },
    '<All>': ()=>{

    }, 
  };

  constructor(
    private inventoryService: InventoryService,
    private rawMaterialService: RawMaterialService,
  ) { }

  ngOnInit(): void {

    forkJoin([
      this.rawMaterialService.getById(this.rawMaterialId),
      this.getDataForInventoryGrid()
    ])
    .pipe(map(res=>({
      rawMaterialDetail: res[0],
      inventoryGridData: res[1]
    })))
    .subscribe(res=>{

      this.setRawMaterialNameOnUI(this.selectedRawMaterial);
      
      this.gridDataSubject.next(res.inventoryGridData);

      this.setSummaryCard({
        'Grade':  this.selectedRawMaterial.grade,
        'Balance Quantity': this.selectedRawMaterial.balanceQuantity,
        'Required Quantity': this.selectedRawMaterial.requiredQuantity
      });

    });
  }

  setRawMaterialNameOnUI(selectedRawMaterial: RawMaterial): void {
    const name = selectedRawMaterial.rawMaterialName;
    const description = selectedRawMaterial.rawMaterialDescription ?
      `/ ${selectedRawMaterial.rawMaterialDescription}` : '';

    this.rawMaterialName = `${name} ${description}`;
  }

  getAllocationTypes() {
    return Object.keys(this.allocationTypeDropdownData);
  }

  onAllocationTypeDropdownChange(type: string) {
    this.allocationTypeDropdownData[type]();
  }

  setSummaryCard(data: {[name:string]:any}): void {
    this.summaryCardDetails = Object.keys(data).reduce((prev, cur)=>([
      ...prev, `${cur}: ${data[cur] ?? 'n/a'}`
    ]), []);
  }

  getDataForInventoryGrid() {
    return this.inventoryService
      .getAllocationById(this.rawMaterialId)
      .pipe(map(res=>res.map(this.convertAPIResponseToWorkOrderVM)));
  }

  convertAPIResponseToWorkOrderVM(data): WorkOrderVM {
    return {
      workOrderNumber: data.remarks,
      poNumber: data?.poNumber,
      quantity: data.quantity, 
      createdDate: data?.createdDate, 
      status: data.status,
      materialRatio: data.materialRatio, 
      requiredMaterialQuantity: data.requiredQuantity,
      allocated: data?.allocated,
      allocatedQuantity: data?.allocatedQuantity,
      locked: data?.locked
    };
  }

  onClose(): void {
    this.closeWindow.emit(true);
  }

  ngOnDestroy(): void {
    this.closeWindow.unsubscribe();
  }
}
