import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocateRawMaterialsComponent } from './allocate-raw-materials.component';

describe('AllocateRawMaterialsComponent', () => {
  let component: AllocateRawMaterialsComponent;
  let fixture: ComponentFixture<AllocateRawMaterialsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllocateRawMaterialsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllocateRawMaterialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
