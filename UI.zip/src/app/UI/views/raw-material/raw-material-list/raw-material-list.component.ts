import {Component, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import {DataBindingDirective, EditEvent, RemoveEvent, RowClassArgs} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import {AbstractControl, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators} from '@angular/forms';
import {BehaviorSubject, Observable} from 'rxjs';
import {ToastService} from '@dis/services/message/toast.service';
import {CustomDialogService} from '@dis/services/message/custom-dialog.service';
import { ProductService, RawMaterialService, SupplierService } from '@app/_services';
import { first } from 'rxjs/operators';
import { RawMaterial } from '@app/_models';

import * as _ from 'lodash';

@Component({
  selector: 'app-raw-material-list',
  templateUrl: './raw-material-list.component.html',
  styleUrls: ['./raw-material-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class RawMaterialListComponent implements OnInit {

  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;

  gridDataSubject: BehaviorSubject<RawMaterial[]>;
  gridView : Observable<RawMaterial[]>;

  mySelection: number[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  editedRowIndex: number;

  dropdownLists: {[type: string]: string[]} = {
    grade: [],
    type: [],
    uom: [],
    linkPart: []
  };

  cachedList: {[type: string]: string[]} = {
    grade: [],
    type: [],
    uom: [],
    linkPart: []
  };
  
  filters = {
    grade: '',
    type: '',
    uom: ''
  };

  public suppliers: Array<{ text: string, value: number}>;

  receiveRawMaterialSubject = new BehaviorSubject<boolean>(false);
  receiveRawMaterial$ = this.receiveRawMaterialSubject.asObservable();

  allocateRawMaterialSubject = new BehaviorSubject<boolean>(false);
  allocateRawMaterial$ = this.allocateRawMaterialSubject.asObservable();

  selectedRawMaterialSubject = new BehaviorSubject<RawMaterial>(null);
  selectedRawMaterial$ = this.selectedRawMaterialSubject.asObservable();

  public data: any = {
    rawMaterialName: '',
    rawMaterialType: '',
    rawMaterialDescription: '',
    grade: '',
    supplierId: 0,
    currency: '',
    price: 0,
    linkedPartId: 0,
    assy: '',
    uoM: '',
    length: '',
    width: '',
    thickness: '',
    productionLoss: 0,
    remarks: '',
  };

  formatGridRowClass = (context: RowClassArgs) => {
    if(context.dataItem.requiredQuantity>0){
      return {
        'raw-material-list-required-qty': true
      };
    }
  }

  constructor(
    private toastr: ToastService, 
    private customDialog: CustomDialogService,
    private supplierService: SupplierService,
    private rawMaterialService: RawMaterialService, 
    private productService: ProductService
  ) {

    const hasRequiredValidator = ['rawMaterialName', 'rawMaterialType'];
    const hasMinNumericValidator = ['productionLoss', 'price'];

    const numValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
      const convertToInt = parseInt(control.value, 10);
      const failureCondition = isNaN(convertToInt) || convertToInt < 0;
      return failureCondition ?  { required: 'Value must be an integer or more than 0' } : null;
    };

    const formControls = Object.keys(this.data).reduce((prev, cur)=>{

      const formcontrol = [this.data[cur]];

      if(hasRequiredValidator.includes(cur)){
        formcontrol.push(Validators.required);
      }

      if(hasMinNumericValidator.includes(cur)){
        formcontrol.push(numValidator);
      }

      return { ...prev, [cur]: new FormControl(...formcontrol) };

    }, {});

      this.formGroup = new FormGroup(formControls);

      this.gridDataSubject = new BehaviorSubject<RawMaterial[]>([]);
      this.gridView = this.gridDataSubject.asObservable();
    }

  onFilter(inputValue: string): void {
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          }
        ],
      },
    }).data;

    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }



  ngOnInit(): void {
    this.loadItems();    
  }

  onAddNewClick(): void {
    this.loadDialogData();
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
  }

  onEditClick(event: EditEvent): void {
    this.loadDialogData();
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;
    this.formGroup.reset(event.dataItem);
    this.editedRowIndex = event.rowIndex;

  }

  closeWindow(): void {
    this.isWindowOpened = false;
    this.formGroup.reset();
    this.mySelection = [];
  }

  submitWindow(item): void {

    this.isWindowOpened = false;

    if(!this.isNew){
      const items = this.gridDataSubject.value;
      item.id = items[this.editedRowIndex].id;
    }

    this.saveItem(item);
  }

  public saveItem(item) : void {

    let data = _.cloneDeep(item);

    if (this.isNew) {
      this.rawMaterialService
        .save(data)
        .pipe(first())
        .subscribe(() => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          }
        );
    }
    else {

      this.rawMaterialService
        .update(data.id, data)
        .pipe(first())
        .subscribe(() => {
          this.loadItems();
          this.toastr.success('Your data has been updated sucessfully.');
        });
    }
  }

  onDeleteClick(event: RemoveEvent ): void {
    this.editedRowIndex = event.rowIndex;
    this.customDialog.confirm().subscribe(res => {
      if (res.primary){
          this.removeItem();
      }
    });
  }



  removeItem(): void {
    // do you processing and close window
    let items = this.gridDataSubject.value;

    // success should be in resolve of subscribe method
    this.rawMaterialService
      .delete(items[this.editedRowIndex].id)
      .pipe(first())
      .subscribe({
        next: () => {
          this.gridDataSubject.next(items);
          this.toastr.success('Your data has been removed sucessfully.');
        },
        error: (error) => {},
      });


    items.splice(this.editedRowIndex, 1);

    // array isnt updating
    // Retrieve backend data to update
    const temp = [...items];
    // noinspection JSUnusedAssignment
    items = [];
    items = [...temp];

  }

   callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void{
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }

  loadItems() {
    this.rawMaterialService.getAll()
    .subscribe((result) => {
      if(result) result =  orderBy(result, [{ field: 'id', dir: 'desc' }]);
      this.gridDataSubject.next(result);
    });
  }

  loadDialogData(): void {

    this.productService.getRawMaterialType().subscribe((data) => {
      if(data) {
        this.dropdownLists['type'] = this.cachedList['type'] = data;
      }
    })

    this.productService.getMaterialGrade().subscribe((data) => {
      if(data) {
        this.dropdownLists['grade'] = this.cachedList['grade'] = data;
      }
    })

    this.productService.getUoms().subscribe((data) => {
      if(data) {
        this.dropdownLists['uom']   = this.cachedList['uom'] = data;
        this.dropdownLists['linkPart']  = this.cachedList['linkPart'] = [...data];
      }
    })

    this.supplierService.getAll().subscribe((data) => {
      if(data) {
        this.suppliers  = data.map(res => ({
          text: res.name,
          value: res.id
        }));
      }
    });
  }

  addNewGrade(): void {
    this.addNew('grade');
  }

  addNewType(): void {
    this.addNew('type');   
  }

  addNewUom(): void {
    this.addNew('uom');
  }

  addNew(filterFor: string): void {
    const filter = this.filters[filterFor];

    if(!filter) return;
    if(this.cachedList[filterFor].includes(filter)) return;

    this.cachedList[filterFor].push(filter);
    this.dropdownLists[filterFor]  = this.cachedList[filterFor];
  }

  handleFilter(filterFor: 'type'|'grade'|'uom',  filter: string): void {
    this.filters[filterFor] = filter;
    this.dropdownLists[filterFor] = 
      this.caseInsensitiveStringListFilter(this.cachedList[filterFor], filter);
  }

  caseInsensitiveStringListFilter(list: string[], filter: string): string[] {
    filter = filter?.toLowerCase();
    return list.filter(s=>s?.toLowerCase().includes(filter));
  }

  retrieveRawMaterialFromGridViewById(id: number): RawMaterial {
    const rawMaterials = this.gridDataSubject.value.filter(rawMaterial=>rawMaterial.id===id);
    return rawMaterials[0];
  }

  toggleReceiveRawMaterialUI(open: boolean): void {

    if(this.mySelection?.length<=0) return;

    const rawMaterialId = this.mySelection[0]
    const rawMaterial = this.retrieveRawMaterialFromGridViewById(rawMaterialId);

    if(!rawMaterial) return;

    this.selectedRawMaterialSubject.next(rawMaterial);
    this.receiveRawMaterialSubject.next(open);
    
  }

  toggleAllocateRawMaterialUI(open: boolean): void {

    if(this.mySelection?.length<=0) return;

    const rawMaterialId = this.mySelection[0]
    const rawMaterial = this.retrieveRawMaterialFromGridViewById(rawMaterialId);

    if(!rawMaterial) return;

    this.selectedRawMaterialSubject.next(rawMaterial);
    this.allocateRawMaterialSubject.next(open);
    
  }

}
