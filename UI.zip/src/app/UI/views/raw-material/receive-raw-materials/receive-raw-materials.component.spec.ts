import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReceiveRawMaterialsComponent } from './receive-raw-materials.component';

describe('ReceiveRawMaterialsComponent', () => {
  let component: ReceiveRawMaterialsComponent;
  let fixture: ComponentFixture<ReceiveRawMaterialsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReceiveRawMaterialsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReceiveRawMaterialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
