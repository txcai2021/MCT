import { Component, OnDestroy, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { EditEvent, RemoveEvent } from '@progress/kendo-angular-grid';
import { BehaviorSubject, forkJoin, Observable } from 'rxjs';
import * as _ from 'lodash';
import { InventoryService, RawMaterialService, SupplierService } from '@app/_services';
import { map } from 'rxjs/operators';
import { RawMaterial } from '@app/_models';

interface InventoryRawMaterialVM {
  rawMaterialName: string;
  dateIn: Date;
  quantity: number;
  allocatedQuantity: number;
  balanceQuantity: number;
  cost: number;
  balanceCost: number;
  supplier: string;
  remarks: string;
  createdBy: string; 
}

@Component({
  selector: '[app-receive-raw-materials]',
  templateUrl: './receive-raw-materials.component.html',
  styleUrls: ['./receive-raw-materials.component.scss']
})
export class ReceiveRawMaterialsComponent implements OnInit, OnDestroy {

  @Output() closeWindow = new EventEmitter<boolean>();
  @Input() rawMaterialId: number = -1;
  @Input() selectedRawMaterial: RawMaterial;

  rawMaterialName: string = '';

  cachedInventoryData: InventoryRawMaterialVM[];
  inventoryListGridSubject = new BehaviorSubject<InventoryRawMaterialVM[]>([]);
  inventoryListGrid$ = this.inventoryListGridSubject.asObservable();

  inventoryListGridSelection: number[] = [];

  formMode: 'add'| 'update' = 'add';

  defaultFormData = {
    dateIn: new Date(),
    quantity: 0,
    cost: null,
    supplier: {text: '', value: ''},
    remark: ''
  };
  formData = _.cloneDeep(this.defaultFormData);

  rawMaterialDetail: FormGroup;

  suppliersSubject = new BehaviorSubject<{ text: string, value: any }[]>([]);
  suppliers$ = this.suppliersSubject.asObservable();

  summaryCardDetails: string[] = [];

  constructor(
    private inventoryService: InventoryService,
    private rawMaterialService: RawMaterialService,
    private supplierService: SupplierService
  ) {

    const hasRequiredValidator = ['dateIn', 'quantity'];

    const formControls = Object.keys(this.formData).reduce((prev, cur)=>{

      const formcontrol = [this.formData[cur]];

      if(hasRequiredValidator.includes(cur)){
        formcontrol.push(Validators.required);
      }

      return { ...prev, [cur]: new FormControl(...formcontrol) };

    }, {});

    this.rawMaterialDetail = new FormGroup(formControls);
  }

  ngOnInit(): void {
    this.getAndSetSupplierDropdownList();
    this.refreshInventoryListGrid();
  }

  refreshInventoryListGrid(): void {
    
    forkJoin([
      this.rawMaterialService.getById(this.rawMaterialId),
      this.getReceiveMaterialData()
    ])  
    .pipe(map(res=>({
      materialInfo: res[0],
      materialsData: res[1]
    })))
    .subscribe(res=>{

      if(res.materialInfo){
        const name = this.selectedRawMaterial.rawMaterialName;
        const description = this.selectedRawMaterial.rawMaterialDescription ?
          `/ ${ this.selectedRawMaterial.rawMaterialDescription }` : '';

        this.rawMaterialName = `${name} ${description}`;

        res.materialsData = res.materialsData.map(data=>({
          ...data, 
          rawMaterialName: res.materialInfo.rawMaterialName,
          supplier: res.materialInfo.supplierName
        }));
      }

      if(res.materialsData){
        this.cachedInventoryData = res.materialsData;
        this.inventoryListGridSubject.next(this.cachedInventoryData);

        if(this.selectedRawMaterial){
          this.setRawMaterialsSummaryCard({
            balanceQuantity: this.selectedRawMaterial.balanceQuantity,
            totalQuantity: this.cachedInventoryData.reduce((prev, cur)=>prev + cur.quantity, 0),
            requiredQuantity: this.selectedRawMaterial.requiredQuantity
          });
        }
      }
    });
  }

  getReceiveMaterialData(): Observable<InventoryRawMaterialVM[]> {
    return this.inventoryService.getReceiptById(this.rawMaterialId)
    .pipe(map(res=>res.map(this.convertDataFromAPIIntoInventoryRawMaterialVM)));
  }

  getAndSetSupplierDropdownList(): void {
    this.supplierService.getAll().subscribe(res=>{
      if(res){
        this.suppliersSubject.next(
          res.map(supplier=>({
            text: supplier.name, 
            value: supplier.id
          }))
        );
      }
    })
  }

  convertDataFromAPIIntoInventoryRawMaterialVM(data: any): InventoryRawMaterialVM {
    return {
      rawMaterialName: data.rawMaterialName,
      dateIn: new Date(data.dateIn),
      quantity: data.completedQty,
      allocatedQuantity: data.allocatedQuantity,
      balanceQuantity: data.balancedQty,
      cost: data.cost,
      balanceCost: data.balanceCost,
      supplier: data.supplier,
      remarks: data.remarks,
      createdBy: data.createdBy
    };
  }

  setRawMaterialsSummaryCard(data: {
    requiredQuantity: number;
    totalQuantity: number;
    balanceQuantity: number;
  }): void {
    this.summaryCardDetails = [
      `Total Quantity: ${data.totalQuantity?.toFixed(2) ?? 'n/a'}`, 
      `Balance Quantity: ${data.balanceQuantity?.toFixed(2) ?? 'n/a'}`,
      `Required Quantity: ${data.requiredQuantity?.toFixed(2) ?? 'n/a'}`
    ];
  }

  onFormCancelClick(): void {
    this.formMode = 'add';
    this.rawMaterialDetail.reset({
      dateIn: new Date()
    });
  }

  onEditClick(e: EditEvent): void {

  }

  onDeleteClick(event: RemoveEvent): void {
    let removeIndex = event.rowIndex;

    let data = [...this.cachedInventoryData];
    data.splice(removeIndex, 1);
    this.cachedInventoryData = data;

    this.inventoryListGridSubject.next(data);
  }

  onClose(): void {
    this.closeWindow.emit(true);
  }

  ngOnDestroy(): void {
    this.closeWindow.unsubscribe();
  }
}
