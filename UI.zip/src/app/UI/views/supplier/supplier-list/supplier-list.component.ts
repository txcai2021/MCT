import {Component, OnInit, ViewChild} from '@angular/core';
import {DataBindingDirective, EditEvent, RemoveEvent} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {BehaviorSubject, Observable} from 'rxjs';
import {ToastService} from '@dis/services/message/toast.service';
import {CustomDialogService} from '@dis/services/message/custom-dialog.service';
import { AccountService, CustomerService, MenuService, SupplierService } from '@app/_services';
import { first } from 'rxjs/operators';
import { Customer } from '@app/_models';

@Component({
  selector: 'app-supplier-list',
  templateUrl: './supplier-list.component.html',
  styleUrls: ['./supplier-list.component.scss']
})
export class SupplierListComponent implements OnInit {

  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;

  gridDataSubject: BehaviorSubject<Customer[]>;
  gridView : Observable<Customer[]>;

  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  editedRowIndex: number;

  public phoneNumberValue: string = '';
  public phoneNumberMask: string = '0000-0000';
  public data: any = {
    code: '',
    name: '',
    contactPerson: '',
    phone: this.phoneNumberValue,
    email: '',
    address: '',
    billingAddress: '',
    description: '',
    currency: '',
    priority: 0,
    credit_term: '',
  };

  constructor(private toastr: ToastService, private customDialog: CustomDialogService,
    private supplierService: SupplierService) {
        this.formGroup = new FormGroup({
          code: new FormControl(this.data.code, Validators.required),
          name: new FormControl(this.data.name, Validators.required),
          contactPerson: new FormControl(this.data.contactPerson),
          phone: new FormControl(this.data.phone),
          email: new FormControl(this.data.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")),
          address: new FormControl(this.data.address),
          billingAddress: new FormControl(this.data.billingAddress),
          description: new FormControl(this.data.description),
          currency: new FormControl(this.data.currency),
          priority: new FormControl(this.data.priority),
          credit_term: new FormControl(this.data.credit_term),
        });


        this.supplierService.getAll().subscribe((result) => {
          if(result) result =  orderBy((result as any), [{ field: 'id', dir: 'desc' }]);
          this.gridDataSubject = new BehaviorSubject<Customer[]>(result);
          this.gridView = this.gridDataSubject.asObservable();
        });
    
     }


  onFilter(inputValue: string): void {
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          }

        ],
      },
    }).data;

    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }



  ngOnInit(): void {
    this.loadItems();
    
  }

  onAddNewClick(): void {
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
  }

  onEditClick(event: EditEvent): void {
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;
    this.formGroup.reset(event.dataItem);
    this.editedRowIndex = event.rowIndex;

  }

  closeWindow(): void {
    this.isWindowOpened = false;
    this.formGroup.reset()
    this.mySelection = []
  }

  submitWindow(item): void {

    this.isWindowOpened = false;

    if(!this.isNew){
      const items = this.gridDataSubject.value;
      item.id = items[this.editedRowIndex].id;
    }

    this.saveItem(item);
  }

  public saveItem(item) : void {

    console.log(JSON.stringify(this.formGroup.value));

    if (this.isNew) {
      this.supplierService
        .save(this.formGroup.value)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {
          
          },
        });
    }
    else {

      let customer: Customer = item;
      customer.id = item.id;

      this.supplierService
        .update(item.id, customer)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been updated sucessfully.');
          },
          error: (error) => {
          },
        });
    }
  }

  onDeleteClick(event: RemoveEvent ): void {
    this.editedRowIndex = event.rowIndex;
    this.customDialog.confirm().subscribe(res => {
      // Primary (Yes) button is clicked
      if (res.primary){
          this.removeItem();
      }
    });
  }



  removeItem(): void {
    // do you processing and close window
    let items = this.gridDataSubject.value;

    // success should be in resolve of subscribe method
    this.supplierService
      .delete(items[this.editedRowIndex].id)
      .pipe(first())
      .subscribe({
        next: () => {
          this.gridDataSubject.next(items);
          this.toastr.success('Your data has been removed sucessfully.');
        },
        error: (error) => {},
      });



    items.splice(this.editedRowIndex, 1);

    // array isnt updating
    // Retrieve backend data to update
    const temp = [...items];
    // noinspection JSUnusedAssignment
    items = [];
    items = [...temp];

    
  }

   callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void{
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }

  loadItems() {
    this.supplierService.getAll().subscribe((result) => {
      if(result) result =  orderBy((result as any), [{ field: 'id', dir: 'desc' }]);
      this.gridDataSubject.next(result);
    });

  }

}
