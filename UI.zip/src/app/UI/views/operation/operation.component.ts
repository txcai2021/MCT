import { Component, OnInit, ViewChild } from '@angular/core';
import {
  DataBindingDirective,
  EditEvent,
  RemoveEvent,
  PageChangeEvent,
} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable } from 'rxjs';
import { ToastService } from '@dis/services/message/toast.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { CustomMessageService } from '@dis/services/message/custom-message.service';

import { MealService, MachineService, OperationService } from '@app/_services';
import { first } from 'rxjs/operators';
import { Shift, Machine, Operation } from '@app/_models';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { __values } from 'tslib';
@Component({
  selector: 'app-operation',
  templateUrl: './operation.component.html',
  styleUrls: ['./operation.component.scss'],
})
export class OperationComponent implements OnInit {
  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;
  public min: Date = new Date(2000, 2, 10, 2, 30);
  public max: Date = new Date(2002, 2, 10, 22, 15);
  public value: Date = new Date(2000, 2, 10, 10, 0);
  public selectableSettings: SelectableSettings;

  public checkboxOnly = true;
  public mode = 'single';
  public drag = false;

  gridDataSubject: BehaviorSubject<Operation[]>;
  gridView: Observable<Operation[]>;

  gridDataSubjectMeal: BehaviorSubject<Machine[]>;
  gridViewMeal: Observable<Machine[]>;
  previousSelectedMeal = [];
  previousSelectedMealTup = {};

  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  idTextFieldDisabled = false;
  editedRowIndex: number;
  editedRowId: number;
  isSecondWindowOpened = false;
  disabledCondition = false;
  mySelectionMeal: any[] = [];
  pageSize = 10;
  skip = 0;
  machinemapping = {};

  public data: any = {
    idName: '',
    description: '',
    instruction: '',
    radio: null,
    minclass: 0,
    maxclass: 0,
    sizemultiple: 0,
  };

  calling(base): void {
    console.log(base);
    if (base == 'rate') {
      console.log('if');
      this.disabledCondition = false;
    } else {
      console.log('else');
      this.disabledCondition = true;
    }
  }

  constructor(
    private toastr: ToastService,
    private customDialog: CustomDialogService,
    private customMessage: CustomMessageService,
    private machineService: MachineService,
    private operationService: OperationService
  ) {
    this.setSelectableSettings();

    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
      instruction: new FormControl(this.data.instruction),
      ratetype: new FormControl('ratebased'),
      minclass: new FormControl(this.data.minclass, [Validators.required]),
      maxclass: new FormControl(this.data.maxclass, [Validators.required]),
      sizemultiple: new FormControl(this.data.sizemultiple, [
        Validators.required,
      ]),
    });

    // this.operationService.getAll().subscribe((result) => {
    //   if (result['$values'])
    //     result['$values'] = orderBy(result['$values'] as any, [
    //       { field: 'id', dir: 'desc' },
    //     ]);
    //   console.log('operation service ');
    //   console.log(result);
    //   console.log(JSON.stringify(result['$values']));
    //   this.gridDataSubject = new BehaviorSubject<Operation[]>(
    //     result['$values']
    //   );
    //   console.log('grideview');
    //   // for (var row in this.gridDataSubject) {
    //   //   console.log(row);
    //   //   console.log('hi');
    //   // }
    //   // console.log(this.gridDataSubject);
    //   this.gridView = result['$values'];
    //   // this.gridView = JSON.stringify(result['$values']);
    // });

    console.log('machineService');

    this.machineService.getAll().subscribe((newresult) => {
      console.log('machineService inside');
      console.log(newresult);
      let result = {};
      let nlength = newresult.length;
      for (let i = 0; i < nlength; i++) {
        this.machinemapping[newresult[i].id] = newresult[i].name;
        if (String(newresult[i]['type']) == '1') {
          newresult[i]['type'] = 'InHouse';
        } else if (String(newresult[i]['type']) == '2') {
          newresult[i]['type'] = 'QC';
        } else if (String(newresult[i]['type']) == '3') {
          newresult[i]['type'] = 'SubCon';
        }
      }
      result['$id'] = 1;
      result['$values'] = newresult;
      console.log(result);
      console.log(result);
      if (result['$values']) {
        console.log('inside man');
        result['$values'] = orderBy(result['$values'] as any, [
          { field: 'id', dir: 'desc' },
        ]);
      }
      console.log('constructor');
      console.log(JSON.stringify(result));
      this.gridDataSubjectMeal = new BehaviorSubject<Machine[]>(
        result['$values']
      );
      console.log('grideview');
      console.log(this.gridDataSubjectMeal);
      this.gridViewMeal = result['$values'];
      console.log('constructor');
      console.log(JSON.stringify(result['$values']));
      // this.gridDataSubject = new BehaviorSubject<Machine[]>(result['$values']);
      // console.log('grideview');
      // console.log(this.gridDataSubject);
      // this.gridView = result['$values'];
      // if (result)
      //   result = orderBy(result as any, [
      //     { field: 'id', dir: 'desc' },
      //   ]);

      // this.gridView = JSON.stringify(result['$values']);
      console.log('operationService');
      this.operationService.getAll().subscribe((newresult) => {
        let result = {};
        let nlength = newresult.length;
        console.log(this.machinemapping);
        console.log(newresult);

        for (let i = 0; i < nlength; i++) {
          let nlen = newresult[i].operationResourcePMs.length;
          newresult[i]['resourceNames'] = '';
          for (let j = 0; j < nlen; j++) {
            let machineid = newresult[i].operationResourcePMs[j]['resourceId'];
            if (j == 0) {
              newresult[i]['resourceNames'] = this.machinemapping[machineid];
            } else {
              let newstring = ', ' + this.machinemapping[machineid];
              newresult[i]['resourceNames'] += newstring;
            }
            newresult[i]['resourceNames'];
          }
        }

        result['$id'] = 1;
        result['$values'] = newresult;

        if (result['$values'])
          result['$values'] = orderBy(result['$values'] as any, [
            { field: 'id', dir: 'desc' },
          ]);
        console.log('operation service ');
        console.log(result);
        console.log(JSON.stringify(result['$values']));

        this.gridDataSubject = new BehaviorSubject<Operation[]>(
          result['$values']
        );
        console.log('grideview');
        // for (var row in this.gridDataSubject) {
        //   console.log(row);
        //   console.log('hi');
        // }
        // console.log(this.gridDataSubject);
        this.gridView = result['$values'];
        // this.gridView = JSON.stringify(result['$values']);
      });
    });

    // this.operationService.getAll().subscribe((newresult) => {
    //   let result = {};
    //   let nlength = newresult.length;

    //   for (let i = 0; i < nlength; i++) {
    //     newresult[i]['resourceNames'] = 'anodizing1, anodizing2, anodizing3';
    //   }

    //   result['$id'] = 1;
    //   result['$values'] = newresult;

    //   if (result['$values'])
    //     result['$values'] = orderBy(result['$values'] as any, [
    //       { field: 'id', dir: 'desc' },
    //     ]);
    //   console.log('operation service ');
    //   console.log(result);
    //   console.log(JSON.stringify(result['$values']));

    //   this.gridDataSubject = new BehaviorSubject<Operation[]>(
    //     result['$values']
    //   );
    //   console.log('grideview');
    //   // for (var row in this.gridDataSubject) {
    //   //   console.log(row);
    //   //   console.log('hi');
    //   // }
    //   // console.log(this.gridDataSubject);
    //   this.gridView = result['$values'];
    //   // this.gridView = JSON.stringify(result['$values']);
    // });
  }

  ngOnInit(): void {
    this.loadItems();
    this.setSelectableSettings();
  }

  public setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: this.checkboxOnly,

      drag: this.drag,
      mode: 'single',
    };
  }
  loadItems() {
    this.setSelectableSettings();
    this.operationService.getAll().subscribe((newresult) => {
      let result = {};
      let nlength = newresult.length;
      console.log(this.machinemapping);
      console.log(newresult);

      for (let i = 0; i < nlength; i++) {
        let nlen = newresult[i].operationResourcePMs.length;
        newresult[i]['resourceNames'] = '';
        for (let j = 0; j < nlen; j++) {
          let machineid = newresult[i].operationResourcePMs[j]['resourceId'];
          if (j == 0) {
            newresult[i]['resourceNames'] = this.machinemapping[machineid];
          } else {
            let newstring = ', ' + this.machinemapping[machineid];
            newresult[i]['resourceNames'] += newstring;
          }
          newresult[i]['resourceNames'];
        }
      }
      result['$id'] = 1;
      result['$values'] = newresult;

      if (result['$values'])
        result['$values'] = orderBy(result['$values'] as any, [
          { field: 'id', dir: 'desc' },
        ]);
      console.log('operation service ');
      console.log(result);
      console.log(JSON.stringify(result['$values']));
      this.gridDataSubject = new BehaviorSubject<Operation[]>(
        result['$values']
      );
      console.log('grideview');
      // for (var row in this.gridDataSubject) {
      //   console.log(row);
      //   console.log('hi');
      // }
      // console.log(this.gridDataSubject);
      this.gridView = result['$values'];
    });
  }
  closeWindowWarning() {
    this.isSecondWindowOpened = false;
  }

  onFilter(inputValue: string): void {
    console.log(inputValue);
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          },
        ],
      },
    }).data;

    console.log(items);
    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }

  clearData(): void {
    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
      instruction: new FormControl(this.data.instruction),
      ratetype: new FormControl('ratebased'),
      minclass: new FormControl(this.data.minclass, [Validators.required]),
      maxclass: new FormControl(this.data.maxclass, [Validators.required]),
      sizemultiple: new FormControl(this.data.sizemultiple, [
        Validators.required,
      ]),
    });
    this.previousSelectedMeal = [];
    this.previousSelectedMealTup = {};
  }

  onAddNewClick(): void {
    this.idTextFieldDisabled = false;
    this.clearData();
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
    this.disabledCondition = false;
    console.log(this.disabledCondition);
    this.previousSelectedMeal = [];
    this.previousSelectedMealTup = {};
  }

  onEditClick(event: EditEvent): void {
    console.log('on edit click');
    console.log(this.gridDataSubject);
    console.log('selected event');
    console.log(event);
    console.log('selected editedrowindex');
    console.log(this.editedRowIndex);
    let selectedchildarr = event['dataItem']['operationResourcePMs'];
    console.log('length of operationreoucepm ');
    console.log(selectedchildarr.length);
    for (var index in selectedchildarr) {
      this.previousSelectedMeal.push(selectedchildarr[index]['resourceId']);
      this.previousSelectedMealTup[selectedchildarr[index]['resourceId']] =
        selectedchildarr[index];
      console.log(selectedchildarr);
      this.mySelectionMeal.push(selectedchildarr[index]['resourceId']);
    }

    console.log('previously selected');
    console.log(this.previousSelectedMeal);
    console.log('previously selected tup');
    console.log(this.previousSelectedMealTup);
    console.log('currently selected');
    console.log(this.mySelectionMeal);

    console.log('israte');
    let isRate = 'ratebased';
    this.disabledCondition = false;
    if (event['dataItem'].type == 1) {
      isRate = 'cyclebase';
      console.log('inside');
      this.disabledCondition = true;
    }

    console.log(event);
    this.idTextFieldDisabled = true;

    let newData: any = {
      idName: '',
      description: '',
      instruction: '',
      ratetype: isRate,
      minclass: 0,
      maxclass: 0,
      sizemultiple: 0,
    };

    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;
    console.log('event');
    console.log(event.dataItem);

    newData.idName = event.dataItem.name;
    // newData.startTime = new Date(2002, 2, 10, startTimeHour, startTimeMinute);
    // newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);
    // newData.description = event.dataItem.description;
    newData.description = event.dataItem.description;
    newData.instruction = event.dataItem.instruction;
    newData.minclass = event.dataItem.minSize;
    newData.maxclass = event.dataItem.maxSize;
    newData.sizemultiple = event.dataItem.sizeMultiple;

    console.log(newData);

    this.formGroup.reset(newData);
    this.editedRowIndex = event.rowIndex;
  }

  closeWindow(): void {
    console.log('close window');
    console.log(this.mySelectionMeal);
    this.mySelectionMeal = [];
    this.isWindowOpened = false;
    this.disabledCondition = true;
  }

  submitWindow(item): void {
    this.isWindowOpened = false;
    if (!this.isNew) {
      const items = this.gridDataSubject.value;

      item.id = items[this.editedRowIndex].id;
    } else {
      item.id = 0;
    }
    console.log('submitwindowfunction');
    console.log(item);
    this.saveItem(item);
  }

  public saveItem(item): void {

    let newOperationResourcePMs: any = [];

    for (var i in this.mySelectionMeal) {
      let elem = this.mySelectionMeal[i];
      for (var index in this.gridViewMeal) {
        let curTup = this.gridViewMeal[index];
        if (curTup['id'] == elem) {

          let newtup = {};
          if (this.previousSelectedMeal.includes(curTup.id)) {
            console.log('reused');
            newOperationResourcePMs.push(
              this.previousSelectedMealTup[curTup.id]
            );
          } else {
            if (!this.previousSelectedMeal.includes(curTup.id)) {
              if (curTup.type == 'InHouse') {
                newtup = {
                  id: 0,
                  operationId: item.id,
                  resourceId: curTup.id,
                  isActive: true,
                  isDefault: true,
                  cost: 0,
                  pretime: 0,
                  posttime: 0,
                  productionRate: 0,
                  prodRateUoM: 0,

                  description: 'string',
                  comment: 'string',
                  createdDate: '2021-11-02T11:24:24.391Z',
                  resourceName: 'string',
                  resourceType: 0,
                  resourceCost: 0,

                  locationName: 'string',
                  isInhouse: true,
                };
              } else {
                newtup = {
                  id: 0,
                  operationId: item.id,
                  resourceId: curTup.id,
                  isActive: true,
                  isDefault: true,
                  cost: 0,
                  pretime: 0,
                  posttime: 0,
                  productionRate: 0,
                  prodRateUoM: 0,

                  description: 'string',
                  comment: 'string',
                  createdDate: '2021-11-02T11:24:24.391Z',
                  resourceName: 'string',
                  resourceType: 0,
                  resourceCost: 0,

                  locationName: 'string',
                  isInhouse: false,
                };
              }
              newOperationResourcePMs.push(newtup);
            }
          }
          console.log('outsidedetail');
        }
      }
    }

    let isRate = 0;
    if (item.ratetype == 'cyclebase') {
      isRate = 1;
    }

    if (this.isNew) {
      console.log('newcalendar');
      console.log(newOperationResourcePMs);

      let postMealObject = {
        id: 0,
        name: item.idName,
        type: isRate,
        locationId: 0,
        locationName: 'string',
        active: true,
        description: item.description,
        comment: 'string',
        createdDate: '2021-11-02T11:24:24.390Z',
        minSize: item.minclass,
        maxSize: item.maxclass,
        sizeMultiple: item.sizemultiple,
        routes: 0,
        resources: 0,
        remarks: 'string',
        operationResourcePMs: newOperationResourcePMs,
        resourceNames: 'string',
        resourceName: 'string',
        routings: 0,
        parameters: 0,
        operationParameterPMs: [],
        parameterNames: 'string',
        operationParameterReport: 'string',
        isParameter: true,
        dataCollections: 0,
        operationDataCollectionPMs: [],
        dataCollectionNames: 'string',
        isLargeImage: true,
        isThumbNailImage: true,
        largeImageFileName: 'string',

        pictureId: 0,
        operationDataCollectionId: 0,
        operationDataCollectionName: 'string',
        operationDataCollectionReport: 'string',
        operationDataCollectionUOM: 'string',
        operationDataCollectionCriteria: 'string',
        isDataCollection: true,
        sParameters: 0,
        operationSParameterPMs: [],
        sParameterNames: 'string',
        operationSParameterReport: 'string',
        isSParameter: true,
        ok: 'string',
        ng: 'string',
        category: 'string',
        instruction: item.instruction,
        version: 1,
        modifiedDate: '2021-11-02T11:24:24.394Z',
        noofReading: 0,
        rpIdNameList: ['string'],
        isPdfFile: true,
      };
      console.log('postmeal');
      console.log(JSON.stringify(postMealObject));
      console.log();

      this.operationService
        .save(postMealObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    } else {
      let postMealObject = {
        id: item.id,
        name: item.idName,
        type: isRate,
        locationId: 0,
        locationName: 'string',
        active: true,
        description: item.description,
        comment: 'string',
        createdDate: '2021-11-02T11:24:24.390Z',
        minSize: item.minclass,
        maxSize: item.maxclass,
        sizeMultiple: item.sizemultiple,
        routes: 0,
        resources: 0,
        remarks: 'string',
        operationResourcePMs: newOperationResourcePMs,
        resourceNames: 'string',
        resourceName: 'string',
        routings: 0,
        parameters: 0,
        operationParameterPMs: [],
        parameterNames: 'string',
        operationParameterReport: 'string',
        isParameter: true,
        dataCollections: 0,
        operationDataCollectionPMs: [],
        dataCollectionNames: 'string',
        isLargeImage: true,
        isThumbNailImage: true,
        largeImageFileName: 'string',

        pictureId: 0,
        operationDataCollectionId: 0,
        operationDataCollectionName: 'string',
        operationDataCollectionReport: 'string',
        operationDataCollectionUOM: 'string',
        operationDataCollectionCriteria: 'string',
        isDataCollection: true,
        sParameters: 0,
        operationSParameterPMs: [],
        sParameterNames: 'string',
        operationSParameterReport: 'string',
        isSParameter: true,
        ok: 'string',
        ng: 'string',
        category: 'string',
        instruction: item.instruction,
        version: 1,
        modifiedDate: '2021-11-02T11:24:24.394Z',
        noofReading: 0,
        rpIdNameList: ['string'],
        isPdfFile: true,
      };
      
      let finalnewcalendarDetails = [];

      this.operationService
        .update(item.id, postMealObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
      finalnewcalendarDetails = [];
    }
    this.mySelectionMeal = [];
    this.previousSelectedMeal = [];
  }

  // deleteButton(): void {
  //   console.log(this.mySelection);
  //   if (this.mySelection.length == 0) {
  //     this.toastr.error('Please click on one of the checkboxes');
  //   } else {
  //     this.editedRowIndex = parseInt(this.mySelection[0]);
  //     console.log('inside');
  //     console.log(this.mySelection);
  //     console.log(this.editedRowIndex);
  //     console.log('delete ' + this.editedRowIndex);
  //     this.customDialog.confirm().subscribe((res) => {
  //       // Primary (Yes) button is clicked
  //       if (res.primary) {
  //         console.log('delete if');
  //         this.removeItem();
  //       }
  //     });
  //   }
  // }

  onDeleteClick(event: RemoveEvent): void {
    console.log(event);

    this.editedRowIndex = event.rowIndex;
    console.log('delete ' + this.editedRowIndex);
    //thisisSecondWindowOpened;
    if (event.dataItem.locationId > 0) {
      this.isSecondWindowOpened = true;
    } else {
      this.customDialog.confirm().subscribe((res) => {
        // Primary (Yes) button is clicked
        if (res.primary) {
          console.log('delete if');
          this.removeItem(event.dataItem.id);
        }
      });
    }
  }

  removeItem(deleteid): void {
    // do you processing and close window
    let items = this.gridDataSubject.value;
    console.log('before');
    console.log(items);
    console.log('editedrowindex');
    console.log(this.editedRowIndex);
    let deletedId = this.editedRowIndex;
    let getdeleteid: any = 0;

    for (var row in items) {
      let curTup = items[row];
      console.log(curTup);
      if (curTup['$id'] == deletedId) {
        console.log('inside');
        getdeleteid = curTup['id'];
        console.log(curTup['id']);
      }
    }
    console.log(items[this.editedRowIndex]);
    // let getdeleteid = items[this.editedRowIndex].id;
    console.log(getdeleteid);
    items.splice(this.editedRowIndex, 1);

    // array isnt updating
    // Retrieve backend data to update
    const temp = [...items];
    // noinspection JSUnusedAssignment
    items = [];
    items = [...temp];
    console.log('after');
    console.log(items);
    // success should be in resolve of subscribe method
    this.operationService
      .delete(String(deleteid))
      .pipe(first())
      .subscribe({
        next: (data) => {
          if (data == -1) {
            this.toastr.error('Shift is used by Day');
          } else {
            this.gridDataSubject.next(items);
            this.loadItems();
            this.toastr.success('Your data has been removed sucessfully.');
          }
        },
        error: (error) => {},
      });
    this.mySelectionMeal = [];
    this.isWindowOpened = false;
    this.mySelection = [];
  }

  callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void {
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }
  pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();

    // Optionally, clear the selection when paging
    // this.mySelection = [];
  }
}

// editButton(event: EditEvent): void {
//   this.idTextFieldDisabled = true;
//   let newData = {
//     idName: '',
//     instruction: '',
//     description: '',
//   };

//   if (this.mySelection.length == 0) {
//     this.toastr.error('Please click on one of the checkboxes');
//   } else {
//     let selectedindex = this.mySelection[this.mySelection.length - 1];
//     console.log('edit event');
//     console.log(this.mySelection);
//     console.log(this.gridView);
//     console.log(event.dataItem);
//     let countindex = 0;
//     for (var row in this.gridView) {
//       let curTup = this.gridView[row];
//       if (curTup['$id'] == selectedindex) {
//         console.log(curTup);
//         let selectedchildarr = curTup['calendarChilds']['$values'];
//         console.log('length of child');
//         console.log(selectedchildarr.length);
//         for (var index in selectedchildarr) {
//           this.previousSelectedMeal.push(selectedchildarr[index]);
//           this.mySelectionMeal.push(selectedchildarr[index]['calendarId']);
//         }

//         console.log('current selection');
//         console.log(this.mySelectionMeal);
//         console.log('previous selection');
//         console.log(this.previousSelectedMeal.length);
//         console.log(this.previousSelectedMeal);

//         let getstarttime = curTup.startTime;
//         let startTimeArray = getstarttime.split(':');
//         let startTimeHour = startTimeArray[0];
//         let startTimeMinute = startTimeArray[1];
//         let getendTime = curTup.endTime;
//         let endTimeArray = getendTime.split(':');
//         let endTimeHour = endTimeArray[0];
//         let endTimeMinute = endTimeArray[1];
//         newData.idName = curTup.name;
//         newData.description = curTup.description;

//         this.formGroup.reset(newData);
//         this.editedRowIndex = countindex;
//         this.isWindowOpened = !this.isWindowOpened;
//         this.isNew = false;
//       }
//       countindex += 1;
//     }
//   }
// }
