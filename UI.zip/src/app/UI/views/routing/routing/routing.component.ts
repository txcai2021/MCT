import { Component, OnInit, ViewChild } from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';

import { Observable, of, forkJoin, BehaviorSubject } from 'rxjs';
import { map, finalize } from 'rxjs/operators';

import { Operation, Routing } from '@app/_models';
import { LocationService, ProductService, RoutingService } from '@app/_services';

import { AuthKeycloakService } from '@dis/auth/auth-keycloak.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { ToastService } from '@dis/services/message/toast.service';

import { DragStartEvent, DataEvent, DragEndEvent, DragOverEvent} from '@progress/kendo-angular-sortable';
import { orderBy, process } from '@progress/kendo-data-query';
import { DataBindingDirective, EditEvent, RemoveEvent } from '@progress/kendo-angular-grid';
import { OperationService } from '@app/_services/operation.service';

interface RouteOperation {
  id: number;
  name: string;
  instruction: string;
  comments: string;
  resource: any[];
  machines: any;
}

@Component({
  selector: 'app-routing',
  templateUrl: './routing.component.html',
  styleUrls: ['./routing.component.scss']
})
export class RoutingComponent implements OnInit {

  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;

  cachedGridData : Routing[];
  gridDataSubject = new BehaviorSubject<Routing[]>([]);
  gridView : Observable<Routing[]> = this.gridDataSubject.asObservable();
  myGridViewSelection: any[] = [];

  availableOperationsSubject: BehaviorSubject<RouteOperation[]>;
  availableOperations: Observable<RouteOperation[]>;

  showFormWindow = false;
  formWindowFlag: 'save' | 'update' = 'save'; 
  formGroup: FormGroup;
  data = {
    unit: {text: '', value: ''},
    name: '',
    assignRoutingToPart: {text: '', value: ''},
    productFamily: '',
    description: ''
  };
  routingToEdit: Routing;

  productFamilyList: Array<{text: string}> = [];
  unitList: Array<{text: string, value: number}> = [];
  assignRoutingToPartList: BehaviorSubject<Array<{text: string, value: number}>>;
  name: string = '';
  description: string = '';

  operationListSubject: BehaviorSubject<RouteOperation[]>;
  operationList: Observable<RouteOperation[]>;
  selectedItemIndexOnOperationList: number;
  removeOperationFromOperationList = false;

  showAssignRouteToProductWindowSubject = new BehaviorSubject<boolean>(false);
  showAssignRouteToProductWindow$ = this.showAssignRouteToProductWindowSubject.asObservable();
  initialAssignRouteToProductDropdownValueSubject = new BehaviorSubject<{text: string, value: string}>({text: '', value: ''});
  initialAssignRouteToProductDropdownValue$ = this.initialAssignRouteToProductDropdownValueSubject.asObservable();

  showDefineProcessTimeWindowSubject = new BehaviorSubject<boolean>(false);
  showDefineProcessTimeWindow$ = this.showDefineProcessTimeWindowSubject.asObservable();
  selectedDefineProcessTimeRoute: number = -1;

  constructor(
    private routingService: RoutingService, 
    private locationService: LocationService, 
    private productService: ProductService,
    private operationService: OperationService, 
    private _keycloakAuth: AuthKeycloakService,
    private customDialog: CustomDialogService,
    private toastr: ToastService
  ) { 

    this.formGroup = new FormGroup({
      unit: new FormControl(this.data.unit),
      name: new FormControl(this.data.name),
      assignRoutingToPart: new FormControl(this.data.assignRoutingToPart),
      productFamily: new FormControl(this.data.productFamily),
      description: new FormControl(this.data.description)
    });

    this.availableOperationsSubject = new BehaviorSubject<RouteOperation[]>([]);
    this.availableOperations= this.availableOperationsSubject.asObservable();

    this.operationListSubject = new BehaviorSubject<RouteOperation[]>([]);
    this.operationList = this.operationListSubject.asObservable();

    this.assignRoutingToPartList = new BehaviorSubject<Array<{text: string, value: number}>>([]);
  }

  ngOnInit(): void {   
    this.refreshRoutingUIGrid();
  }

  onEditClick(event: EditEvent): void {
    
    var selectedItem = <Routing>(event.dataItem ?? {});

    forkJoin([
      this.locationService.getAll().pipe(
        map(res=>(res ? res.map(res => ({ name: res.name, id: res.id })) : []))
      ),
      this.productService.getProductFamilies().pipe(map(res => res ? res : []))
    ]).subscribe((res)=>{

      const locations = res[0];
      const productFamilies = res[1];

      this.setUnitDropdown(locations);

      if(selectedItem.locationId)
        this.setAvailableOperationsSortableList(selectedItem.locationId);
      else if(this.unitList?.length>0)
        this.setAvailableOperationsSortableList(this.unitList[0]?.value);


      this.setProductFamilyDropdown(productFamilies);
      this.setAssignRoutingToPartDropdown(selectedItem.productFamily);  
      
      this.setFormValuesForEditing(selectedItem);
          
      this.setOperationListOnSubmitFormUIForEdit(selectedItem.routeOperationPMs);

      this.routingToEdit = selectedItem;
      this.formWindowFlag = 'update';
      this.showFormWindow = true;

    });
  }

  setFormValuesForEditing(selected: Routing): void {
    const formData = {
      unit: { 
        text: selected.locationName, 
        value: selected.locationId 
      },
      name: selected.name,
      productFamily: selected.productFamily,
      description: selected.description
    };

    if(selected.partName) {
      this.productService
        .getPartById(selected.partName)
        .subscribe(res => { 
          if(res){
            this.formGroup.reset({
              ...formData, 
              assignRoutingToPart: { text: res.name, value: res.id }
            });
          }
        }, 
        (error) => {
          this.toastr.error(`Unable to Retrieve Part Information`);
        });
    }
    else 
      this.formGroup.reset(formData); 
  }

  setOperationListOnSubmitFormUIForEdit(routeOperations: {
    operationId:number;
    name: string;
    instruction: string;
    remarks: string;
    sequence: number;
  }[]): void {

    routeOperations = orderBy(routeOperations, [{field: 'sequence', dir: 'asc'}]) ?? [];

    this.operationService.getAll().subscribe(res => {

      if(res){
      
        const dictionary = this.createOperationsDictionary(res);

        const operationList = routeOperations.map(operation=>{

          const operationId = operation.operationId;
          const name = operationId in dictionary ? dictionary[operationId].name : '';
          const resource = operationId in dictionary ? dictionary[operationId].resource : [];

          return {
            id: operationId,
            name: name,
            instruction: operation.instruction,
            comments: operation.remarks,
            sequence: operation.sequence,
            resource: resource,
            machines: resource.length
          } as RouteOperation;

        });
        
        this.operationListSubject.next(operationList);
      }
      
    });
  }

  createOperationsDictionary(operations: Operation[]): 
    {[id: number]: {name: string, resource: any[]}} 
  {
    const dictionary = {};

    operations.forEach(val => { 
      dictionary[val.id] = {
        name: val.name,
        resource: val.operationResourcePMs
      }; 
    });

    return dictionary;
  }

  onDeleteClick(event: RemoveEvent): void {
    this.customDialog.confirm().subscribe(res =>{
      if(res.primary)
        this.removeItem(event.dataItem.id);
      else
        this.refreshRoutingUIGrid();
    });
  }

  removeItem(id: number): void {
    this.routingService.delete(id).subscribe((res)=>{
      this.myGridViewSelection = [];
      if(res)
        this.toastr.success('Your data has been removed sucessfully.');
      this.refreshRoutingUIGrid();
    });
  }

  onFilter(inputValue: string): void {
    this.getRoutingObservable().subscribe((res)=>{
      const items = process(res, {
        filter: {
          logic: 'or',
          filters: ['locationName', 'name']
            .map(filter => { 
              return {
                field: filter,
                operator:'contains',
                value: inputValue
              };
            }),
        },
      }).data;
  
      this.cachedGridData = items;
      this.gridDataSubject.next(this.cachedGridData);
      this.dataBinding.skip = 0;
    });
  }

  onAddNewClick(): void {

    this.operationListSubject.next([]);

    forkJoin([
      this.locationService.getAll().pipe(
        map(res=>(res ? res.map(res => ({ name: res.name, id: res.id })) : []))
      ),
      this.productService.getProductFamilies().pipe(map(res => res ? res : []))
    ]).subscribe((res)=>{

      const locations = res[0];
      const productFamilies = res[1];

      this.setUnitDropdown(locations);

      this.setProductFamilyDropdown(productFamilies);

      if(this.unitList.length>0){
        this.setAvailableOperationsSortableList(this.unitList[0]?.value);
        this.formGroup.reset({unit: this.unitList[0]});
      }
      else {
        this.formGroup.reset();
      }

      this.formWindowFlag = 'save';
      this.showFormWindow = true;
    });
  }

  closeWindow(windowToClose: 'Form'|'AssignRoutingToProduct'|'DefineProcessTime'): void {
    this.refreshRoutingUIGrid();
    switch(windowToClose){
      case 'Form':
        this.showFormWindow = false;
        break;
      case 'AssignRoutingToProduct':
        this.showAssignRouteToProductWindowSubject.next(false);
        break;
      case 'DefineProcessTime':
        this.showDefineProcessTimeWindowSubject.next(false);
        break;
    }
  }

  submitFormWindow(): void {  

    this.createRoutingObject()
    .then((routing)=>{ 
      if(this.formWindowFlag === 'save')
        this.saveRouting(routing);
      else if(this.formWindowFlag === 'update')
        this.updateRouting(routing);
    })
    .catch((err)=>{
      console.error(err);
    });
  }

  saveRouting(routing: Routing): void {
    this.routingService.save(routing)
      .pipe(
        finalize(()=>{
          this.closeWindow('Form');
          this.formGroup.reset();
      }))
      .subscribe((res)=>{  
        if(res)
          this.toastr.success('Your data has been saved sucessfully.');
      });
  }

  updateRouting(routing: Routing): void {
    this.routingService.update(routing)
      .pipe(
        finalize(()=>{
          this.closeWindow('Form');
          this.formGroup.reset();
      }))
      .subscribe((res)=>{  
        if(res)
          this.toastr.success('Your data has been updated sucessfully.');
      });
  }

  createRoutingObject(): Promise<Routing> {

    const form = this.formGroup.value;
    const orderOfOperations = this.operationListSubject.value.map((val, index)=>{
      const operation: any = { operationId: val.id, sequence: index + 1 };
      if(this.formWindowFlag === 'update')
        operation.routeId = this.routingToEdit.id;
      return operation;
    });
    
    return this._keycloakAuth.getUserDetails()
      .then(user=>{

        let routingObject = {
          name: form.name,
          type: 1,
          locationId:form.unit.value,
          locationName:form.unit.name,
          version: 1,
          active: true,
          createdBy: this.formWindowFlag === 'save' ? user.id : this.routingToEdit.createdBy,
          modifiedBy: user.id,
          description: form.description,
          productFamily: form.productFamily,
          routeOperationPMs: orderOfOperations 
        } as Routing;

        if(this.formWindowFlag === 'update'){
          routingObject = {
            ...routingObject, 
            id: this.routingToEdit.id, 
            version: this.routingToEdit.version+1
          };        
        }
   
      const partId = form.assignRoutingToPart?.value.toString();

      if(form.assignRoutingToPart && partId){
        routingObject = {
          ...routingObject,
          partName: partId,
        }
      }

      return routingObject;

    });
  }

  refreshRoutingUIGrid(): void {
    this.getRoutingObservable().subscribe((res)=>{
      this.cachedGridData = res ?? [];
      this.gridDataSubject.next(res); 
    });
  }

  getRoutingObservable(): Observable<Routing[]> {
    return forkJoin([
      this.routingService.getAll(),
      this.getLocationsDictionary()
    ])
    .pipe(map((res)=>{

        let routings = orderBy(res[0] ?? [], [{ field: 'id', dir: 'desc' }]);
        let locations = res[1];

        return routings.map(val=>{ 
          return locations.hasOwnProperty(val.locationId) ? 
            {...val, locationName: locations[val.locationId]} : val;
        });

      })
    );
  }

  getLocationsDictionary(): Observable<{[id: number]: string}> {
    return this.locationService.getAll()
    .pipe(map(response=>{
        return response ? response.reduce((prev, cur) => ({
          ...prev, [cur.id]: cur.name
        }), {}) : {};
      })
    )
  }
  
  setUnitDropdown(locations: { name:string, id: number }[]): void {
    this.unitList = locations?.map((val)=>({ text: val.name, value: val.id })) ?? [];
  }

  onUnitDropDownItemClick(e): void {

    const itemClicked = e as { text: string, value: number };
    const unit = itemClicked?.value;

    this.setAvailableOperationsSortableList(unit);

    if(!unit || unit<=0){
      this.operationListSubject.next([]);
      this.availableOperationsSubject.next([]);
    }
  }

  setProductFamilyDropdown(productFamilies: string[]): void {
    this.productFamilyList = productFamilies?.map(val => ({ text: val })) ?? [];
  }

  onProductFamilyDropdownItemClick(e): void {
    const itemClicked = e as { text: string, value: number };
    this.setAssignRoutingToPartDropdown(itemClicked.text);
  }

  setAssignRoutingToPartDropdown(currentSelectedPartRouting: string): void {
    if(currentSelectedPartRouting !== ''){
      const partRoutings$ = this.productService.getProductFamilyProductList(currentSelectedPartRouting);
    
      partRoutings$.subscribe(res => {
        const partListRouting = res.map((val)=>{ return {text: val.name, value: val.id}; });
        this.assignRoutingToPartList.next(partListRouting);
      });
    }  
  }

  onAssignRoutingToPartChange(part: {text: string, value: number}): void {
    if(!this.formGroup.get('name')?.value){
      this.formGroup.patchValue({
        name: `R_${part.text}`
      });
    }
  }

  setAvailableOperationsSortableList(unit: number): void {
    
    if(!unit || unit<=0) return;

    this.operationService.getAll()
    .pipe(map(result => {
      return result ? result
        .filter(val => val.locationId == unit)
        .map(routeOperation => 
            <RouteOperation>{
              id: routeOperation.id,
              name: routeOperation.name,
              instruction: routeOperation.instruction,
              comments: routeOperation.comment,
              resource: routeOperation.operationResourcePMs,
              machines: routeOperation.operationResourcePMs?.length
            }
          ) : []
    }))
    .subscribe(result => {

      //Add Sortable List Header, Should not be Draggable due to id of -1
      result.unshift({
        id: -1,
        name: 'Name',
        instruction: 'Instruction',
        comments: 'Comments',
        resource: [],
        machines: 'Machines'
      });

      this.availableOperationsSubject.next(result);

    });
  }

  onAssignRoutingToProductClick(): void {

    if(this.myGridViewSelection.length>0){
      
      const initialRouting = this.cachedGridData.filter(val => val.id == this.myGridViewSelection[0]);
      
      if(initialRouting.length>0){

        const firstRouting = initialRouting[0];

        this.initialAssignRouteToProductDropdownValueSubject.next({
          text:firstRouting.name,
          value: firstRouting.id.toString()
        });

        this.showAssignRouteToProductWindowSubject.next(true);
      }
    }
  }

  onDefineProcessTimeClick(): void {
    if(this.myGridViewSelection.length>0){
      this.selectedDefineProcessTimeRoute = this.myGridViewSelection[0];
      this.showDefineProcessTimeWindowSubject.next(true);
    }
  }

  onCopyRouteClick(): void {
    
  }

  onAvailableOperationsDragStart(e: DragStartEvent): void {
    if(e.index==0){
      e.preventDefault();
    }
  }

  onOperationListSortableDragStart(e: DragStartEvent){
    if(e.index>-1){
      this.selectedItemIndexOnOperationList = e.index;
    }
  }

  onOperationListSortableDragEnd(e: DragEndEvent){

    if(this.removeOperationFromOperationList) {
      this.removeOperationFromOperationList = false;
      const indexToRemove = this.selectedItemIndexOnOperationList;
      
      this.operationListSubject.next(
        this.operationListSubject.value.filter((operation, index)=> index !== indexToRemove)
      );
    }

    this.selectedItemIndexOnOperationList = -1;
  }

  onOperationListSortableDragOver(e: DragOverEvent){

    this.removeOperationFromOperationList = false;

    if(this.selectedItemIndexOnOperationList>-1){
      this.selectedItemIndexOnOperationList = e.index;
    }
  }

  onOperationListSortableDragLeave(e: DataEvent){
    if(this.selectedItemIndexOnOperationList>-1){
      this.removeOperationFromOperationList = true;
    }
  }

}