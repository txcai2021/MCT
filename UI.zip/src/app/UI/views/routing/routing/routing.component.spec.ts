// TEST UTILITIES
import { ComponentFixture, TestBed, waitForAsync, fakeAsync, flush } from '@angular/core/testing';
import { of } from 'rxjs';

// SERVICES
import { LocationService, ProductService, RoutingService } from '@app/_services';
import { AuthKeycloakService } from '@dis/auth/auth-keycloak.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { ToastService } from '@dis/services/message/toast.service';

// MODEL & COMPOENENT
import { Routing } from '@app/_models';
import { RoutingComponent } from './routing.component';

// KENDO
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { LabelModule } from '@progress/kendo-angular-label';
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { SortableModule } from '@progress/kendo-angular-sortable';


//ANGULAR
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OperationService } from '@app/_services/operation.service';


describe('RoutingComponent', () => {

  let component: RoutingComponent;
  let fixture: ComponentFixture<RoutingComponent>;
  let debugElement: DebugElement;

  let routingService: any,
      locationService: any,
      productService: any,
      operationService: any,
      keycloakService: any,
      customDialogService: any,
      toastService: any;

  let routingDataFromDB = [{
    name:'TEST_DATA', 
    description:'LORUM IPSUM',
    locationName: "",
    locationId: 1,
    productFamily:'FRAME',
    routeOperationPMs:[{}, {}],
    noofParts: Math.floor(Math.random()*10),
    createdBy:'tester',
    modifiedBy: 'tester',
    createdDate: new Date(),
    modifiedDate: new Date()
  },
  {
    name:'TEST_DATA_2', 
    description:'LORUM IPSUM 2',
    locationId: 1,
    locationName: "",
    productFamily:'BOX',
    routeOperationPMs:[{}],
    noofParts: Math.floor(Math.random()*10),
    createdBy:'tester_2',
    modifiedBy: 'tester_2',
    createdDate: new Date(),
    modifiedDate: new Date()
  }] as Routing[];

  let locationDataFromDB = {
    $values:[{ name: 'S-MOM', id: 1 }]
  };

  let operationsDataFromDB = [
    {
      locationId: "S-MOM",
      id: 1,
      name: "BENDING",
      instruction: "Lorum Ipsum",
      comment: "Lorum",
      operationResourcePMs: new Array<any>()
    }
  ];

  let routingServiceSpy = jasmine.createSpyObj('RoutingService', ['getAll', 'delete', 'save', 'update']),
      locationServiceSpy = jasmine.createSpyObj('LocationService', ['getAll']),
      productServiceSpy = jasmine.createSpyObj('ProductService', ["getProductFamilies", "getProductFamilyPartList"]),
      operationServiceSpy = jasmine.createSpyObj('OperationService', ['getAll']),
      keycloakServiceSpy = jasmine.createSpyObj('AuthKeycloakService', ["getUserDetails"]),
      customDialogServiceSpy = jasmine.createSpyObj('CustomDialogService', ["confirm"]),
      toastServiceSpy = jasmine.createSpyObj('ToastService', ["success"]);

  beforeEach(waitForAsync (() => {

    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [ RoutingComponent ],
      imports: [
        LabelModule, 
        GridModule, 
        ButtonsModule, 
        InputsModule, 
        WindowModule, 
        FormsModule, 
        ReactiveFormsModule,
        DropDownsModule,
        SortableModule,
        BrowserModule,
        BrowserAnimationsModule
      ],
      providers: [
        {provide: RoutingService, useValue: routingServiceSpy},
        {provide: LocationService, useValue: locationServiceSpy},
        {provide: ProductService, useValue: productServiceSpy},
        {provide: OperationService, useValue: operationServiceSpy},
        {provide: AuthKeycloakService, useValue: keycloakServiceSpy},
        {provide: CustomDialogService, useValue: customDialogServiceSpy},
        {provide: ToastService, useValue: toastServiceSpy}, 
      ]
    })
    .compileComponents()
    .then(()=>{
      fixture = TestBed.createComponent(RoutingComponent);
      component = fixture.componentInstance;

      debugElement = fixture.debugElement;

      routingService = TestBed.inject(RoutingService);   
      locationService = TestBed.inject(LocationService);
      productService = TestBed.inject(ProductService);
      operationService = TestBed.inject(OperationService);
      keycloakService = TestBed.inject(AuthKeycloakService);
      customDialogService = TestBed.inject(CustomDialogService);
      toastService = TestBed.inject(ToastService);

    });

  }));

  it('should create', () => {

    routingService.getAll.and.returnValue(of(routingDataFromDB));
    locationService.getAll.and.returnValue(of(locationDataFromDB));

    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  it('should invoke refreshRoutingUIGrid() which sets gridDataSubject', ()=>{

    routingService.getAll.and.returnValue(of(routingDataFromDB));
    locationService.getAll.and.returnValue(of(locationDataFromDB));

    component.ngOnInit();
    fixture.detectChanges();



  });

  describe('onAddNewClick()', ()=>{

    beforeEach(()=>{
      routingService.getAll.and.returnValue(of(routingDataFromDB));
      productService.getProductFamilies.and.returnValue(of(['AP', 'Frame', 'Body']));
      locationService.getAll.and.returnValue(of(locationDataFromDB));
      operationService.getAll.and.returnValue(of(operationsDataFromDB));

      fixture.detectChanges();
    });

    afterEach(()=>{
      routingService.getAll.calls.reset();
      productService.getProductFamilies.calls.reset();
      locationService.getAll.calls.reset();
      operationService.getAll.calls.reset();

    });

    it('should set the unit list dropdown with specified values', fakeAsync(()=>{
  

      component.ngOnInit();
      component.onAddNewClick();

      fixture.detectChanges();
      
      flush();

    }));
  });

  describe('onEditClick()', ()=>{
    
  });

  describe('onDeleteClick()', ()=>{
    
  });

  describe('onFilter()', ()=>{
    
  });

  describe('onAssignRoutingToProductClick()', ()=>{
    
  });

  describe('onDefineProcessTimeClick()', ()=>{
    
  });
});
