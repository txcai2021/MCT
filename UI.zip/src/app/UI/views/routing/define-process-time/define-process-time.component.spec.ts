import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync, fakeAsync, flush } from '@angular/core/testing';

import { DefineProcessTimeComponent } from './define-process-time.component';
import { of } from 'rxjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GridModule } from '@progress/kendo-angular-grid';
import { LabelModule } from '@progress/kendo-angular-label';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { TreeItem, TreeViewModule } from '@progress/kendo-angular-treeview';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { OperationService, RoutingService } from '@app/_services';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';

function createRandomString(length: number): string {
  return Math.random().toString(length).slice(2);
}

function createDummyOperations(numberToCreate: number){
  const arr: any[] = [];

  for(let i=1; i<=numberToCreate; i++){
    arr.push({
      name: createRandomString(20),
      id: i
    });
  }

  return arr;
}

function createRouteOperation(operation) {
  return {
    operationName: operation.name,
    instruction: createRandomString(15),
    id: Math.floor(Math.random()*100),
    operationId: operation.id,
    operationResourcePMs: []
  };
}

function createDummyRouting(routeOperationPMs: any[]){
  return {
    id:  Math.floor(Math.random()*100),
    name: createRandomString(15),
    routeOperationPMs: routeOperationPMs
  };
}

describe('DefineProcessTimeComponent', () => {

  let component: DefineProcessTimeComponent;
  let fixture: ComponentFixture<DefineProcessTimeComponent>;
  let debugElement: DebugElement;
  
  let routingServiceSpy = jasmine.createSpyObj('RoutingService', ['getById', 'updateRouteOperationInstruction']);
  let operationServiceSpy = jasmine.createSpyObj('OperationService', ['getAll', 'getProcessTimeByRouteId', 'updateProcessTimeByRouteId']);

  let routingService, operationService;

  let operationsData = createDummyOperations(3);
  let aSubsetOfOperations = operationsData.slice(0,2);

  let routingData = createDummyRouting(aSubsetOfOperations.map(createRouteOperation));

  let operationResourceData = [{
    id: 1,
    routeId:routingData.id,
    routeOperationId: routingData.routeOperationPMs[0].id,
    resourceName: "TEST_RESOURCE",
    isDefault: true,
    pretime: 25,
    posttime: 5,
    productionRate: 15,
    prodRateUoM: 200,
    cost: 1,
    hourlyRate: 1,
    uomList: [
      {
        id: 1,
        uomId: 100,
        description: "Minutes"
      }, 
      {
        id: 2,
        uomId: 200,
        description: "Hours"
      }
    ]
  },
  {
    id: 2,
    routeId:routingData.id,
    routeOperationId: routingData.routeOperationPMs[0].id,
    isDefault: false,
    resourceName: "TEST_RESOURCE_2",
    pretime: 5,
    posttime: 25,
    productionRate: 5,
    prodRateUoM: 100,
    cost: 1,
    hourlyRate: 1,
    uomList: [
      {
        id: 1,
        uomId: 100,
        description: "Minutes"
      }
    ]
  }];

  function initializeComponent() {
    return TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [ DefineProcessTimeComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        GridModule,
        DropDownsModule,
        LabelModule,
        InputsModule,
        WindowModule,
        ButtonsModule,
        TreeViewModule,
        LayoutModule,
        BrowserModule,
        BrowserAnimationsModule
      ],
      providers: [
        {provide: RoutingService, useValue: routingServiceSpy},
        {provide: OperationService, useValue: operationServiceSpy}
      ]
    })
    .compileComponents();
  }

  function createFixture(){
    fixture = TestBed.createComponent(DefineProcessTimeComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
  }

  function injectServices(){
    routingService = TestBed.inject(RoutingService);
    operationService = TestBed.inject(OperationService);
  }

  function resetFunctionCalls(){
    routingService.getById.calls.reset();
    routingService.updateRouteOperationInstruction.calls.reset();

    operationService.getAll.calls.reset();
    operationService.getProcessTimeByRouteId.calls.reset();
    operationService.updateProcessTimeByRouteId.calls.reset();
  }

  function setDefaultFunctionReturnValues(){
    routingService.getById.and.returnValue(of(routingData));
    routingService.updateRouteOperationInstruction.and.returnValue(of({}));

    operationService.getAll.and.returnValue(of(operationsData));
    operationService.getProcessTimeByRouteId.and.returnValue(of(operationResourceData));
    operationService.updateProcessTimeByRouteId.and.returnValue(of({}));
  }

  describe('Initialize Component', ()=>{
    beforeEach(waitForAsync(()=>{
      initializeComponent()
      .then(()=>{
        createFixture();
        injectServices();
        setDefaultFunctionReturnValues();
      });
    }));

    afterEach(resetFunctionCalls);

    it('should create', () => {
      expect(component).toBeTruthy();
    });
  });

  describe('Initialize UI', ()=>{

    let closeWindowEmit;

    beforeEach(waitForAsync(()=>{
      initializeComponent()
      .then(()=>{
        createFixture();
        injectServices();
        setDefaultFunctionReturnValues();
      });
    }));

    afterEach(resetFunctionCalls);

    it('should correctly set kendo tree view component', fakeAsync(()=>{
      
      //Setup
      component.selectedRouteId = routingData.id; //Set to more than -1

      fixture.detectChanges();
      flush();

      //Assert
      component.nestedTreeView$.subscribe(res=>{
        expect(res.length).toBe(1);
        expect(res[0].text).toBe(routingData.name);
        expect(res[0].items.length).toBe(routingData.routeOperationPMs.length);

        res[0].items.forEach((operation, index) => {
          const routeOperationId = routingData.routeOperationPMs[index].id;
          const operationId = routingData.routeOperationPMs[index].operationId;
          expect(operation.value.routeOperationId).toBe(routeOperationId);
          expect(operation.text).toBe(routingData.routeOperationPMs[index].operationName);
        });
        
      });

      flush();

    }));

    it('should not set tree view if route id is less than 0', fakeAsync(()=>{

      //Setup
      component.selectedRouteId = -1; //Set to more than -1
      closeWindowEmit = spyOn(component.closeWindow, 'emit');

      fixture.detectChanges();
      flush();

      //Assert
      component.nestedTreeView$.subscribe(res=>{
        expect(res.length).toBe(0);
      });

      expect(closeWindowEmit).toHaveBeenCalledOnceWith(true);
      flush();

    }))

  });

  describe('Operation Resource Grid View', ()=>{
    beforeEach(waitForAsync(()=>{
      initializeComponent()
      .then(()=>{
        createFixture();
        injectServices();
        setDefaultFunctionReturnValues();
      });
    }));

    afterEach(resetFunctionCalls);

    it('should update resource grid view with the correct routeOperation\'s resources', fakeAsync(()=>{
      
      //Setup
      const routeOperationId = operationResourceData[0].routeOperationId;
      component.selectedRouteId = routingData.id;

      fixture.detectChanges(); //ngOnInit
      flush();

      //Act
      component.onOperationNodeClick({
        item:{ 
          dataItem: { 
            value: {
              routeOperationId: routeOperationId,
              instruction: createRandomString(15)
            },
            items: []
          } 
        } as TreeItem
      });

      fixture.detectChanges();
      flush();

      //Assert
      component.resourceGridView$.subscribe(res=>{
        expect(res.length).toBe(operationResourceData.length);

        res.forEach((resource, index)=>{
          expect(resource.id).toBe(operationResourceData[index].id);
          expect(resource.routeOperationId).toBe(routeOperationId);
          expect(resource.resourceName).toBe(operationResourceData[index].resourceName);
          expect(resource.setupTime).toBe(operationResourceData[index].pretime);
          expect(resource.transitTime).toBe(operationResourceData[index].posttime);

          expect(resource.productionRate).toBe(operationResourceData[index].productionRate);
          expect(resource.unitOfMeasurement).toBe(operationResourceData[index].prodRateUoM);
          expect(resource.unitPrice).toBe(operationResourceData[index].cost);
          //expect(resource.hourlyRate).toBe(operationResourceData[index].hourlyRate);
        });

      });

      flush(); 

    }));

    it('should set correct operation\'s resource when changing setup time', fakeAsync(()=>{

      //Setup
      const routeOperationId = operationResourceData[0].routeOperationId;
      const rowIndex = 0;
      const input = "5";
      const resourceVM = {
        routeOperationId: routeOperationId
      } as any;

      component.selectedRouteId = routingData.id;

      fixture.detectChanges();
      flush();

      //Act
      component.onOperationNodeClick({
        item:{ 
          dataItem: { 
            value: {
              routeOperationId: routeOperationId,
              instruction: createRandomString(15)
            },
            items: []
          } 
        } as TreeItem
      });

      fixture.detectChanges();
      flush();

      component.onSetupTimeChange(rowIndex, resourceVM, input);
      
      //Assert
      const resources = component.cachedRouteOperationInformation[routeOperationId].resources;
      expect(resources[rowIndex].setupTime).toBe(parseInt(input));
      expect(resources[rowIndex].routeOperationId).toBe(routeOperationId);

    }));

    it('Should set correct operation\'s resource when changing transit time', fakeAsync(()=>{

      //Setup
      const routeOperationId = operationResourceData[0].routeOperationId;
      const rowIndex = 0;
      const input = "3";
      const resourceVM = { routeOperationId: routeOperationId } as any;

      component.selectedRouteId = routingData.id;

      fixture.detectChanges();
      flush();

      //Act
      component.onOperationNodeClick({
        item:{ 
          dataItem: { 
            value: {
              routeOperationId: routeOperationId,
              instruction: createRandomString(15)
            },
            items: []
          } 
        } as TreeItem
      });
      fixture.detectChanges();
      flush();
      component.onTransitTimeChange(rowIndex, resourceVM, input);

      //Assert
      const resources = component.cachedRouteOperationInformation[routeOperationId].resources;
      expect(resources[rowIndex].transitTime).toBe(parseInt(input));
      expect(resources[rowIndex].routeOperationId).toBe(routeOperationId);

    }));


    it('should set correct operation\'s resource when changing production rate', fakeAsync(()=>{

      //Setup
      const routeOperationId = operationResourceData[0].routeOperationId;
      const rowIndex = 0;
      const input = "5";

      component.selectedRouteId = routingData.id;

      const resourceVM = {
        routeOperationId: routeOperationId
      } as any;

      fixture.detectChanges();
      flush();
    
      //Act
      component.onOperationNodeClick({
        item:{ 
          dataItem: { 
            value: {
              routeOperationId: routeOperationId,
              instruction: createRandomString(15)
            },
            items: []
          } 
        } as TreeItem
      });

      fixture.detectChanges();
      flush();

      component.onProductionRateChange(rowIndex, resourceVM, input);
      
      //Assert
      const resources = component.cachedRouteOperationInformation[routeOperationId].resources;
      expect(resources[rowIndex].productionRate).toBe(parseInt(input));
      expect(resources[rowIndex].routeOperationId).toBe(routeOperationId);

    }));


    it('should set correct operation\'s resource when changing unit of measurement', fakeAsync(()=>{

      //Setup
      const routeOperationId = operationResourceData[0].routeOperationId;
      const rowIndex = 0;
      const input = "242";

      const selectedRouteId = routingData.id;
      component.selectedRouteId = selectedRouteId;

      const resourceVM = {
        routeOperationId: routeOperationId,
        unitOfMeasurement: parseInt(input),
        uomList: [{ uomId: 242 }, { uomId: 243 }]
      } as any;

      fixture.detectChanges();
      flush();

      //Act
      component.onOperationNodeClick({
        item:{ 
          dataItem: { 
            value: {
              routeOperationId: routeOperationId,
              instruction: createRandomString(15)
            },
            items: []
          } 
        } as TreeItem
      });

      fixture.detectChanges();
      flush();

      component.onUnitOfMeasurementChange(rowIndex, resourceVM, input);
      
      //Assert
      const resources = component.cachedRouteOperationInformation[routeOperationId].resources;
      expect(resources[rowIndex].unitOfMeasurement).toBe(parseInt(input));
      expect(resources[rowIndex].routeOperationId).toBe(routeOperationId);
    }));

    it('should duplicate resource values onto all the other resource rows', fakeAsync(()=>{
      
      //Setup
      const routeOperationId = operationResourceData[0].routeOperationId;
      const resourceVMToDuplicate = component
        .convertOperationResourceToResourceVM(operationResourceData[1]);
      
      component.selectedRouteId = routingData.id;

      fixture.detectChanges();
      flush();

      //Act
      component.onOperationNodeClick({
        item:{ 
          dataItem: { 
            value: {
              routeOperationId: routeOperationId,
              instruction: createRandomString(15)
            },
            items: []
          } 
        } as TreeItem
      });

      component.onCopyClick(1, resourceVMToDuplicate);

      fixture.detectChanges();
      flush();

      //Assert
      component.resourceGridView$.subscribe(res=>{
        expect(res.length).toBe(operationResourceData.length);
        res.forEach(resource => {
          expect(resource.setupTime).toBe(operationResourceData[1].pretime);
          expect(resource.transitTime).toBe(operationResourceData[1].posttime);
          expect(resource.productionRate).toBe(operationResourceData[1].productionRate);
          expect(resource.unitOfMeasurement).toBe(operationResourceData[1].prodRateUoM);
        });
      });

      flush();
      
    }));

    it('should correctly change default selected resource', fakeAsync(()=>{

      //Setup
      const routeOperationId = operationResourceData[0].routeOperationId;
      const idOfResourceToSelect = operationResourceData[1].id;

      component.selectedRouteId = routingData.id;
    
      fixture.detectChanges();
      flush();

      //Act
      component.onOperationNodeClick({
        item:{ 
          dataItem: { 
            value: {
              routeOperationId: routeOperationId,
              instruction: createRandomString(15)
            },
            items: []
          } 
        } as TreeItem
      });

      fixture.detectChanges();
      flush();

      component.setDefaultResourceByPosition(routeOperationId, 1);

      //Assert
      expect(component.cachedRouteOperationInformation
        [routeOperationId].resources[0].isDefault).toBeFalse();
      expect(component.cachedRouteOperationInformation
        [routeOperationId].resources[1].isDefault).toBeTrue();
      expect(component.resourceGridViewSelection
        .filter(id=>id==idOfResourceToSelect).length).toBe(1);

    }));

  });

  describe('Operation Instructions', ()=>{

    beforeEach(
      waitForAsync(()=>{
        initializeComponent()
        .then(()=>{
          createFixture();
          injectServices();
          setDefaultFunctionReturnValues();
        });
    }));

    afterEach(resetFunctionCalls);

    it('should correctly set and update instructions', fakeAsync(()=>{

      //Setup
      const routeId = routingData.id;
      component.selectedRouteId = routeId

      const routeOperationId = routingData.routeOperationPMs[0].id
      const routeOperationId2 = routingData.routeOperationPMs[1].id

      const newInstruction = "CHANGE_INSTRUCTION";

      const data = {
        [routeOperationId]: {
          id: 1,
          resources: [],
          instruction: {
            description: "TEST_INSTRUCTION",
            isDirty: false
          }
        },
        [routeOperationId2]: {
          id: 2,
          resources: [],
          instruction: {
            description: "TEST_INSTRUCTION_2",
            isDirty: false
          }
        }
      }

      fixture.detectChanges();
      flush();

      component.cachedRouteOperationInformation = data;

      //Act
      component.formGroup.patchValue({ selectedRouteOperationId: routeOperationId });

      component.onInstructionChange(newInstruction);
      component.updateRouteOperationInstructions();
      fixture.detectChanges();
      flush();

      //Assert
      expect(routingService.updateRouteOperationInstruction)
      .toHaveBeenCalledOnceWith(routeId, jasmine.any(Object));

      expect(component.cachedRouteOperationInformation[routeOperationId].instruction.isDirty).toBeFalse();
      expect(component.cachedRouteOperationInformation[routeOperationId2].instruction.isDirty).toBeFalse();
    }));

  });

  describe('Saving changes', ()=>{

    let closeWindowEmit;

    beforeEach(waitForAsync(()=>{
      initializeComponent()
      .then(()=>{
        createFixture();
        injectServices();
        setDefaultFunctionReturnValues();
      });
    }));

    afterEach(resetFunctionCalls);

    it('should save changes made to current selected route operation', fakeAsync(()=>{

      //Setup
      const selectedRouteId = routingData.id;
      const data = { 
        1: {
          resources: [
            component.convertOperationResourceToResourceVM(operationResourceData[0]),
            component.convertOperationResourceToResourceVM(operationResourceData[1])
          ], 
          instruction: {
            description: "", 
            isDirty: false
          }
        }
      };

      const flatArray = [...data[1].resources ]
      .map(component.convertResourceVMForDataBaseUpdate);

      component.selectedRouteId = selectedRouteId;
      component.cachedRouteOperationInformation = data;

      fixture.detectChanges();
      flush();

      //Act
      component.onApply();
      fixture.detectChanges();
      flush();

      //Assert
      expect(operationService.updateProcessTimeByRouteId)
      .toHaveBeenCalledOnceWith(selectedRouteId, flatArray);

    }));

    it('should save changes made to all operations modified on clicking Save Button', fakeAsync(()=>{

      //Setup
      const selectedRouteId = routingData.id;
      const data = { 
        1: {
          resources: [
            component.convertOperationResourceToResourceVM(operationResourceData[0]),
            component.convertOperationResourceToResourceVM(operationResourceData[1])
          ], 
          instruction: {
            description: "", 
            isDirty: false
          }
        }
      };

      const flatArray = [...data[1].resources ]
      .map(component.convertResourceVMForDataBaseUpdate);

      component.selectedRouteId = selectedRouteId;
      component.cachedRouteOperationInformation = data;

      closeWindowEmit = spyOn(component.closeWindow, 'emit');
      fixture.detectChanges();
      flush();

      //Act
      component.onSave();
      fixture.detectChanges();
      flush();

      //Assert
      expect(operationService.updateProcessTimeByRouteId)
      .toHaveBeenCalledOnceWith(selectedRouteId, flatArray);
      expect(closeWindowEmit).toHaveBeenCalledOnceWith(true);

    }));

  });



});
