import { Route } from '@angular/compiler/src/core';
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Routing } from '@app/_models';
import { OperationService, RoutingService } from '@app/_services';
import { EditEvent } from '@progress/kendo-angular-grid';
import { TreeItem } from '@progress/kendo-angular-treeview';
import { BehaviorSubject, forkJoin, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

import * as _ from 'lodash';
import { ToastService } from '@dis/services/message/toast.service';

interface OperationsTreeNode<T> {
  text: string;
  value: T;
  items: Array<OperationsTreeNode<T>>;
}

interface ResourceVM {
  id: number;
  routeId: number;
  routeOperationId: number;
  operationId: number;
  isDefault: boolean;

  resourceName: string;
  setupTime: number;
  transitTime: number;
  productionRate: number;
  unitOfMeasurement: number;
  unitPrice: number;
  hourlyRate: number;
  uomList: Uom[];
}

interface Uom {
  id: number;
  codeNo: string;
  codeTypeId: number;
  description: string;
  rateId: number;
  uomId: number;
}

interface RouteOperations {
  [id: number]: {
    resources: ResourceVM[]
    instruction: {
      description: string;
      isDirty: boolean;
    }
  }
}

@Component({
  selector: '[app-define-process-time]',
  templateUrl: './define-process-time.component.html',
  styleUrls: ['./define-process-time.component.scss']
})
export class DefineProcessTimeComponent implements OnInit, OnDestroy {

  @Output() closeWindow = new EventEmitter<boolean>();
  @Input() selectedRouteId: number = -1;

  cachedRouting: Routing;

  nestedTreeViewSubject = new BehaviorSubject<OperationsTreeNode<{routeOperationId: number, instruction: string}>[]>([]);
  nestedTreeView$ = this.nestedTreeViewSubject.asObservable();

  cachedRouteOperationInformation: RouteOperations = {};

  resourceGridViewSubject = new BehaviorSubject<ResourceVM[]>([]);
  resourceGridView$ = this.resourceGridViewSubject.asObservable();

  resourceGridViewSelection = new Array<number>();

  expandedKeys: any[] = [];

  data = {
    instruction: "",
    selectedRouteOperationId: -1
  };

  formGroup: FormGroup;

  constructor(
    private routingService: RoutingService,
    private operationService: OperationService,
    private toastr: ToastService
  ){ 

    const formControls = Object.keys(this.data).reduce((prev, cur)=>{
      return {...prev, [cur]: new FormControl(this.data[cur])}
    }, {});

    this.formGroup = new FormGroup(formControls);
  }

  ngOnInit(): void {
    if(this.selectedRouteId>-1){

      forkJoin([
        this.routingService.getById(this.selectedRouteId),
        this.retrieveAndGroupOperationProcessTimeByRouteOperationId(this.selectedRouteId)
      ])
      .pipe(map(res=>{
        return { route: <Routing>(res[0] ?? {}), routeOperationResources: res[1] };
      }))
      .subscribe(res=>{

      this.cachedRouting = res.route;
      this.expandedKeys = ['0'];

      const items: any[] = res.route.routeOperationPMs
        .map(routeOperation=>{
          const routeOperationId = routeOperation.id;
          const instruction = routeOperation.instruction;
          const operationName = routeOperation.operationName

          if(res.routeOperationResources.hasOwnProperty(routeOperationId)){
            res.routeOperationResources[routeOperationId].instruction = {
              description: instruction,
              isDirty: false
            };
          }

          return { 
            text: operationName, 
            value: { routeOperationId: routeOperationId, instruction: instruction }, 
            items: [] 
          };
        }) ?? [];

        this.cachedRouteOperationInformation = res.routeOperationResources;

        this.nestedTreeViewSubject.next([{ 
          text: res.route?.name, 
          value: { instruction: "", routeOperationId: -1 }, 
          items: items 
        }]);

      });
    }
    else
      this.closeWindow.emit(true);
  }

  setResourcesGridByRouteOperationId(id: number): void {
    const containsCachedResourceInfo =
      this.cachedRouteOperationInformation.hasOwnProperty(id);

      if(containsCachedResourceInfo){
        this.resourceGridViewSubject.next(
          this.cachedRouteOperationInformation[id].resources);

        this.setDefaultResourceCheckBox(id);
      }
  }

  retrieveAndGroupOperationProcessTimeByRouteOperationId(routeId: number): 
    Observable<RouteOperations> {

    return this.operationService.getProcessTimeByRouteId(routeId)
      .pipe(map(res=>{

        const result: RouteOperations = {};

        if(res){
          res.map(this.convertOperationResourceToResourceVM)
           .forEach((resourceVM: ResourceVM)=> {

            resourceVM.routeId = this.selectedRouteId;

            if(!result.hasOwnProperty(resourceVM.routeOperationId)) {
              result[resourceVM.routeOperationId] = {
                resources: [],
                instruction: { description: "", isDirty: false }
              }
            }

            result[resourceVM.routeOperationId].resources = [
              ...result[resourceVM.routeOperationId].resources, 
              resourceVM
            ];
          });
        }

        return result;

      }));
  }

  convertOperationResourceToResourceVM(operationResource): ResourceVM {
    return {
      id: operationResource.id,
      routeId: operationResource.routeId,
      routeOperationId: operationResource.routeOperationId,
      operationId: operationResource.operationId,
      isDefault: operationResource.isDefault,
      resourceName: operationResource.resourceName,
      setupTime: operationResource.pretime,
      transitTime: operationResource.posttime,
      productionRate: operationResource.productionRate,
      unitOfMeasurement: operationResource.prodRateUoM,
      unitPrice: operationResource.cost,
      //hourlyRate: ,
      uomList: operationResource.uomList?.map(uom=>({
        id: uom.id,
        codeNo: uom.codeNo,
        codeTypeId: uom.codeTypeId,
        description: uom.description,
        rateId: uom.rateId,
        uomId: uom.uomId
      } as Uom))
    } as ResourceVM;
  }

  createOperationsDictionary(
    operations: Array<{ 
      name:string, 
      id: number, 
      operationResourcePMs: any[] 
    }>
  ): {[id: number]: { name: string, resource: any[] }} 
  {
    const dictionary = {};

    operations.forEach(val => { 
      dictionary[val.id] = {
        name: val.name,
        resource: val.operationResourcePMs
      }; 
    });

    return dictionary;
  }

  convertResourceVMForDataBaseUpdate(resource: ResourceVM) {
    return {
      id: resource.id,
      routeId: resource.routeId,
      pretime:resource.setupTime,
      posttime: resource.transitTime,
      productionRate: resource.productionRate,
      prodRateUoM:resource.unitOfMeasurement,
      isDefault: resource.isDefault
    };
  }
  
  onOperationNodeClick(event: { item: TreeItem }): void {
    const routeOperation = event.item.dataItem as OperationsTreeNode<{
      routeOperationId: number, 
      instruction: string
    }>;

    if(routeOperation.value?.routeOperationId>0){
      this.formGroup.patchValue({ 
        instruction: routeOperation.value?.instruction,
        selectedRouteOperationId: routeOperation.value.routeOperationId
      });
      this.setResourcesGridByRouteOperationId(routeOperation.value.routeOperationId);
    }
    else if(routeOperation.value?.routeOperationId===-1){
      if(this.expandedKeys.length>0)
        this.expandedKeys.pop();
      else
        this.expandedKeys.push('0');
    }
  }

  onCopyClick(rowIndex: number, dataItem: ResourceVM): void {
    if(this.cachedRouteOperationInformation.hasOwnProperty(dataItem.routeOperationId)){
      const dataToDuplicate = {
        setupTime: dataItem.setupTime,
        transitTime: dataItem.transitTime,
        productionRate: dataItem.productionRate,
        unitOfMeasurement: dataItem.unitOfMeasurement
      };

      this.cachedRouteOperationInformation[dataItem.routeOperationId].resources =
        this.cachedRouteOperationInformation[dataItem.routeOperationId].resources
          .map(resource=>({ ...resource, ...dataToDuplicate }));

      this.resourceGridViewSubject.next(
        this.cachedRouteOperationInformation[dataItem.routeOperationId].resources
      );
    }
  }

  onApply(): void {

    const operationResources = this.retrieveAllCachedOperationResourceAsFlatArray();

    this.updateProcessTime(
      operationResources.map(this.convertResourceVMForDataBaseUpdate)
    )
    .subscribe(res=>{
      if(res){
        this.toastr.success("Your data has been saved successfully.");
      }
    });

    this.updateRouteOperationInstructions();
  }

  onSave(): void {

    const operationResources = this.retrieveAllCachedOperationResourceAsFlatArray();

    this.updateProcessTime(
      operationResources.map(this.convertResourceVMForDataBaseUpdate)
    )
    .subscribe(res=>{
      if(res){
        this.toastr.success("Your data has been saved successfully.");
        this.closeWindow.emit(true);
      }
    });

    this.updateRouteOperationInstructions();
  }

  retrieveAllCachedOperationResourceAsFlatArray(): ResourceVM[] {
    return Object.values(this.cachedRouteOperationInformation)
      .map(routeOperation=>routeOperation?.resources ?? [])
      .reduce((prev, cur)=>[
        ...prev, ...(cur)
      ], []);
  }

  retrieveAllDirtyRouteOperationInstructions() {
    return Object.keys(this.cachedRouteOperationInformation)
     .reduce((prev, cur)=>{
       if(this.cachedRouteOperationInformation[cur].instruction.isDirty) {
        prev.push({
          id: cur,
          instruction: this.cachedRouteOperationInformation[cur].instruction.description,
        })
      }
      return prev;
     }, []);
  }

  updateProcessTime(data: any): Observable<any> {
    return this.operationService
      .updateProcessTimeByRouteId(this.selectedRouteId, data);
  }

  updateRouteOperationInstructions() {
    const dirtyInstructions = this.retrieveAllDirtyRouteOperationInstructions()
      .reduce((prev,cur)=>({
        ...prev, [cur.id]: cur.instruction 
      }), {});

    this.cachedRouting.routeOperationPMs = this.cachedRouting.routeOperationPMs
    .map(routeOperation=>{
      if(dirtyInstructions.hasOwnProperty(routeOperation.id))
        routeOperation.instruction = dirtyInstructions[routeOperation.id];
      return routeOperation;
    });

    if(Object.keys(dirtyInstructions).length>0){
      this.routingService.updateRouteOperationInstruction(
        this.selectedRouteId,
        this.cachedRouting
      ).subscribe(res=>{
        if(res)
          this.resetAllDirtyInstructions();
      });
    }
  }

  resetAllDirtyInstructions(): void {
    Object.keys(this.cachedRouteOperationInformation).forEach(key => {
      this.cachedRouteOperationInformation[key].instruction.isDirty = false;
    });
  }

  onClose(): void {
    this.closeWindow.emit(true);
  }
  
  ngOnDestroy(): void {
    this.closeWindow.unsubscribe();
  }

  onSetupTimeChange(rowIndex: number, dataItem: ResourceVM, input: string): void {

    const setupTime = parseInt(input);

    if(setupTime>-1){
      this.setOperationResourceAttribute({
        routeOperationId: dataItem.routeOperationId,
        rowIndex: rowIndex,
        attributeName: "setupTime",
        valueToSet: setupTime
      });
    }
  }

  onTransitTimeChange(rowIndex: number, dataItem: ResourceVM, input: string): void {

    const transitTime = parseInt(input);

    if(transitTime>-1){
      this.setOperationResourceAttribute({
        routeOperationId: dataItem.routeOperationId,
        rowIndex: rowIndex,
        attributeName: "transitTime",
        valueToSet: transitTime
      });
    }
  }

  onProductionRateChange(rowIndex: number, dataItem: ResourceVM, input: string): void {

    const productionRate = parseInt(input);

    if(productionRate>-1){
      this.setOperationResourceAttribute({
        routeOperationId: dataItem.routeOperationId,
        rowIndex: rowIndex,
        attributeName: "productionRate",
        valueToSet: productionRate
      });
    }
  }

  onUnitOfMeasurementChange(rowIndex: number, dataItem: ResourceVM, input: string): void {

    const unitOfMeasurement = parseInt(input); 
    const filterUomId = dataItem.uomList.filter(uom=>uom.uomId==unitOfMeasurement);

    if(unitOfMeasurement>-1 && 
      filterUomId.length>0)
    {
      this.setOperationResourceAttribute({
        routeOperationId: dataItem.routeOperationId,
        rowIndex: rowIndex,
        attributeName: "unitOfMeasurement",
        valueToSet: unitOfMeasurement
      });
    }
  }

  onInstructionChange(input): void {
    const routeOperationId = parseInt(this.formGroup.get("selectedRouteOperationId").value);

    if(routeOperationId>0){
      this.cachedRouteOperationInformation[routeOperationId].instruction = {
        description: input,
        isDirty: true
      };
    }
  }

  setOperationResourceAttribute(
    data: {
      routeOperationId: number, 
      rowIndex: number, 
      attributeName: string
      valueToSet: any
    } 
  ){
    if(data.rowIndex>=0 && 
      this.cachedRouteOperationInformation
      .hasOwnProperty(data.routeOperationId)) 
    {
      this.cachedRouteOperationInformation
        [data.routeOperationId].resources[data.rowIndex][data.attributeName] = data.valueToSet;
    }
  }

  setDefaultResourceCheckBox(routeOperationId: number): void {

    if(this.cachedRouteOperationInformation
      .hasOwnProperty(routeOperationId))
    {

      const positionIsDefault = 
        this.cachedRouteOperationInformation[routeOperationId].resources
          .findIndex(element=>element.isDefault);

      if(positionIsDefault!=-1){

        const resourceId = this.cachedRouteOperationInformation
          [routeOperationId].resources[positionIsDefault].id; 

        this.resourceGridViewSelection = [resourceId];
      }
    }
  }

  setDefaultResourceByPosition(routeOperationId: number, newIndex: number) {

    const currentPositionIsDefault = 
      this.cachedRouteOperationInformation[routeOperationId].resources
        .findIndex(element=>element.isDefault);

    if(newIndex!=currentPositionIsDefault){
      this.cachedRouteOperationInformation
        [routeOperationId].resources[currentPositionIsDefault].isDefault = false;
      this.cachedRouteOperationInformation
        [routeOperationId].resources[newIndex].isDefault = true;

    }

    this.setDefaultResourceCheckBox(routeOperationId);
  }

}
