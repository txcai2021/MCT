import { Component, Input, Output, EventEmitter, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ProductService, RoutingService } from '@app/_services';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { ToastService } from '@dis/services/message/toast.service';
import { BehaviorSubject, Observable } from 'rxjs';

import { process } from '@progress/kendo-data-query';
import { DataBindingDirective } from '@progress/kendo-angular-grid';
import { map } from 'rxjs/operators';

@Component({
  selector: '[app-assign-routing-to-product]',
  templateUrl: './assign-routing-to-product.component.html',
  styleUrls: ['./assign-routing-to-product.component.scss']
})
export class AssignRoutingToProductComponent implements OnDestroy, OnInit {

  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;

  formGroup: FormGroup;

  @Output() closeWindow = new EventEmitter<boolean>();

  data = {
    route: {text: '', value: ''},
    filter: ""
  };
  
  @Input() initialDropdownValue: {text: string, value: string} = {text: "", value: ""};
  routingDropdownList = new BehaviorSubject<Array<{text: string, value: string}>>([]);

  cachedGridData : any[];
  gridDataSubject = new BehaviorSubject<{ 
    id: number;
    productNo: string;
    revision:string;
    productName: string;
    partFamily: string;
    routeName: string;
    familyRouteName: string;
    productType: string; }[]>
  ([]);

  gridView = this.gridDataSubject.asObservable();
  gridViewSelection: any[] = [];

  constructor(
    private customDialog: CustomDialogService, 
    private routingService: RoutingService,
    private productService: ProductService,
    private toastr: ToastService 
  ) { 

    this.formGroup = new FormGroup({
      route: new FormControl(this.data.route),
      filter: new FormControl(this.data.filter)
    });
    
  }

  ngOnInit(): void {
    this.setDropdownList('initialize');
    this.refreshAssignRoutingToProductUIGrid();
  }

  onResetButtonClick(): void {
    if(this.gridViewSelection.length > 0 ){
      this.customDialog.confirm().subscribe((res)=>{

        if(res.primary){

          const payload = this.gridViewSelection;

          this.routingService.resetProductRoutes(payload).subscribe(res => {
            if(res)
              this.toastr.success('Product(s) Route has been successfully reset.');
            this.onFilter();

          });
        }   
      });
    }
  }

  onApplyButtonClick(filter: string): void {

    const form = this.formGroup.value;

    if(this.gridViewSelection.length>0){

      const routeId = form.route ? form.route.value : "";
      const routeName = form.route ? form.route.text : "";

      this.routingService.updateProductRoute(routeId, this.gridViewSelection)
        .subscribe(res => {
          this.toastr.success(`Selected Product(s) Route has been updated sucessfully to ${routeName}`);
          this.onFilter();
        }, (error) => {
          console.error(error);
        });
    }
  }

  setDropdownList(state: 'initialize' | 'update'): void {

    this.routingService.getAll().subscribe(res => {

      const useRoute = state == 'initialize' ? this.initialDropdownValue : this.formGroup.value.route;

      if(res){
        this.routingDropdownList.next(
          res.map(val => { 
            return { text: val.name, value: val.id.toString() }; 
          })
        );

        this.formGroup.reset({
          route: useRoute,
          filter: this.formGroup.value.filter
        });
      }
    });
  }

  refreshAssignRoutingToProductUIGrid(): void {
    this.getFormattedProductListWithRoutingObservable().subscribe(res => {
      if(res)
        this.gridDataSubject.next(res);
    });
  }

  getFormattedProductListWithRoutingObservable(): Observable<any> {
    return this.productService
      .getProductListWithRouting()
      .pipe(map(products => products.map(product => {
          return {
            id: product.id,
            productNo: product.name,
            revision: product.revision,
            productName: product.description,
            partFamily: product.partFamily,
            routeName: product.routeName,
            familyRouteName: product.familyRouteName,
            productType: product.productType
          };
      })));
  } 

  onFilter(): void {

    this.getFormattedProductListWithRoutingObservable()
      .subscribe(res => {

        const form = this.formGroup.value;

        const items = process(res, {
          filter: {
            logic: 'or',
            filters: ['productNo', 'productName', 'routeName']
              .map(filter => { 
                return {
                  field:filter,
                  operator:'contains',
                  value:form.filter
                }; 
              }),
          },
        }).data;

        this.gridViewSelection = [];
        this.gridDataSubject.next(items);
        this.dataBinding.skip = 0;

    });  
  }

  onCancelClick(): void {
    this.closeWindow.emit(true);
  }

  onClose(): void {
    this.closeWindow.emit(true);
  }

  ngOnDestroy() {
    this.closeWindow.unsubscribe();
  }

}
