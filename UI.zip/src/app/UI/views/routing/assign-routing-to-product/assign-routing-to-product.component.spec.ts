import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignRoutingToProductComponent } from './assign-routing-to-product.component';

describe('AssignRoutingToProductComponent', () => {
  let component: AssignRoutingToProductComponent;
  let fixture: ComponentFixture<AssignRoutingToProductComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssignRoutingToProductComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignRoutingToProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
