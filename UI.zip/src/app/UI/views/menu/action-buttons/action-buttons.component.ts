import { Component, EventEmitter,  Input,  OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Menu, User } from '@app/_models';
import { AccountService, MenuService } from '@app/_services';
import { filterBy } from '@progress/kendo-data-query';

@Component({
  selector: 'app-action-buttons',
  templateUrl: './action-buttons.component.html',
  styleUrls: ['./action-buttons.component.less']
})
export class ActionButtonsComponent implements OnInit {

  @Output()
  click: EventEmitter<string> = new EventEmitter<string>();

  @Input() buttonList;

  user: User;

  buttonsList: Menu[] = [];
  constructor(
    private menuService: MenuService,
    private accountService: AccountService,
    private route: ActivatedRoute
  ) {
    this.user = this.accountService.userValue;
  }

  ngOnInit(): void {
    //console.log(JSON.stringify(this.buttonList));

   // this.menuService.getMenu(this.user.roles.toString(), "Security")
  }

  checkValid(buttontext: string): boolean {
    if (this.buttonsList) {
      var isValid = filterBy(this.buttonsList, {
        logic: 'and',
        filters: [
          {
            operator: 'eq',
            value: buttontext,
            field: 'buttonText',
            ignoreCase: true,
          },
        ],
      });

      if (isValid.length > 0) return true;
      else return false;
    }
    return false;
  }

  getImageUrl(imgURL: string): string {
    var lastPart = imgURL.split('/').pop();
    return '../../assets/img/' + lastPart;
  }

  open(buttonText: string) {
    this.click.emit(buttonText);
  }

}
