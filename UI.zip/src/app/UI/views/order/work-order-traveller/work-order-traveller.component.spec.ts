import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { ChartsModule } from '@progress/kendo-angular-charts';

import { WorkOrderTravellerComponent } from './work-order-traveller.component';

describe('WorkOrderTravellerComponent', () => {
  let component: WorkOrderTravellerComponent;
  let fixture: ComponentFixture<WorkOrderTravellerComponent>;

  function initializeComponent() {
    return TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [ WorkOrderTravellerComponent ],
      imports: [
        GridModule,
        LabelModule,
        InputsModule,
        WindowModule,
        ChartsModule
      ]
    })
    .compileComponents();
  }

  function createFixture() {
    fixture = TestBed.createComponent(WorkOrderTravellerComponent);
    component = fixture.componentInstance;
  }

  function injectServices() {

  }

  function setDefaultFunctionReturnValues(){

  }

  function resetFunctionCalls() {
    
  }

  describe('initialize component', ()=>{

    beforeEach(waitForAsync (() => {
      initializeComponent()
      .then(()=>{
        createFixture();
      });
    }));

    it('should create', () => {
      expect(component).toBeTruthy();
    });
  });

});
