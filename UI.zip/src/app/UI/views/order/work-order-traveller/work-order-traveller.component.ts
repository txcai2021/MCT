import { Component, OnInit, EventEmitter, Output, OnDestroy, ViewChild, ElementRef, AfterViewInit, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { WorkOrder } from '@app/_models';
import { CustomerService, LocationService, ProductService, RoutingService, WorkOrderService } from '@app/_services';
import { Surface, Path, Text, Group, geometry, SurfaceOptions } from "@progress/kendo-drawing";
import { BehaviorSubject } from 'rxjs';
import { WorkOrderTypePipe } from '@app/_helpers/work-order-type.pipe';
import { PDFExportComponent } from '@progress/kendo-angular-pdf-export';

const { Point } = geometry;

interface RouteOperationVM {
  sequence: number;
  workCenter: string;
  process: string;
  docReference: string;
  remark: string;
}

interface RawMaterialsVM {
  item: number;
  materialCode: string;
  description: string;
  matType: string;
  qtySet: number;
  qtyLot: number;
  grade: string;
}

interface ComponentVM {
  partNo: string;
  requiredQty: number;
  workOrder: string;
  dueDate: Date;
  barcode: string;
}


@Component({
  selector: '[app-work-order-traveller]',
  templateUrl: './work-order-traveller.component.html',
  styleUrls: ['./work-order-traveller.component.scss']
})
export class WorkOrderTravellerComponent implements OnInit, AfterViewInit, OnDestroy {

  @Input() workOrderId: number = -1;
  @Output() closeWindow = new EventEmitter<boolean>();

  unit: string = "";

  public static woType: WorkOrderTypePipe; 

  formData = {
    customer: "",
    poNumber: "",
    productNo: "",
    partNo: "",
    partName: "",
    woNumber: "",
    issueDate: new Date(),
    dueDate: new Date(),
    releasedDate: new Date(),
    orderType: "",

    revision: "",
    projectNo: "",
    lineNo: "",
    newOrRepeat: "",
  };

  formGroup: FormGroup;

  workOrderSubject = new BehaviorSubject<WorkOrder>({} as WorkOrder);
  workOrder$ = this.workOrderSubject.asObservable();

  routeDataSubject = new BehaviorSubject<{
    name: string, 
    operations: RouteOperationVM[]}>
  ({
    name: "",
    operations: []
  });
  routeData$ = this.routeDataSubject.asObservable();

  rawMaterialsDataSubject = new BehaviorSubject<RawMaterialsVM[]>([]);
  rawMaterialsData$ = this.rawMaterialsDataSubject.asObservable();

  componentsDataSubject = new BehaviorSubject<ComponentVM[]>([]);
  componentsData$ = this.componentsDataSubject.asObservable();

  @ViewChild("approve")
  private approveSurfaceElement: ElementRef;
  private approveSurface: Surface;

  constructor(
    private routingService: RoutingService, 
    private workOrderService: WorkOrderService,
    private productService: ProductService,
    private customerService: CustomerService,
    private locationService: LocationService
  ) { 

    if(!WorkOrderTravellerComponent.woType)
      WorkOrderTravellerComponent.woType = new WorkOrderTypePipe();

    const formControls = 
      Object.keys(this.formData)
        .reduce((prev, cur)=>({
          ...prev,
          [cur]: new FormControl({ value: this.formData[cur], disabled: true })
        }), {}); 

    this.formGroup = new FormGroup(formControls);
  }

  ngAfterViewInit(): void {
    this.drawLine(this.createSurface({
      width: 'fit-content',
      height: '15px'
    }));
  }

  createSurface(options: SurfaceOptions): Surface {
    return this.approveSurface = Surface.create(this.approveSurfaceElement.nativeElement, options);
  }

  drawLine(surface: Surface): void {
    const path = new Path({ stroke: { color: "black", width: 1 } });
    path.moveTo(10, 15).lineTo(310, 15);
    surface.draw(path);
  }

  ngOnInit(): void {

    this.workOrderService.getById(this.workOrderId)
    .subscribe(workOrderResponse=>{

      this.workOrderSubject.next(workOrderResponse);

      this.unit = workOrderResponse.location?.name;
      
      this.setBasicWorkOrderInfoOntoForm(workOrderResponse);
      this.setPartAndAssemblyInfoOntoForm(workOrderResponse);
      this.getAndSetRawMaterials(workOrderResponse);

      if(workOrderResponse.noofChildWOs>0)
        this.getAndSetChildWorkOrders(workOrderResponse.id);

      this.routingService.getById(workOrderResponse.routeId)
      .subscribe(res=>{
        //console.log(res);
        this.routeDataSubject.next({
          name: res.name,
          operations: res.routeOperationPMs?.map(this.convertRouteOperationPM)
        });
      });

    });
    
  }

  setBasicWorkOrderInfoOntoForm(workOrder: WorkOrder): void {
    this.formGroup.patchValue({ 
      customer: workOrder.customer.name,
      poNumber: workOrder.poNumbers,
      woNumber: workOrder.workOrderNumber,
      orderType: WorkOrderTravellerComponent.woType.transform(workOrder.orderType),
      issueDate: new Date(workOrder.issueDate),
      dueDate: new Date(workOrder.dueDate),
      releasedDate: new Date(workOrder.releasedDate)
    });
  }

  setPartAndAssemblyInfoOntoForm(workOrder: WorkOrder): void {

    let patchValue: any;

    if(!workOrder.assemblyNo){
      if(workOrder.noofChildWOs==0){
        patchValue = {
          partNo: workOrder.productNo,
          partName: workOrder.productName
        };
      }
      else{
        patchValue = {
          productNo: workOrder.productNo,
          partNo: 'N/A',
          partName: 'N/A'
        };
      }
    }
    else {
      patchValue = {
        productNo: workOrder.assemblyNo,
        partNo: workOrder.productNo,
        partName: workOrder.productName
      };
    }

    this.formGroup.patchValue(patchValue);
  }

  getAndSetRawMaterials(workOrder: WorkOrder): void {
    this.productService.getAllMaterials().subscribe(res=>{

      const rawMaterialsDict = res.reduce((prev, cur)=>(
        {...prev, [cur.id]: cur}
      ), {});

      const rawMaterialVMs = workOrder.workOrderMaterials?.map(rawMaterial=>{

        let result: any = {
          qtySet: rawMaterial.ratio,
          qtyLot: rawMaterial.quantity
        };

        if(rawMaterialsDict.hasOwnProperty(rawMaterial.materialId)){
          const rm = rawMaterialsDict[rawMaterial.materialId];
          result = {...result, ...{
            materialCode: rm.rawMaterialName,
            description: rm.rawMaterialDescription,
            matType: rm.rawMaterialType,
            grade: rm.grade
          }};
        }

        return result;

      }) ?? [];

      this.rawMaterialsDataSubject.next(rawMaterialVMs);

    });
  }

  getAndSetChildWorkOrders(id: number): void {
    this.workOrderService.getChildWorkOrders(id)
    .subscribe(res=>{
      this.componentsDataSubject.next(
        res?.map(childWO=>({
          partNo: childWO.productNo,
          requiredQty: childWO.quantity,
          workOrder: childWO.workOrderNumber,
          dueDate: childWO.dueDate,
          barcode: childWO.workOrderNumber
        })) ?? []
      );
    });
  }

  convertRouteOperationPM(routeOperation): RouteOperationVM {
    return {
      sequence: routeOperation.sequence,
      workCenter: routeOperation.operationName,
      //process:
      //docReference:
      //remark: 
    } as RouteOperationVM;
  }

  ngOnDestroy(): void {
    this.approveSurface.destroy();
    this.closeWindow.unsubscribe();
  }

  onClose(): void {
    this.closeWindow.emit(true);
  }

  savePdf(pdf: PDFExportComponent, fileName: string): void {
    pdf.saveAs(`${fileName}.pdf`);
  }

}
