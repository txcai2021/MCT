import { formatDate } from '@telerik/kendo-intl';
import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { WorkOrder, WorkOrderStatus } from '@app/_models';
import { SettingsService, WorkOrderService } from '@app/_services';
import { AuthKeycloakService } from '@dis/auth/auth-keycloak.service';
import { ToastService } from '@dis/services/message/toast.service';
import { SelectionEvent } from '@progress/kendo-angular-grid';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '../../../../../environments/environment';
import { orderBy } from '@progress/kendo-data-query';

interface WorkOrderReleaseModel {
  id: number;
  woNumber: string;
  poNumber: string;
  customerName: string;
  customerId: number;
  productNo: string;
  productName: string;
  productFamily: string;
  quantity: number;
  urgentFlag: number;
  requestedDeliveryDate: string;
  routeName: string;
  specialRequest: string;
  rawMaterials: string;
  isAllocated: boolean;
  previousStatus: number;
  status: number;
  previousReleasedDate: Date;
  releasedDate: Date;
  releasedDate1: string;
}

@Component({
  selector: '[app-work-order-release]',
  templateUrl: './work-order-release.component.html',
  styleUrls: ['./work-order-release.component.scss']
})
export class WorkOrderReleaseComponent implements OnInit, OnDestroy {

  @Output() closeWindow = new EventEmitter<boolean>();

  data: {
    releaseDate: {text: string, value: Date},
    poNumber: string,
    customerName: {text: string, value: string}
  };

  formGroup: FormGroup = new FormGroup({});

  customers: Array<{text: string, value: string}> = []; 
  poNumbers: Array<string> = []; 
  releaseDates: Array<{text: string, value: Date }> = [];

  availableWorkOrderSubject = new BehaviorSubject<WorkOrderReleaseModel[]>([]);
  availableWorkOrder$ = this.availableWorkOrderSubject.asObservable();

  releasedWorkOrderSubject = new BehaviorSubject<WorkOrderReleaseModel[]>([]);
  releasedWorkOrder$ = this.releasedWorkOrderSubject.asObservable();

  cachedWorkOrderReleaseModels: {[parentWoNumber: string]: WorkOrderReleaseModel[]} = {};

  availableWorkOrderGridSelection: {[workOrderId: number]: WorkOrderReleaseModel} = {};
  availableWorkOrderIdSelection: number[] = []; //Necessary to reset Grid Selection(s) after clicking Release

  releasedWorkOrderGridSelection: {[workOrderId: number]: WorkOrderReleaseModel} = {}; 
  releasedWorkOrderIdSelection: number[] = []; //Necessary to reset Grid Selection(s) after clicking Unrelease

  checkForIsMaterialAllocated = false;

  constructor(
    private workOrderService: WorkOrderService,
    private _keycloakAuth: AuthKeycloakService,
    private toastr: ToastService,
    private settingsService: SettingsService
  ) { 

    this.releaseDates = this.initializeReleaseDateDropdown(7);

    this.data = {
      releaseDate: this.releaseDates[0],
      poNumber: "",
      customerName: {text: "", value: ""} 
    };

    const createFormControls = {
      releaseDate: new FormControl(this.data.releaseDate, [Validators.required]),
      poNumber: new FormControl(this.data.poNumber),
      customerName: new FormControl(this.data.customerName)
    };

    this.formGroup = new FormGroup(createFormControls);
  }

  ngOnInit(): void {
    this.initializeUI();
  }

  initializeUI(): void {
    this.createWorkOrderReleaseModels()
      .subscribe(woReleaseModels=>{

        this.populateCustomerDropwdownArray(woReleaseModels);
        this.populateReleaseDateArray(woReleaseModels);
        this.populatePoNumberArray(woReleaseModels);

        this.settingsService.getSettingsByName('CheckRawMaterial').subscribe(res=>{
          this.checkForIsMaterialAllocated = res.defaultSetting == '1';
        });

        this.availableWorkOrderSubject.next(woReleaseModels.filter(wo=>wo.status===0));
        this.releasedWorkOrderSubject.next(
          woReleaseModels.filter(
            wo => wo.status === WorkOrderStatus.Released && 
            wo.releasedDate1 === this.formGroup.get("releaseDate").value.text)
        );

        this.cachedWorkOrderReleaseModels =
          this.createWorkOrderReleaseModelsOrderedByParent(woReleaseModels);
      });
  }

  initializeReleaseDateDropdown(noOfDaysFromToday: number): Array<{text: string, value: Date }> {
    const result: Array<{text: string, value: Date }> = [];
    const today = new Date();

    for(let i=0; i<noOfDaysFromToday; i++){
      const dateToAdd = new Date(today);
      dateToAdd.setDate(today.getDate() + i); 
      result.push(this.createReleaseDateObject(dateToAdd));
    }
    return result;
  }

  createReleaseDateObject(date: Date): {text: string, value: Date } {
    return { 
      text: formatDate(date, 'dd/MM/yyyy'),
      value: date
    };
  }

  convertWorkOrderToWorkOrderReleaseModel(wo: WorkOrder): WorkOrderReleaseModel {
    return {
      id: wo.id,
      woNumber: wo.workOrderNumber,
      poNumber: wo.poNumbers,
      customerName: wo.customer.name,
      customerId: wo.customer.id,
      productName: wo.productName,
      productNo: wo.productNo,
      productFamily: wo.productFamily,
      quantity: wo.quantity,
      urgentFlag: wo.urgentFlag,
      requestedDeliveryDate: wo.committedDeliveryDate,
      routeName: wo.routeName,
      specialRequest: null,
      rawMaterials: wo.materialList,
      isAllocated: wo.isMaterialAllocated,
      previousStatus: wo.status,
      status: wo.status,
      previousReleasedDate: new Date(wo.releasedDate),
      releasedDate: new Date(wo.releasedDate),
      releasedDate1: formatDate(new Date(wo.releasedDate), 'dd/MM/yyyy')
    };
  }

  populateCustomerDropwdownArray(woReleaseModels: WorkOrderReleaseModel[]): void {

    const trackCustomers: {[id: number]: string} = {};

    woReleaseModels.forEach(wo=>{
      if(wo.customerId && !(wo.customerId in trackCustomers))
        trackCustomers[wo.customerId] = wo.customerName;
    });

    this.customers = Object.keys(trackCustomers)
      .reduce((prev, cur)=>([ ...prev, {text: trackCustomers[cur], value: cur}]), []);
  }

  populateReleaseDateArray(woReleaseModels: WorkOrderReleaseModel[]): void {
    const trackReleasedDates: {[text: string]: Date} = 
      this.releaseDates.reduce((prev, cur)=>({ ...prev, [cur.text]: cur.value }), {});

      woReleaseModels.forEach(wo=>{
        if(!(wo.releasedDate1 in trackReleasedDates))
          trackReleasedDates[wo.releasedDate1] = wo.releasedDate;
      });

    const releaseDates = Object.keys(trackReleasedDates).reduce((prev, cur)=>{
      return [ ...prev, { text: cur, value: trackReleasedDates[cur] } ];
    }, []);

    this.releaseDates = orderBy(releaseDates, [{field: 'value', dir: 'asc'}]);
  }

  populatePoNumberArray(woReleaseModels: WorkOrderReleaseModel[]): void {
    const trackPoNumbers: {[poNumber: string]: boolean} = {};

    woReleaseModels.forEach(wo => {
      if(wo.poNumber && !(wo.poNumber in trackPoNumbers))
        trackPoNumbers[wo.poNumber] = true;
    });

    this.poNumbers = Object.keys(trackPoNumbers)
      .reduce((prev, cur) => ([ ...prev, cur]), [])
      .filter(poNumber => poNumber.length>0);
  }

  createWorkOrderReleaseModels(): Observable<WorkOrderReleaseModel[]> {
    return this.workOrderService.getAll()
      .pipe(map(res => res.map(this.convertWorkOrderToWorkOrderReleaseModel)));
  }

  createWorkOrderReleaseModelsOrderedByParent(
    woReleaseModels: WorkOrderReleaseModel[]
  ): {[parentWoNumber: string]: WorkOrderReleaseModel[]} {

    const workOrderReleaseModels: {[parentWoNumber: string]: WorkOrderReleaseModel[]} = {};

    woReleaseModels.forEach(wo=>{
      const checkIfChild = wo.woNumber.split('.');
        if(checkIfChild.length>0){
          if(!workOrderReleaseModels.hasOwnProperty(checkIfChild[0]))
            workOrderReleaseModels[checkIfChild[0]] = [];
          workOrderReleaseModels[checkIfChild[0]].push(wo);
        }
    });

    return workOrderReleaseModels;
  }

  onCustomerChange(e): void {
    //const itemClicked = e as { text: string, value: number };
    const form = this.formGroup.value;
    this.refreshAvailableWorkOrderUsingCachedWorkOrderReleaseModels(
      this.getAllCachedWOs(), form.customerName?.text, form.poNumber);
  }

  onPoNumberChange(e): void {
    //const itemClicked = e as { text: string, value: number };
    const form = this.formGroup.value;
    this.refreshAvailableWorkOrderUsingCachedWorkOrderReleaseModels(
      this.getAllCachedWOs(), form.customerName?.text, form.poNumber);
  }

  onReleaseDateChange(e): void {
    this.refreshReleasedWorkOrderUsingCachedWorkOrderReleaseModels(
      this.getAllCachedWOs(),
      this.formGroup.get("releaseDate").value?.text
    );
  }

  onClose(): void {
    this.closeWindow.emit(true);
  }

  onOkButtonClick(): void {

    const getWOWithReleasedStatus = this.getAllCachedWOs()
      .filter(wo => {

        const statusChangeCondition = wo.previousStatus !== wo.status;
        const releaseDateChangeCondition = wo.previousStatus === wo.status &&
          this.datesAreSameDay(wo.previousReleasedDate, wo.releasedDate) === false;

        return statusChangeCondition || releaseDateChangeCondition;

      })
      .map(wo=>({
          workOrderId: wo.id,
          status: wo.status,
          releasedDate: wo.releasedDate
        })
      );

    if(getWOWithReleasedStatus.length<=0){
      this.onClose();
      return;
    }

    this._keycloakAuth.getUserDetails()
      .then(user=>{
        this.workOrderService.releaseWorkOrder(user.id, getWOWithReleasedStatus)
          .subscribe(res=>{
            if(res)
              this.toastr.success("Your data has been updated successfully.");
            this.onClose();
          }, (err)=>{
            this.toastr.error("Unable to release Work Orders.");
            this.initializeUI();
          });
      })
      .catch(err=>console.error(err));
  }

  datesAreSameDay(first: Date, second: Date): boolean {
    return (
      first.getFullYear() === second.getFullYear() &&
      first.getMonth() === second.getMonth() &&
      first.getDate() === second.getDate()
    );
  }

  onReleaseButtonClick(): void {

    Object.keys(this.availableWorkOrderGridSelection)
      .forEach(woNumber=>{

        const checkIsChild = woNumber.split('.');
        const parentWoNumber = checkIsChild[0];

        if(checkIsChild.length>0 && 
          this.cachedWorkOrderReleaseModels.hasOwnProperty(parentWoNumber))
        {

          if(checkIsChild.length>1){
            this.checkAndHandleReleaseForChildWO(parentWoNumber, woNumber);
          }
          else {
            this.checkAndHandleReleaseForAllWORelatedToParentWO(parentWoNumber);
          }
        }
      });

    this.refreshUIUsingCachedWorkOrderReleaseModels();
  }

  checkAndHandleReleaseForChildWO(parentWoNumber: string, childWoNumber: string): void {

    //Patch Values only for the Child Work Order
    const index = this.cachedWorkOrderReleaseModels[parentWoNumber]
      .findIndex(wo => wo.woNumber === childWoNumber);

    if(index!=-1){

      const childWOReference = this.cachedWorkOrderReleaseModels[parentWoNumber][index];

      const checkMaterialAllocatedCondition = 
        ( this.checkForIsMaterialAllocated && childWOReference.isAllocated );

      const materialAllocatedCheckIsNotRequired = !this.checkForIsMaterialAllocated;

      if(checkMaterialAllocatedCondition || materialAllocatedCheckIsNotRequired){
        this.cachedWorkOrderReleaseModels[parentWoNumber][index] = {
          ...childWOReference, ...this.getInformationToPatchWOToReleasedStatus()
        };
      }
      else {
        this.toastr.error(`Material is not Allocated for ${childWoNumber}.` );
      }
    }
  }

  checkAndHandleReleaseForAllWORelatedToParentWO(parentWoNumber: string): void {

    //Patch values for all Work Orders Related to this Parent
    const workOrders = this.cachedWorkOrderReleaseModels[parentWoNumber];

    const checkMaterialAllocatedCondition = ( this.checkForIsMaterialAllocated && 
        workOrders.filter(wo => wo.isAllocated === false ).length === 0);

    const materialAllocatedCheckIsNotRequired = !this.checkForIsMaterialAllocated;

    if(checkMaterialAllocatedCondition || materialAllocatedCheckIsNotRequired){
      this.cachedWorkOrderReleaseModels[parentWoNumber] = 
        workOrders.map(wo=>({ ...wo, ...this.getInformationToPatchWOToReleasedStatus() }));
    }
    else {
      this.toastr.error('Material is not Allocated.');
    }
  }

  getInformationToPatchWOToReleasedStatus(){
    return {
      releasedDate: this.formGroup.get("releaseDate").value.value,
      releasedDate1: this.formGroup.get("releaseDate").value.text,
      status: WorkOrderStatus.Released
    };
  }

  onUnreleaseButtonClick(): void {

    function resetCachedWorkOrderReleaseModelIfExist(parentWoNumber: string, woNumber: string): void {
      const resetWOValues = { releaseDate: null, releaseDate1: null, status: WorkOrderStatus.Pending };
      const index = this.cachedWorkOrderReleaseModels[parentWoNumber]
        .findIndex(wo => wo.woNumber === woNumber);

      if(index != -1){
        this.cachedWorkOrderReleaseModels[parentWoNumber][index] = {
          ...this.cachedWorkOrderReleaseModels[parentWoNumber][index],
          ...resetWOValues
        }
      }
    }

    Object.keys(this.releasedWorkOrderGridSelection)
      .forEach(woNumber=>{

        const checkIsChild = woNumber.split('.');

        if(checkIsChild.length>0 &&
          this.cachedWorkOrderReleaseModels.hasOwnProperty(checkIsChild[0])) 
        {
          //Push Itself Up
          resetCachedWorkOrderReleaseModelIfExist.apply(this, [checkIsChild[0], woNumber]);

          if(checkIsChild.length>1){
            //Push Parent Up If Its a Child
            resetCachedWorkOrderReleaseModelIfExist.apply(this, [checkIsChild[0], checkIsChild[0]]);
          }
        }

      });

    this.refreshUIUsingCachedWorkOrderReleaseModels();
  }

  onAvailableWOSelectedKeyChange(event: SelectionEvent): void {
    if(event.selectedRows.length>0){
      event.selectedRows.forEach((row: {dataItem: WorkOrderReleaseModel}) => {
        this.availableWorkOrderGridSelection[row.dataItem.woNumber] = row.dataItem;
      });
    }
    else if(event.deselectedRows.length>0){
      event.deselectedRows.forEach((row: { dataItem: WorkOrderReleaseModel }) => {
        delete this.availableWorkOrderGridSelection[row.dataItem.woNumber];
      });
    }
  }

  onReleasedWOSelectedKeyChange(event: SelectionEvent): void {
    if(event.selectedRows.length>0){
      event.selectedRows.forEach((row: {dataItem: WorkOrderReleaseModel}) => {
        this.releasedWorkOrderGridSelection[row.dataItem.woNumber] = row.dataItem;
      });
    }
    else if(event.deselectedRows.length>0){
      event.deselectedRows.forEach((row: { dataItem: WorkOrderReleaseModel }) => {
        delete this.releasedWorkOrderGridSelection[row.dataItem.woNumber];
      });
    }
  }

  getAllCachedWOs(): WorkOrderReleaseModel[] {
    return Object.values(this.cachedWorkOrderReleaseModels)
    .reduce((prev, cur)=>([...prev, ...cur]), []);
  } 

  refreshUIUsingCachedWorkOrderReleaseModels(): void {

    this.releasedWorkOrderIdSelection = [];
    this.releasedWorkOrderGridSelection = {};

    this.availableWorkOrderIdSelection = [];
    this.availableWorkOrderGridSelection = {};

    const allWO = this.getAllCachedWOs();

    const form = this.formGroup.value;

    this.refreshAvailableWorkOrderUsingCachedWorkOrderReleaseModels(
      allWO, form.customerName?.text, form.poNumber);

    this.refreshReleasedWorkOrderUsingCachedWorkOrderReleaseModels(allWO, form.releaseDate?.text);
  }

  refreshAvailableWorkOrderUsingCachedWorkOrderReleaseModels(
    allWO: WorkOrderReleaseModel[], 
    selectedCustomer: string,
    selectedPoNumber: string
  ): void {

    const filteredWO = allWO
      .filter(wo => wo.status === 0)
      .filter(wo=> wo.customerName === selectedCustomer || !selectedCustomer)
      .filter(wo=> wo.poNumber === selectedPoNumber || !selectedPoNumber);

    this.availableWorkOrderSubject.next(filteredWO);
  }

  refreshReleasedWorkOrderUsingCachedWorkOrderReleaseModels(
    allWO: WorkOrderReleaseModel[], 
    date: string
  ): void {

    const getReleasedDateStrings = this.releaseDates.reduce((prev, cur)=>{
      return [...prev, cur.text];
    }, []);

    if(getReleasedDateStrings.includes(date)){
      this.releasedWorkOrderSubject.next(
        allWO.filter(wo => wo.status === WorkOrderStatus.Released && wo.releasedDate1 === date));
    }
  }

  ngOnDestroy(): void {
    this.closeWindow.unsubscribe();
  }

}
