import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkOrderReleaseComponent } from './work-order-release.component';

describe('WorkOrderReleaseComponent', () => {
  let component: WorkOrderReleaseComponent;
  let fixture: ComponentFixture<WorkOrderReleaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WorkOrderReleaseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkOrderReleaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
