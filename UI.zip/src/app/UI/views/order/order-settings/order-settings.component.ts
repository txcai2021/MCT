import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Settings } from '@app/_models';
import { SettingsService } from '@app/_services';
import { ToastService } from '@dis/services/message/toast.service';
import { forkJoin } from 'rxjs';

interface SettingsVM {
  id: number;
  optionName: string;
  defaultSetting: string;
  isDirty: boolean;
}

@Component({
  selector: 'app-order-settings',
  templateUrl: './order-settings.component.html',
  styleUrls: ['./order-settings.component.scss']
})
export class OrderSettingsComponent implements OnInit {

  settingsMap = {
    committedDeliveryDate: 'LT_External', 
    requestedDeliveryDate: 'LT_Internal', 
    assembly: 'LT_Assembly', 
    workOrderPrintingOption: 'WOPrintOption', 
    checkRawMaterial: 'CheckRawMaterial'
  };

  data = {
    committedDeliveryDate: 0,
    requestedDeliveryDate: 0,
    assembly: 0,
    workOrderPrintingOption: -1,
    checkRawMaterial: false,
  };

  formGroup: FormGroup;

  workOrderPrintingOptions: Array<{text: string, value: number}> = [];

  cachedSettings: {
    [name:string]: SettingsVM
  } = {};

  constructor(
    private settingsService: SettingsService,
    private toastr: ToastService
  ) { 

    const formGroupControls = Object.keys(this.data).reduce((prev, cur)=>({
      ...prev, [cur]: new FormControl(this.data[cur])
    }), {});

    this.formGroup = new FormGroup(formGroupControls);
  }

  ngOnInit(): void {

    this.workOrderPrintingOptions = [
      {text: "By Selected WO", value: 1},
      {text: "By Parent WO", value: 2},
      {text: "By PO Line Item", value: 3},
      {text: "By PO", value: 4},
    ];

    const settingsName = Object.values(this.settingsMap);

    const tryParseInt = (value)=>{
      let result;
      if(value) {
        const parse = parseInt(value);
        result = !isNaN(parse) && parse>-1 ? parse : 0;
      }
      else { result = 0; }

      return result;
    };

    forkJoin(settingsName.map(name=>this.settingsService.getSettingsByName(name)))
    .subscribe(res=>{

      if(res){
        const settingsVMs = res.map(this.convertSettingsToVM);

        this.cachedSettings = settingsName.reduce((prev, cur, index)=>{
          let current = settingsVMs[index]?.id ? {[cur]: settingsVMs[index]} : {};
          return {...prev, ...current};
        }, {});

        this.formGroup.setValue({
          committedDeliveryDate: tryParseInt(settingsVMs[0]?.defaultSetting),
          requestedDeliveryDate: tryParseInt(settingsVMs[1]?.defaultSetting),
          assembly: tryParseInt(settingsVMs[2]?.defaultSetting),
          workOrderPrintingOption: tryParseInt(settingsVMs[3]?.defaultSetting),
          checkRawMaterial: settingsVMs[4]?.defaultSetting === '1'
        });
      }

    });

  }

  onSaveClick(): void {
    forkJoin(
      Object.values(this.cachedSettings)
      .filter(setting=>setting.isDirty)
      .map(this.convertSettingsVMForUpdate)
      .map(setting=>this.settingsService.update(setting))
    ).subscribe(res=>{
      if(res){
        this.resetAllSettingsDirtyStatus();
        this.toastr.success('Your data has been saved successfully.');
      }
    });
  }

  convertSettingsToVM(settings: Settings): SettingsVM {
    return <SettingsVM>(settings ? {
      id: settings.id,
      optionName: settings.optionName,
      defaultSetting: settings.defaultSetting,
      isDirty: false
    } : {});
  }

  convertSettingsVMForUpdate(settings: SettingsVM) {
    return {
      id: settings.id,
      defaultSetting: settings.defaultSetting
    };
  }

  resetAllSettingsDirtyStatus(): void {
    Object.keys(this.cachedSettings).forEach(key=>{
      this.cachedSettings[key] = {...this.cachedSettings[key], isDirty: false};
    });
  }

  onInputValueChange(inputField: string, input: any): void {
    let defaultSetting;

    switch(inputField){
      case this.settingsMap.committedDeliveryDate:
      case this.settingsMap.requestedDeliveryDate:
      case this.settingsMap.assembly:
        defaultSetting = input.toString();
        break;
      case this.settingsMap.workOrderPrintingOption:
        defaultSetting = this.formGroup.get('workOrderPrintingOption').value.toString();
        break;
      case this.settingsMap.checkRawMaterial:
        defaultSetting = input.target.checked ? '1' : '0';
        break;
    }

    if(this.cachedSettings.hasOwnProperty(inputField)){
      this.cachedSettings[inputField].defaultSetting = defaultSetting;
      this.cachedSettings[inputField].isDirty = true;
    }
    else {
      this.toastr.error(`The setting ${this.settingsMap[inputField] ?? inputField} was not retrieved successfully previously`);
    }
  }
}
