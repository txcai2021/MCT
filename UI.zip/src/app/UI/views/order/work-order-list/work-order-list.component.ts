import { Component, OnInit, ViewChild } from '@angular/core';
import { WorkOrder } from '@app/_models';
import { WorkOrderService } from '@app/_services';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { ToastService } from '@dis/services/message/toast.service';
import { DataBindingDirective, EditEvent, RemoveEvent } from '@progress/kendo-angular-grid';
import { BehaviorSubject } from 'rxjs';
import { orderBy, process } from '@progress/kendo-data-query';

interface WorkOrderViewModel {

  id : number;

  poNumber : string;
  woNumber : string;
  status : number;
  requestedDeliveryDate : Date;
  customerCode : string;

  customerName : string;
  contactPerson : string;
  contactNumber : string;
  productNo : string;
  productName : string;

  productFamily : string;
  lineNo : number;
  quantity : number;
  currentOperation : string;
  routeName : string;

  releasedDate : Date;
  materialList: string;
  materialAllocated : boolean;
  orderType : number;
  allocatedQuantity  : number;

  drawingA : string;
  drawingB : string;
  drawingC : string;
  poRemarks : string;
  specialRequest : string;

  fileName : string;
  buyList: string[];
  noActionList: string[];
  unit : string;
  createdDate : Date;

  createdBy : string;
  releasedBy : string;
}

@Component({
  selector: 'app-work-order-list',
  templateUrl: './work-order-list.component.html',
  styleUrls: ['./work-order-list.component.scss']
})
export class WorkOrderListComponent implements OnInit {

  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;

  gridDataSubject = new BehaviorSubject<WorkOrderViewModel[]>([]);
  gridView = this.gridDataSubject.asObservable();

  myGridViewSelection: number[] = [];

  openWOReleaseWindowSubject = new BehaviorSubject<boolean>(false);
  openWOReleaseWindow$ = this.openWOReleaseWindowSubject.asObservable();

  openWOTravellerWindowSubject = new BehaviorSubject<boolean>(false);
  openWOTravellerWindow$ = this.openWOTravellerWindowSubject.asObservable();

  woTravellerWoIdInputSubject = new BehaviorSubject<number>(-1);
  woTravellerWoIdInput$ = this.woTravellerWoIdInputSubject.asObservable();

  constructor(
    private workOrderService: WorkOrderService,
    private customDialog: CustomDialogService,
    private toastr: ToastService
  ) {}

  ngOnInit(): void {
    this.refreshGridView();
  }

  refreshGridView(): void {

    this.workOrderService.getAll().subscribe(res=>{

      const woViewModels = orderBy(
        res.map(wo=>this.convertWorkOrderToWorkOrderViewModel(wo)),
        [{ field: 'id', dir: 'desc' }]
      );

      this.gridDataSubject.next(woViewModels);

    });
  }

  convertWorkOrderToWorkOrderViewModel(wo: WorkOrder): WorkOrderViewModel {
    return {
      id: wo.id,

      woNumber : wo.workOrderNumber,
      status : wo.status,
      requestedDeliveryDate : wo.dueDate,

      customerCode : wo.customer.description,
      customerName : wo.customer.name,
      poNumber : wo.poNumbers,
      currentOperation : null,
      routeName : wo.routeName,
      allocatedQuantity  : null,
      drawingA : null,
      drawingB : null,
      drawingC : null,
      specialRequest : null,
      noActionList: [],
      unit : null,

      contactPerson : wo.contactPersonName,
      contactNumber : wo.contactNo,
      productNo : wo.productNo,
      productName : wo.productName,
      productFamily : wo.productFamily,

      lineNo : wo.lineNo,
      quantity : wo.quantity,
      releasedDate : wo.releasedDate,
      materialList: wo.materialList,
      materialAllocated : wo.isMaterialAllocated,

      orderType : wo.orderType,
      poRemarks : wo.remarks,
      fileName : wo.fileName,
      buyList: wo.buyList,
      createdDate : wo.issueDate,

      createdBy : wo.createdBy,
      releasedBy : wo.releasedBy

    };
  }

  onReleaseButtonClick(): void {
    this.openWOReleaseWindowSubject.next(true);
  }

  onEditClick(event: EditEvent): void {

  }

  onDeleteClick(event: RemoveEvent): void {
    this.customDialog.confirm().subscribe(res =>{
      if(res.primary)
        this.workOrderService.delete(event.dataItem.id).subscribe(res=>{
          if(res)
            this.toastr.success('Your data has been removed sucessfully.');
          this.refreshGridView();
        });
      else
        this.refreshGridView();
    });
  }

  onFilter(inputValue: string): void {
    this.workOrderService.getAll()
      .subscribe(res=>{
        const items = process(orderBy(res, [{ field: 'id', dir: 'desc' }]), {
          filter: {
            logic: 'or',
            filters: ['workOrderNumber', 'poNumbers', 'productName', 'productFamily', 'productNo']
              .map(filter => { 
                return {
                  field: filter,
                  operator:'contains',
                  value: inputValue
                };
              }),
          },
        }).data;

      const woViewModels = items.map(wo=>this.convertWorkOrderToWorkOrderViewModel(wo));
      this.gridDataSubject.next(woViewModels);
      this.dataBinding.skip = 0;

    });
  }

  onClose(window: 'woRelease'|'woTraveller'): void {
    switch(window){
      case 'woRelease':
        this.openWOReleaseWindowSubject.next(false);
        break;
      case 'woTraveller':
        this.openWOTravellerWindowSubject.next(false);
        break;
    }
    this.refreshGridView();
  }

  onPrintClick(): void {
    this.woTravellerWoIdInputSubject.next(this.myGridViewSelection[0]);
    this.openWOTravellerWindowSubject.next(true);
  }
}
