import { Component, OnInit, ViewChild } from '@angular/core';
import {
  DataBindingDirective,
  EditEvent,
  RemoveEvent,
} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable } from 'rxjs';
import { ToastService } from '@dis/services/message/toast.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { CustomMessageService } from '@dis/services/message/custom-message.service';

import {
  LocationService,
  calendarService,
  OperationService,
} from '@app/_services';
import { first } from 'rxjs/operators';
import { Location, Operation } from '@app/_models';
import { SelectableSettings } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss'],
})
export class LocationComponent implements OnInit {
  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;
  public min: Date = new Date(2000, 2, 10, 2, 30);
  public max: Date = new Date(2002, 2, 10, 22, 15);
  public value: Date = new Date(2000, 2, 10, 10, 0);
  public selectableSettings: SelectableSettings;

  public checkboxOnly = true;
  public mode = 'single';
  public drag = false;

  gridDataSubject = new BehaviorSubject<Location[]>([]);
  gridView = this.gridDataSubject.asObservable();

  gridDataSubjectMeal = new BehaviorSubject<Operation[]>([]);
  gridViewMeal = this.gridDataSubjectMeal.asObservable();
  mySelectionMeal: any[] = [];

  totaloperation: any[] = [];
  totalmySelectionMeal: any[] = [];

  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  idTextFieldDisabled = false;
  editedRowIndex: number;
  isSecondWindowOpened = false;
  public data: any = {
    idName: '',
    description: '',
    calenderID: 0,
    email: '',
    phone: '',
    fax: '',
    site: '',
    regNo: '',
    gstRegno: '',
    address: '',
    pictureId: '',
    customerid: '',
    subCategory: '',
  };
  public editId: any;
  public editCustomerId: any;
  public day1: Array<any> = [];
  public selectedItemDay1: any;
  public previousSelectedDay1: any;
  public changedDay1 = { name: '', id: 0 };

  constructor(
    private toastr: ToastService,
    private locationService: LocationService,
    private customDialog: CustomDialogService,
    private customMessage: CustomMessageService,
    private operationService: OperationService,
    private calendarService: calendarService
  ) {
    this.setSelectableSettings();

    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
      calenderID: new FormControl(),
      email: new FormControl(this.data.email),
      phone: new FormControl(this.data.phone),
      fax: new FormControl(this.data.fax),
      site: new FormControl(this.data.site),
      regNo: new FormControl(this.data.regNo),
      gstRegno: new FormControl(this.data.gstRegno),
      address: new FormControl(this.data.address),
      pictureId: new FormControl(this.data.pictureId),
      subCategory: new FormControl(this.data.subCategory),
      customerid: new FormControl(this.data.id),
    });

    this.populateDay1Array();
    
  }

  ngOnInit(): void {
    this.loadItems();
  }

  public setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: this.checkboxOnly,

      drag: this.drag,
      mode: 'single',
    };
  }
  loadItems() {

    this.mySelectionMeal = [];

    this.refreshLocationGrid();
    this.refreshMealGrid();
  }

  populateDay1Array(): void {
    this.calendarService.getAll()
    .subscribe((result) => {

      if (!result) return;
        
      result = orderBy(result as any, [{ field: 'id', dir: 'desc' }]);

      this.day1.push({ name: '', id: 0 });

      for (let i = 0; i < result.length; i++) {
        this.day1.push(result[i]);
      }

    });
  }

  refreshLocationGrid(): void {
    this.locationService.getAll().subscribe((res) => {
      if (res){
        res = orderBy(res, [{ field: 'id', dir: 'desc' },]);
        this.gridDataSubject.next(res);
      }
    });
  }

  refreshMealGrid(): void {
    this.operationService.getAll().subscribe((res) => {
      this.totaloperation = res;
      if (res){
        res= orderBy(res, [{ field: 'id', dir: 'desc' }]);
        this.gridDataSubjectMeal.next(res);
      }
    });
  }

  onFilter(inputValue: string): void {
    console.log(inputValue);
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          },
        ],
      },
    }).data;

    console.log(items);
    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }

  clearData(): void {
    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
      calenderID: new FormControl(),
      email: new FormControl(this.data.email),
      phone: new FormControl(this.data.phone),
      fax: new FormControl(this.data.fax),
      site: new FormControl(this.data.site),
      regNo: new FormControl(this.data.regNo),
      gstRegno: new FormControl(this.data.gstRegno),
      address: new FormControl(this.data.address),
      pictureId: new FormControl(this.data.pictureId),
      subCategory: new FormControl(this.data.subCategory),
      customerid: new FormControl(this.data.id),
    });
  }

  onAddNewClick(): void {
    this.clearData();
    this.idTextFieldDisabled = false;

    let nlength = this.totaloperation.length;
    let selectableoperation = [];

    for (let i = 0; i < nlength; i++) {
      if (
        this.totaloperation[i].locationId == 0 ||
        this.totaloperation[i].locationId == null
      ) {
        selectableoperation.push(this.totaloperation[i]);
      }
    }

    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
  }

  editButton(event: EditEvent): void {

    let newData = {
      idName: '',
      startTime: new Date(2002, 2, 10, 22, 15),
      endTime: new Date(2002, 2, 10, 22, 15),
    };

    this.idTextFieldDisabled = true;

    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } 
    else {
      let selectedindex = this.mySelection[0];
      let countindex = 0;

      for (var row in this.gridView) {
        let curTup = this.gridView[row];

        if (curTup['id'] == selectedindex) {

          this.isNew = false;
          let getstarttime = curTup.startTime;
          let startTimeArray = getstarttime.split(':');
          let startTimeHour = startTimeArray[0];
          let startTimeMinute = startTimeArray[1];
          let getendTime = curTup.endTime;
          let endTimeArray = getendTime.split(':');
          let endTimeHour = endTimeArray[0];
          let endTimeMinute = endTimeArray[1];

          newData.idName = curTup.name;
          newData.startTime = new Date(
            2002,
            2,
            10,
            startTimeHour,
            startTimeMinute
          );
          newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);

          this.formGroup.reset(newData);
          this.isWindowOpened = !this.isWindowOpened;
          this.editedRowIndex = countindex;
          break;
        }
        countindex += 1;
      }
    }
  }

  onEditClick(event: EditEvent): void {

    this.idTextFieldDisabled = true;
    this.editId = event.dataItem.id;
    this.mySelectionMeal = [];

    let nlength = this.totaloperation.length;
    let selectableoperation = [];

    //get the selected operation and selectable operation
    for (let i = 0; i < nlength; i++) {
      if (
        this.totaloperation[i].locationId == 0 ||
        this.totaloperation[i].locationId == null
      ) {
        selectableoperation.push(this.totaloperation[i]);
      } else if (this.totaloperation[i].locationId == event.dataItem.id) {
        console.log('inside');

        selectableoperation.push(this.totaloperation[i]);
        this.mySelectionMeal.push(this.totaloperation[i].id);
      }
    }

    let newData = {
      id: event.dataItem.id,
      idName: '',
      startTime: new Date(2002, 2, 10, 22, 15),
      endTime: new Date(2002, 2, 10, 22, 15),
      calenderID: { name: '', id: 0 },
      description: event.dataItem.description,
      email: event.dataItem.customer.email,
      phone: event.dataItem.customer.phone,
      fax: event.dataItem.customer.fax,
      site: event.dataItem.customer.site,
      regNo: event.dataItem.customer.regNo,
      gstRegno: event.dataItem.customer.gstRegno,
      address: event.dataItem.customer.address,
      subCategory: event.dataItem.subCategory,
      customerid: event.dataItem.customer.id,
    };

    let curCalendarID = event.dataItem.calenderID;
    this.changedDay1 = { name: '', id: 0 };

    for (let i = 0; i < this.day1.length; i++) {
      let curtup = this.day1[i];
      if (curtup.id == curCalendarID) {
        this.changedDay1.name = curtup.name;
        this.changedDay1.id = curtup.id;
        newData.calenderID.name = curtup.name;
        newData.calenderID.id = curtup.id;
      }
    }

    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;
    newData.idName = event.dataItem.name;

    this.formGroup.reset(newData);
    this.editedRowIndex = event.rowIndex;
  }

  closeWindow(): void {
    this.isWindowOpened = false;
    this.mySelectionMeal = [];
  }

  cancelWindow(): void {
    this.isWindowOpened = false;
    this.mySelectionMeal = [];
  }

  submitWindow(item): void {
    // this.isSecondWindowOpened = true;
    if (this.mySelectionMeal.length == 0) {
      console.log('submit button');
      this.isSecondWindowOpened = true;
    } else {
      this.isWindowOpened = false;

      if (!this.isNew) {
        const items = this.gridDataSubject.value;
        console.log('inside');
        console.log(items);
        // console.log('editedrowindex ' + this.editedRowIndex);
        item.id = this.editId;
      }
      console.log('submitwindowfunction');
      console.log(item);
      this.saveItem(item);
    }
  }

  closeWindowWarning() {
    this.isSecondWindowOpened = false;
  }
  twofourHoursformat(time): string {
    var hours = Number(time.match(/^(\d+)/)[1]);
    var minutes = Number(time.match(/:(\d+)/)[1]);
    var AMPM = time.match(/\s(.*)$/)[1];
    if (AMPM == 'PM' && hours < 12) hours = hours + 12;
    if (AMPM == 'AM' && hours == 12) hours = hours - 12;
    var sHours = hours.toString();
    var sMinutes = minutes.toString();
    if (hours < 10) sHours = '0' + sHours;
    if (minutes < 10) sMinutes = '0' + sMinutes;
    return sHours + ':' + sMinutes;
  }

  public saveItem(item): void {
    console.log('save item');
    console.log(item);
    // this.isSecondWindowOpened = true;

    let getName = item['idName'];

    let getid = item['id'];

    let postLocationObject = {
      id: getid,
      name: getName,
      description: item.description,
      calenderID: this.changedDay1.id,
      operationIds: this.mySelectionMeal,

      noOfProductionLines: 0,
      // customerId: 0,
      // customer: {
      subCategory: 0,
      customer: {
        id: 0,
        code: getName,
        name: item.idName,
        site: item.site,
        department: '',
        address: item.address,
        description: item.description,
        phone: item.phone,
        email: item.email,
        fax: item.fax,
        regNo: item.regNo,
        gstRegno: item.gstRegno,
        pictureId: 0,
        thumbnailImage: '',
        thumbnailImageFileName: '',
      },
    };
    if (!this.isNew) {
      postLocationObject.subCategory = item.subCategory;
      postLocationObject.customer.id = item.customerid;
    }
    else {
      delete postLocationObject.subCategory;
    }
    console.log('post unit');
    console.log(JSON.stringify(postLocationObject));
    console.log();

    if (this.isNew) {
      this.locationService
        .save(postLocationObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    } else {
      console.log('getid');
      console.log(getid);
      console.log('postobject');
      console.log(postLocationObject);
      this.locationService
        .update(0, postLocationObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    }
  }

  // deleteButton(): void {
  //   console.log(this.mySelection);
  //   if (this.mySelection.length == 0) {
  //     this.toastr.error('Please click on one of the checkboxes');
  //   } else {
  //     this.editedRowIndex = parseInt(this.mySelection[0]);
  //     console.log('delete ' + this.editedRowIndex);
  //     this.customDialog.confirm().subscribe((res) => {
  //       // Primary (Yes) button is clicked
  //       if (res.primary) {
  //         console.log('delete if');
  //         this.removeItem();
  //       }
  //     });
  //   }
  // }

  onDeleteClick(event: RemoveEvent): void {
    console.log('delete click');
    console.log(event);
    this.editedRowIndex = event.rowIndex;
    console.log('delete ' + this.editedRowIndex);
    this.customDialog.confirm().subscribe((res) => {
      // Primary (Yes) button is clicked
      if (res.primary) {
        console.log('delete if');
        this.removeItem(event.dataItem.id);
      }
    });
  }

  removeItem(deleteidd): void {
    // do you processing and close window
    let items = this.gridDataSubject.value;
    console.log('before');
    console.log(items);
    console.log('editedrowindex');
    console.log(this.editedRowIndex);
    let deletedId = this.editedRowIndex;
    let getdeleteid: any = 0;
    for (var row in items) {
      let curTup = items[row];
      console.log(curTup);
      if (curTup['id'] == deletedId) {
        console.log('inside');
        getdeleteid = curTup['id'];
        console.log(curTup['id']);
      }
    }
    console.log(getdeleteid);
    items.splice(this.editedRowIndex, 1);

    // array isnt updating
    // Retrieve backend data to update
    const temp = [...items];
    // noinspection JSUnusedAssignment
    items = [];
    items = [...temp];
    console.log('after');
    console.log(items);
    // success should be in resolve of subscribe method
    this.locationService
      .delete(deleteidd)
      .pipe(first())
      .subscribe({
        next: (data) => {
          this.gridDataSubject.next(items);
          console.log('delete item');
          console.log(data);
          if (data == -1) {
            this.toastr.error('Meal is used by Shift');
          } else {
            this.loadItems();
            this.toastr.success('Your data has been removed sucessfully.');
          }
        },
        error: (error) => {},
      });
  }

  callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void {
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }

  public valueChangeDay1(value: any): void {
    this.changedDay1 = value;
    console.log(this.changedDay1);
    // this.log('valueChange', JSON.stringify(value));
  }
}
