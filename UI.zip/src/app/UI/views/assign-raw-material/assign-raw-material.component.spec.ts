import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ComponentFixture, fakeAsync, flush, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RawMaterial } from '@app/_models';
import { ProductService, RawMaterialService } from '@app/_services';
import { ToastService } from '@dis/services/message/toast.service';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { WindowModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { of } from 'rxjs';

import { AssignRawMaterialComponent } from './assign-raw-material.component';

enum RatioType {
  Value = 0,
  Each = 1,
  Piece = 2
}

function createRandomString(length: number): string {
  return Math.random().toString(length).slice(2);
}

function createRawMaterial(noToCreate: number): RawMaterial[] {

  let result = new Array<RawMaterial>();

  for(let i=1; i<=noToCreate; i++){
    const rm = new RawMaterial();

    rm.id = i;
    rm.grade = createRandomString(18);
    rm.rawMaterialName = createRandomString(30);
    rm.rawMaterialDescription = createRandomString(30);

    result.push(rm);
  }

  return result;
}

function createProductInformation(){
  return {
    name: createRandomString(30),
    description: createRandomString(20),
    customers: createRandomString(15),
    partFamily: createRandomString(15),
    remarks: createRandomString(15),
    productionYield: Math.floor(Math.random()*101)
  }; 
}

function convertProductInfoForFormGroupUsage(productInfo: any){
  return {
    partNo: productInfo.name,
    partName: productInfo.description,
    customer: productInfo.customers,
    partFamily: productInfo.partFamily,
    remarks: productInfo.remarks,
    productionYield: productInfo.productionYield
  }
}

function createProductBomFromRawMaterial(rm: RawMaterial){
  return {
    componentId: rm.id,
    bomLevel: Math.floor(Math.random()*3),
    perAssemblyQuantity: Math.floor(Math.random()*10)
  };
}

describe('AssignRawMaterialComponent', () => {

  let component: AssignRawMaterialComponent;
  let fixture: ComponentFixture<AssignRawMaterialComponent>;
  let debugElement: DebugElement;
  
  let rawMaterialServiceSpy = jasmine.createSpyObj('RawMaterialService', ['getAll']);
  let productServiceSpy = jasmine.createSpyObj('RawMaterialService', ['getProductBomById', 'getPartById', 'getAssemblyById', 'updateProductRawMaterial', 'deleteProductRawMaterial']);
  let toastServiceSpy = jasmine.createSpyObj('ToastService', ['success']);

  let rawMaterialService, productService, toastService;

  let rawMaterialData: RawMaterial[] = createRawMaterial(3);
  let productRawMaterialData = [createProductBomFromRawMaterial(rawMaterialData[0])];
  let productInfo = createProductInformation();
  let productId = 1;

  function initializeComponent() {
    return TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [ AssignRawMaterialComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        GridModule,
        LabelModule,
        InputsModule,
        WindowModule,
        ButtonsModule
      ],
      providers: [
        {provide: RawMaterialService, useValue: rawMaterialServiceSpy},
        {provide: ProductService, useValue: productServiceSpy},
        {provide: ToastService, useValue: toastServiceSpy}
      ]
    })
    .compileComponents();
  }

  function createFixture(){
    fixture = TestBed.createComponent(AssignRawMaterialComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
  }

  function injectServices(){
    rawMaterialService = TestBed.inject(RawMaterialService);
    productService = TestBed.inject(ProductService);
    toastService = TestBed.inject(ToastService);
  }

  function setDefaultFunctionReturnValues(){  
    rawMaterialService.getAll.and.returnValue(of(rawMaterialData));
    productService.getProductBomById.and.returnValue(of(productRawMaterialData));

    productService.getPartById.and.returnValue(of(productInfo));
    productService.getAssemblyById.and.returnValue(of(productInfo));

    productService.updateProductRawMaterial.and.returnValue(of({}));
    productService.deleteProductRawMaterial.and.returnValue(of({}));
  }
  
  function resetFunctionCalls(){
    rawMaterialService.getAll.calls.reset();
    productService.getProductBomById.calls.reset();

    productService.getPartById.calls.reset();
    productService.getAssemblyById.calls.reset();

    productService.updateProductRawMaterial.calls.reset();
    productService.deleteProductRawMaterial.calls.reset();
  }

  describe('Initialize Component', ()=>{

    beforeEach(waitForAsync(()=>{
      initializeComponent()
      .then(()=>{
        createFixture();
        injectServices();
        setDefaultFunctionReturnValues();
      });  
    }));

    afterAll(resetFunctionCalls);

    it('should create', () => {
      expect(component).toBeTruthy();
    });
  });

  describe('Initialize UI', ()=>{

    let formGroupReset;

    beforeEach(waitForAsync(()=>{
      initializeComponent()
      .then(()=>{
        createFixture();
        injectServices();
        setDefaultFunctionReturnValues();
      });  
    }));

    afterEach(resetFunctionCalls);

    it('should set Raw Material Grid Data, filtering out BOMs that are already added', fakeAsync(()=>{
      
      fixture.detectChanges();
      flush();

      const productRawMaterialIds = productRawMaterialData.map(rm=>rm.componentId);
      const filteredRawMaterialResult = rawMaterialData.filter(rm=>!productRawMaterialIds.includes(rm.id));
  
      component.rawMaterialsGridData$.subscribe((res)=>{
        expect(res.length).toBe(filteredRawMaterialResult.length);
  
        res.forEach((rm, index)=>{
          expect(rm.name).toBe(filteredRawMaterialResult[index].rawMaterialName);
          expect(rm.description).toBe(filteredRawMaterialResult[index].rawMaterialDescription);
          expect(rm.grade).toBe(filteredRawMaterialResult[index].grade);
        });
  
      });

      flush();

    }));

    it('should set Product Raw Material Grid Data', fakeAsync(()=>{

      fixture.detectChanges();
      flush();

      component.productRawMaterialGridData$.subscribe((res)=>{
        expect(res.length).toBe(productRawMaterialData.length);

        res.forEach((rm, index)=>{
          expect(rm.id).toBe(productRawMaterialData[index].componentId);
          expect(rm.ratioType.toString()).toBe(RatioType[productRawMaterialData[index].bomLevel]);
          expect(rm.ratio).toBe(productRawMaterialData[index].perAssemblyQuantity);
        });
      });

      flush();

    }));

    it('should call correct ProductService method if parentUI is set to part', fakeAsync(()=>{
      
      component.parentUI = 'part';
      component.productId = productId;
      formGroupReset = spyOn(component.formGroup, 'reset');

      fixture.detectChanges();
      flush();

      expect(productService.getAssemblyById).not.toHaveBeenCalled();
      expect(productService.getPartById).toHaveBeenCalledOnceWith(productId);
      expect(formGroupReset).toHaveBeenCalledOnceWith(
        convertProductInfoForFormGroupUsage(productInfo));

    }));

    it('should call correct ProductService method if parentUI is set to assembly', fakeAsync(()=>{
      
      component.parentUI = 'assembly';
      component.productId = productId;
      formGroupReset = spyOn(component.formGroup, 'reset');

      fixture.detectChanges();
      flush();

      expect(productService.getAssemblyById).toHaveBeenCalledOnceWith(productId);
      expect(productService.getPartById).not.toHaveBeenCalled();
      expect(formGroupReset).toHaveBeenCalledOnceWith(
        convertProductInfoForFormGroupUsage(productInfo));

    }));

  });

  describe('Adding Raw Materials', ()=>{
  
    beforeEach(waitForAsync(()=>{
      initializeComponent()
      .then(()=>{
        createFixture();
        injectServices();
        setDefaultFunctionReturnValues();
      });  
    }));

    afterEach(resetFunctionCalls);

    it('should remove item from Raw Materials Grid, & Add it to Product Raw Materials Grid', fakeAsync(()=>{
      
      const selectedRawMaterial= rawMaterialData[1];

      fixture.detectChanges();
      flush();

      component.onAddClick(
        component.convertRawMaterialToRawMaterialVM(selectedRawMaterial));

      fixture.detectChanges();
      flush();

      component.productRawMaterialGridData$.subscribe(res=>{
        expect(res.length).toBe(2);
        expect(res.filter(rm=>rm.id==selectedRawMaterial.id).length).toBe(1);
      });
  
      component.rawMaterialsGridData$.subscribe(res=>{
        expect(res.length).toBe(1);
        expect(res.filter(rm=>rm.id==selectedRawMaterial.id).length).toBe(0);
      });

      flush();

    }));
  });

  describe('Removing Raw Materials', ()=>{

    beforeEach(waitForAsync(()=>{
      initializeComponent()
      .then(()=>{
        createFixture();
        injectServices();
        setDefaultFunctionReturnValues();
      });  
    }));

    afterEach(resetFunctionCalls);

    it('should remove from Product Raw Material Grid & Add it to Raw Materials Grid', fakeAsync(()=>{
      const selectedRawMaterial = rawMaterialData[0];

      fixture.detectChanges();
      flush();

      component.onMinusClick(
        component.convertRawMaterialToRawMaterialVM(selectedRawMaterial));

      fixture.detectChanges();
      flush();

      component.productRawMaterialGridData$.subscribe(res=>{
        expect(res.length).toBe(0);
        expect(res.filter(rm=>rm.id==selectedRawMaterial.id).length).toBe(0);
      });
  
      component.rawMaterialsGridData$.subscribe(res=>{
        expect(res.length).toBe(3);
        expect(res.filter(rm=>rm.id==selectedRawMaterial.id).length).toBe(1);
      });

      flush();

    }));
  });

  describe('Details regarding Product Raw Material Input Changes', ()=>{

    beforeEach(waitForAsync(()=>{
      initializeComponent()
      .then(()=>{
        createFixture();
        injectServices();
        setDefaultFunctionReturnValues();
      });  
    }));

    afterEach(resetFunctionCalls);

    it('should set the correct ratioType on the correct Product Raw Material Item', fakeAsync(()=>{
      
      const selectedRawMaterial = rawMaterialData[1];
      const rawMaterialToChangeId = rawMaterialData[0].id;

      fixture.detectChanges();
      flush();

      component.onAddClick(
        component.convertRawMaterialToRawMaterialVM(selectedRawMaterial));

      fixture.detectChanges();
      flush();

      component.onRatioTypeChange(rawMaterialToChangeId, "Each");

      expect(component.cachedProductRawmaterials[rawMaterialToChangeId].ratioType).toBe(RatioType.Each);

    }));

    it('should set the correct ratio value on the correct Product Raw Material Item', fakeAsync(()=>{
      
      const selectedRawMaterial = rawMaterialData[1];
      const rawMaterialToChangeId = rawMaterialData[0].id;

      fixture.detectChanges();
      flush();

      component.onAddClick(
        component.convertRawMaterialToRawMaterialVM(selectedRawMaterial));

      fixture.detectChanges();
      flush();

      component.onRatioChange(rawMaterialToChangeId, "5");
      expect(component.cachedProductRawmaterials[rawMaterialToChangeId].ratio).toBe(5);

    }));    

  });

  describe('Details regarding Form Submission', ()=>{

    beforeEach(waitForAsync(()=>{
      initializeComponent()
      .then(()=>{
        createFixture();
        injectServices();
        setDefaultFunctionReturnValues();
      });  
    }));

    afterEach(resetFunctionCalls);

    it(`should call the correct ProductService method when adding/removing some 
      Product Raw Materials, where number of Product Raw Materials is still > 0`, fakeAsync(()=>{

        const selectedRawMaterial = rawMaterialData[1];
  
        fixture.detectChanges();
        flush();
  
        component.onAddClick(
          component.convertRawMaterialToRawMaterialVM(selectedRawMaterial));

        component.onOkClick();
  
        fixture.detectChanges();
        flush();

        expect(productService.updateProductRawMaterial)
        .toHaveBeenCalledOnceWith(component.productId, jasmine.any(Array));

    }));

    it('should call the correct ProductService method when removing all Product Raw Materials', fakeAsync(()=>{

      const selectedRawMaterial = rawMaterialData[0];
  
      fixture.detectChanges();
      flush();
  
      component.onMinusClick(
        component.convertRawMaterialToRawMaterialVM(selectedRawMaterial));

      component.onOkClick();
  
      fixture.detectChanges();
      flush();

      expect(productService.deleteProductRawMaterial)
      .toHaveBeenCalledOnceWith(component.productId);

    }));

  });

});
