import { Component, OnInit, Output, EventEmitter, OnDestroy, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { RawMaterial } from '@app/_models';
import { ProductService, RawMaterialService } from '@app/_services';
import { RemoveEvent, SaveEvent } from '@progress/kendo-angular-grid';
import { BehaviorSubject, forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';

import * as _ from 'lodash';
import { ToastService } from '@dis/services/message/toast.service';

interface RawMaterialVM {
  id: number;
  name: string;
  type: string;
  ratio: number;
  ratioType: RatioType;
  uom: string;
  description: string;
  grade: string;
  remarks: string;
  supplier: string;
  length: string;
  width: string;
  thickness: string;
  price: number;
}

enum RatioType {
  Value = 0,
  Each = 1,
  Piece = 2
}

@Component({
  selector: '[app-assign-raw-material]',
  templateUrl: './assign-raw-material.component.html',
  styleUrls: ['./assign-raw-material.component.scss']
})
export class AssignRawMaterialComponent implements OnInit, OnDestroy {

  @Input() productId: number = -1;
  @Input() parentUI: string = "";
  @Output() closeWindow = new EventEmitter<boolean>();
  

  data = {
    partNo: "",
    partName: "",
    customer: "",
    partFamily: "",
    remarks: "",
    productionYield: 0
  };

  formGroup: FormGroup;

  cachedRawMaterials: {[id: number]: RawMaterialVM} = {};
  rawMaterialsGridDataSubject = new BehaviorSubject<RawMaterialVM[]>([]);
  rawMaterialsGridData$ = this.rawMaterialsGridDataSubject.asObservable();
  myRawMaterialSelection: number[] = [];

  cachedProductRawmaterials: {[id: number]: RawMaterialVM} = {};
  productRawMaterialGridDataSubject = new BehaviorSubject<RawMaterialVM[]>([]);
  productRawMaterialGridData$ = this.productRawMaterialGridDataSubject.asObservable();
  containedBomFromFirstCall: boolean;

  constructor(
    private rawMaterialService: RawMaterialService, 
    private productService: ProductService, 
    private toastr: ToastService
  ) { 

    this.containedBomFromFirstCall = false;

    const formControls = Object.keys(this.data)
      .reduce((prev, cur)=>{
        return { ...prev, [cur]: new FormControl({value: this.data[cur], disabled: true}) };
      }, {});

    this.formGroup = new FormGroup(formControls);
  }

  ngOnInit(): void {

    this.setProductInformation(this.parentUI);

    forkJoin([
      this.rawMaterialService.getAll(),
      this.productService.getProductBomById(this.productId),
    ])
    .pipe(
      map(res=>({
        allRawMaterials: res[0]
          .map(this.convertRawMaterialToRawMaterialVM)
          .reduce((prev, cur)=>({...prev, [cur.id]: cur}), {}),
        productRawMaterials: res[1]
          .map(res=>({
            id: res.componentId,
            ratioType: RatioType[res.bomLevel],
            ratio: res.perAssemblyQuantity
          }))
          .reduce((prev, cur)=>({...prev, [cur.id]: cur}), {})
      })
    ))
    .subscribe(res=>{

      this.cachedRawMaterials = res.allRawMaterials; 
      console.log(this.cachedProductRawmaterials = res.productRawMaterials);

      Object.keys(this.cachedProductRawmaterials)
        .forEach(id=>{
          if(this.cachedRawMaterials.hasOwnProperty(id))
            this.cachedProductRawmaterials[id] = 
              Object.assign(this.cachedRawMaterials[id], this.cachedProductRawmaterials[id]);
        });

      this.rawMaterialsGridDataSubject.next(
        Object.values(_.omit(this.cachedRawMaterials, Object.keys(res.productRawMaterials)))
      );

      const productRawMaterials = Object.values(this.cachedProductRawmaterials);

      if(productRawMaterials.length>0)
        this.containedBomFromFirstCall = true;

      this.productRawMaterialGridDataSubject.next(productRawMaterials);

    });
  }

  setProductInformation(parentUI: string): void {

    const resetFormGroup = res=>{
      this.formGroup.reset({
        partNo: res.name,
        partName: res.description,
        customer: res.customers,
        partFamily: res.partFamily,
        remarks: res.remarks,
        productionYield: res.productionYield
      });
    };

    switch(parentUI.toUpperCase()){
      case "PART":
        this.productService.getPartById(this.productId)
          .subscribe(resetFormGroup);
        break;
      case "ASSEMBLY":
        this.productService.getAssemblyById(this.productId)
          .subscribe(resetFormGroup);
        break;
    } 
  }

  convertRawMaterialToRawMaterialVM(rawMaterial: RawMaterial): RawMaterialVM {
    return {
      id: rawMaterial.id,
      name: rawMaterial.rawMaterialName,
      uom: rawMaterial.uoM,
      description: rawMaterial.rawMaterialDescription,
      grade: rawMaterial.grade,
      supplier: rawMaterial.supplierName,
      length: rawMaterial.length,
      width: rawMaterial.width,
      thickness: rawMaterial.thickness,
      price: rawMaterial.price,
    } as RawMaterialVM;
  }

  onClose(): void {
    this.closeWindow.emit(true);
  }

  ngOnDestroy(): void {
    this.closeWindow.unsubscribe();
  }

  getRatioTypes(): string[] {
    return Object.keys(RatioType).filter(key=>isNaN(parseInt(key)));
  }

  onAddClick(rawMaterial: RawMaterialVM): void {

    this.cachedProductRawmaterials[rawMaterial.id] = rawMaterial;
    const productRawMaterialKeys = Object.keys(this.cachedProductRawmaterials);

    this.productRawMaterialGridDataSubject.next(
      Object.values(this.cachedProductRawmaterials));
    
    this.rawMaterialsGridDataSubject.next(
      Object.values(_.omit(this.cachedRawMaterials, productRawMaterialKeys)));
  }

  onMinusClick(rawMaterial: RawMaterialVM): void {

    delete this.cachedProductRawmaterials[rawMaterial.id];

    const productRawMaterialKeys = Object.keys(this.cachedProductRawmaterials);

    this.productRawMaterialGridDataSubject.next(
      Object.values(this.cachedProductRawmaterials));

    this.rawMaterialsGridDataSubject.next(
      Object.values(_.omit(this.cachedRawMaterials, productRawMaterialKeys)));
  }

  onOkClick(): void {

    const data = Object.values(this.cachedProductRawmaterials);

    if(data.length > 0){

      const convertRawMaterialVMForUpdate = this.convertRawMaterialVMForUpdate.bind(this);

      this.productService.updateProductRawMaterial(
        this.productId, 
        data.map(convertRawMaterialVMForUpdate)
      ).subscribe(res=>{
        if(res)
          this.toastr.success("Your data has been updated successfully");
        this.closeWindow.emit(true);
      });

    }
    else if(this.containedBomFromFirstCall) {
      this.productService.deleteProductRawMaterial(this.productId)
        .subscribe(res=>{
          if(res)
            this.toastr.success("Your data has been deleted successfully");
          this.closeWindow.emit(true);
        });
    }
  }

  convertRawMaterialVMForUpdate(rmVM: RawMaterialVM): {
    productAssemblyId: number;
    componentId: number;
    bomLevel?: number;
    perAssemblyQuantity: number;
    remarks: string;
  } {
    return Object.assign({
      productAssemblyId: this.productId,
      componentId: rmVM.id,
      
      perAssemblyQuantity: rmVM.ratio,
      remarks: rmVM.remarks
    }, 
    rmVM.ratioType ? { bomLevel: parseInt(RatioType[rmVM.ratioType]) } : {} );
  }

  onRatioTypeChange(rawMaterialId: number, value): void {
    const condition = this.cachedProductRawmaterials.hasOwnProperty(rawMaterialId);
    if(condition){
      this.cachedProductRawmaterials[rawMaterialId].ratioType = value;
    }
  }

  onRatioChange(rawMaterialId: number, value: string): void {
    const ratio = parseFloat(value);   
    const condition = this.cachedProductRawmaterials.hasOwnProperty(rawMaterialId) && ratio

    if(condition)
      this.cachedProductRawmaterials[rawMaterialId].ratio = ratio;
  }
}
