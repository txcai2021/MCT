import {Component, OnInit, ViewChild} from '@angular/core';
import {DataBindingDirective, EditEvent, RemoveEvent} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {BehaviorSubject, Observable} from 'rxjs';
import {ToastService} from '@dis/services/message/toast.service';
import {CustomDialogService} from '@dis/services/message/custom-dialog.service';
import { CustomerService, PartsService, ProductService } from '@app/_services';
import { first } from 'rxjs/operators';
import { Parts } from '@app/_models';

import { ListFilterHelper, SubjectObservablePair } from '../../../_helpers';
import * as _ from 'lodash';

@Component({
  selector: 'app-part-list',
  templateUrl: './part-list.component.html',
  styleUrls: ['./part-list.component.scss']
})
export class PartListComponent implements OnInit {

  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;

  gridDataSubject: BehaviorSubject<Parts[]> = new BehaviorSubject<Parts[]>([]);
  gridView : Observable<Parts[]> = this.gridDataSubject.asObservable();

  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  editedRowIndex: number;

  public partFamilies: Array<{ text: string }>;
  partFamilyFilter: ListFilterHelper<{ text: string }>;

  fgDimensions: string[];
  fgDimensionFilter: ListFilterHelper<string>;


  public cusotmers: Array<{ text: string, value: number}>;
  public data: any = {
    name: '',
    description: '',
    revision: '',
    partFamily: '',
    customerId: 0,
    thumbnailImageFileName: '',
    remarks: '',
    fgDimension: '',
    qtyPerLot: 0,
    productionYield: 0,
    priority: 1,
    unitofMeasure: '',
    buyFlag: false
  };

  openAssignRawMaterialWindowSubject = new BehaviorSubject<boolean>(false);
  openAssignRawMaterialWindow$ = this.openAssignRawMaterialWindowSubject.asObservable();
  assignRawMaterialWindowProductIdSubject = new BehaviorSubject<number>(-1);
  assignRawMaterialWindowProductId$ = this.assignRawMaterialWindowProductIdSubject.asObservable();

  

  constructor(private toastr: ToastService, private customDialog: CustomDialogService,
    private partService: PartsService,private customerService: CustomerService,private productService: ProductService) {
        this.formGroup = new FormGroup({
          name: new FormControl(this.data.name),
          description: new FormControl(this.data.description),
          revision: new FormControl(this.data.revision),
          partFamily: new FormControl(this.data.partFamily),
          customerId: new FormControl(this.data.customerId),
          thumbnailImageFileName: new FormControl(this.data.thumbnailImageFileName),
          remarks: new FormControl(this.data.remarks),
          fgDimension: new FormControl(this.data.fgDimension),
          qtyPerLot: new FormControl(this.data.qtyPerLot),
          productionYield: new FormControl(this.data.productionYield),
          priority: new FormControl(this.data.priority),
          unitofMeasure: new FormControl(this.data.unitofMeasure),
          buyFlag: new FormControl(this.data.buyFlag),
        });

        this.fgDimensionFilter = new ListFilterHelper<string>({
          findIndexStrategy: filterWord => (word => word === filterWord),
          filterStrategy: (cachedWordList, filterWord) => 
            cachedWordList.filter(word => {
              const text = word?.toLowerCase();
              const input = filterWord?.toLowerCase();
              return text?.includes(input);
            })
        });

        this.partFamilyFilter = new ListFilterHelper<{ text: string }>({
          findIndexStrategy: filterWord => (wordObj => wordObj?.text === filterWord),
          filterStrategy: (cachedWordObjList, filterWordObj) =>
            cachedWordObjList.filter(wordObj => {
              const text = wordObj?.text?.toLowerCase();
              const input = filterWordObj?.text?.toLowerCase();
              return text?.includes(input);
            })
        });
     }


  onFilter(inputValue: string): void {
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          }
        ],
      },
    }).data;

    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }


  ngOnInit(): void {
    this.loadItems();
  }

  onAddNewClick(): void {
    this.isWindowOpened = true;
    this.isNew = true;
  }

  onEditClick(event: EditEvent): void {
    this.isWindowOpened = true;
    this.isNew = false;
    this.formGroup.reset(event.dataItem);
    this.editedRowIndex = event.rowIndex;

  }

  closeWindow(window: 'form' | 'assignRawMaterial'): void {
    switch(window){
      case 'form':
        this.isWindowOpened = false;
        this.formGroup.reset();
        this.mySelection = [];
        break;
      case 'assignRawMaterial':
        this.openAssignRawMaterialWindowSubject.next(false);
        break;
    }
    this.loadItems();
  }

  submitWindow(item): void {

    this.isWindowOpened = false;

    if(!this.isNew){
      const items = this.gridDataSubject.value;
      item.id = items[this.editedRowIndex].id;
    }

    console.log(item, this.formGroup.value);
    this.saveItem(item);
  }

  public saveItem(item) : void {

    if (this.isNew) {
      this.partService
        .save(this.formGroup.value)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    }
    else {

      let data: Parts = item;
      data.id = item.id;

      this.partService
        .update(item.id, data)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been updated sucessfully.');
          },
          error: (error) => {
          },
        });
    }
  }

  onDeleteClick(event: RemoveEvent ): void {
    this.editedRowIndex = event.rowIndex;
    this.customDialog.confirm().subscribe(res => {
      // Primary (Yes) button is clicked
      if (res.primary){
          this.removeItem();
      }
    });
  }

  onAddNewCustomer(): void {
    
  }


  removeItem(): void {
    // do you processing and close window
    let items = this.gridDataSubject.value;

     // success should be in resolve of subscribe method
     this.partService
     .delete(items[this.editedRowIndex].id)
     .pipe(first())
     .subscribe({
       next: () => {
         this.gridDataSubject.next(items);
         this.toastr.success('Your data has been removed sucessfully.');
       },
       error: (error) => {},
     });

     
    items.splice(this.editedRowIndex, 1);

    // array isnt updating
    // Retrieve backend data to update
    const temp = [...items];
    // noinspection JSUnusedAssignment
    items = [];
    items = [...temp];
  }

   callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void{
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }

  loadItems() {

    this.partService.getAll()
    .subscribe((result) => {
      if(result) {
        result =  orderBy(result, [{ field: 'id', dir: 'desc' }]);
        this.gridDataSubject.next(result);
      }  
    });

    this.productService.getPartFamilies()
    .subscribe((data) => {
      if(!data) {
        this.partFamilies = this.partFamilyFilter.cachedWordList = [];
        return;
      }
      this.partFamilyFilter.cachedWordList = data.map(res=>({ text: res }));
      this.partFamilies = this.partFamilyFilter.cachedWordList;
    })

    this.customerService.getAll()
    .subscribe((data) => {
      if(data) {
        this.cusotmers  = data.map(res => ({
          text: res.name,
          value: res.id
        }));
      }
    });

    this.productService.getFGDimensions().subscribe((data) => {
      if(!data) return;
      this.fgDimensions = this.fgDimensionFilter.cachedWordList = data;
    });

  }

  onAssignRawMaterialClick(): void {

    const selection = parseInt(this.mySelection[0]);

    if(isNaN(selection) || selection<0) return;

    this.assignRawMaterialWindowProductIdSubject.next(selection);
    this.openAssignRawMaterialWindowSubject.next(true);
  }

  addNewPartFamily(): void {
    if(!this.partFamilyFilter.tryAddWordToCache()) return;
    this.partFamilies = this.partFamilyFilter.cachedWordList;
  }

  addNewFgDimension(): void {
    if(!this.fgDimensionFilter.tryAddWordToCache()) return;
    this.fgDimensions = this.fgDimensionFilter.cachedWordList;
  }

  handleFilter(filterFor: 'partFamily'|'fgDimension', filter: string): void {
    switch(filterFor){
      case 'partFamily':
        this.partFamilies = this.partFamilyFilter.getFilterdArray({ text: filter });
        break;
      case 'fgDimension':
        this.fgDimensions = this.fgDimensionFilter.getFilterdArray(filter);
        break;
    }
  }

}
