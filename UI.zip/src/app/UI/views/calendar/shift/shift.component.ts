import { Component, OnInit, ViewChild } from '@angular/core';

import {
  DataBindingDirective,
  EditEvent,
  RemoveEvent,
  PageChangeEvent,
} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable } from 'rxjs';
import { ToastService } from '@dis/services/message/toast.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { first } from 'rxjs/operators';
import { ShiftService, MealService } from '@app/_services';
import { Shift, Meal } from '@app/_models';
import { SelectableSettings } from '@progress/kendo-angular-grid';

import { formatDate } from '@telerik/kendo-intl';

@Component({
  selector: 'app-shift',
  templateUrl: './shift.component.html',
  styleUrls: ['./shift.component.scss'],
})
export class ShiftComponent implements OnInit {
  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;
  public min: Date = new Date(2000, 2, 10, 2, 30);
  public max: Date = new Date(2002, 2, 10, 22, 15);
  public value: Date = new Date(2000, 2, 10, 10, 0);
  public idTextFieldDisabled = true;
  public selectableSettings: SelectableSettings;

  public checkboxOnly = true;
  public mode = 'single';
  public drag = false;

  gridDataSubject = new BehaviorSubject<Shift[]>([]);
  gridView = this.gridDataSubject.asObservable();

  gridViewMealSubject = new BehaviorSubject<Meal[]>([]);
  gridViewMeal = this.gridViewMealSubject.asObservable();

  previousSelectedMeal = [];
  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  editedRowIndex: number;
  isSecondWindowOpened = false;

  mySelectionMeal: any[] = [];
  pageSize = 10;
  skip = 0;

  public data: any = {
    idName: '',
    description: '',
    startTime: '',
    endTime: '',
  };
  constructor(
    private toastr: ToastService,
    private shiftService: ShiftService,
    private mealService: MealService,
    private customDialog: CustomDialogService
  ) {

    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
      startTime: new FormControl(this.data.startTime, Validators.required),
      endTime: new FormControl(this.data.endTime, Validators.required),
    });
  }

  ngOnInit(): void {
    this.loadItems();
  }

  public setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: this.checkboxOnly,
      drag: this.drag,
      mode: 'single',
    };
  }

  loadItems() {
    this.setSelectableSettings();
    this.loadShiftGridData();
    this.loadMealGridData();
  }

  loadShiftGridData(): void {
    this.shiftService.getAll().subscribe((result) => {
      if (result){
        result = orderBy(result, [
          { field: 'id', dir: 'desc' },
        ]);

        this.gridDataSubject.next(result);
      }
    });
  }

  loadMealGridData(): void {
    this.mealService.getAll().subscribe((result) => {
      if (result){
        result = orderBy(result, [
          { field: 'id', dir: 'desc' },
        ]);

        this.gridViewMealSubject.next(result);
      }
    });
  }

  closeWindowWarning() {
    this.isSecondWindowOpened = false;
  }

  onFilter(inputValue: string): void {
    console.log(inputValue);
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          },
        ],
      },
    }).data;

    console.log(items);
    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }

  clearData(): void {
    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
      startTime: new FormControl(this.data.startTime, Validators.required),
      endTime: new FormControl(this.data.endTime, Validators.required),
    });
    this.previousSelectedMeal = [];
  }

  onAddNewClick(): void {
    this.idTextFieldDisabled = false;
    this.clearData();
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
    this.previousSelectedMeal = [];
  }

  editButton(event: EditEvent): void {
    this.idTextFieldDisabled = true;
    let newData = {
      idName: '',
      startTime: new Date(2002, 2, 10, 22, 15),
      endTime: new Date(2002, 2, 10, 22, 15),
      description: '',
    };

    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } 
    else {

      let selectedindex = this.mySelection[this.mySelection.length - 1];
      let countindex = 0;

      for (var row in this.gridView) {
        let curTup = this.gridView[row];
        if (curTup['id'] == selectedindex) {
          let selectedchildarr = curTup['calendarChilds'];

          for (var index in selectedchildarr) {
            this.previousSelectedMeal.push(selectedchildarr[index]);
            this.mySelectionMeal.push(selectedchildarr[index]['calendarId']);
          }

          let getstarttime = curTup.startTime;
          let startTimeArray = getstarttime.split(':');
          let startTimeHour = startTimeArray[0];
          let startTimeMinute = startTimeArray[1];
          let getendTime = curTup.endTime;
          let endTimeArray = getendTime.split(':');
          let endTimeHour = endTimeArray[0];
          let endTimeMinute = endTimeArray[1];
          newData.idName = curTup.name;
          newData.startTime = new Date(
            2002,
            2,
            10,
            startTimeHour,
            startTimeMinute
          );
          newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);
          newData.description = curTup.description;

          this.formGroup.reset(newData);
          this.editedRowIndex = countindex;
          this.isWindowOpened = !this.isWindowOpened;
          this.isNew = false;
        }
        countindex += 1;
      }
    }
  }

  onEditClick(event: EditEvent): void {
    let selectedchildarr = event['dataItem']['calendarChilds'];

    for (var index in selectedchildarr) {
      this.previousSelectedMeal.push(selectedchildarr[index]);
      this.mySelectionMeal.push(selectedchildarr[index].calendarId);
    }

    this.idTextFieldDisabled = true;
    let newData = {
      idName: '',
      startTime: new Date(2002, 2, 10, 22, 15),
      endTime: new Date(2002, 2, 10, 22, 15),
      description: '',
    };

    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;

    let getstarttime = event.dataItem.startTime;
    let startTimeArray = getstarttime.split(':');
    let startTimeHour = startTimeArray[0];
    let startTimeMinute = startTimeArray[1];
    let getendTime = event.dataItem.endTime;
    let endTimeArray = getendTime.split(':');
    let endTimeHour = endTimeArray[0];
    let endTimeMinute = endTimeArray[1];

    newData.idName = event.dataItem.name;
    newData.startTime = new Date(2002, 2, 10, startTimeHour, startTimeMinute);
    newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);
    newData.description = event.dataItem.description;

    this.formGroup.reset(newData);
    this.editedRowIndex = event.rowIndex;
  }

  closeWindow(): void {
    this.mySelectionMeal = [];
    this.isWindowOpened = false;
  }

  submitWindow(item): void {
    if (item['startTime'] >= item['endTime']) {
      this.isSecondWindowOpened = true;
    } 
    else {

      this.isWindowOpened = false;

      if (!this.isNew) {
        const items = this.gridDataSubject.value;
        item.id = items[this.editedRowIndex].id;
      }
      console.log(item);
      this.saveItem(item);
    }
  }

  twofourHoursformat(time): string {
    var hours = Number(time.match(/^(\d+)/)[1]);
    var minutes = Number(time.match(/:(\d+)/)[1]);
    var AMPM = time.match(/\s(.*)$/)[1];
    if (AMPM == 'PM' && hours < 12) hours = hours + 12;
    if (AMPM == 'AM' && hours == 12) hours = hours - 12;
    var sHours = hours.toString();
    var sMinutes = minutes.toString();
    if (hours < 10) sHours = '0' + sHours;
    if (minutes < 10) sMinutes = '0' + sMinutes;
    return sHours + ':' + sMinutes;
  }

  public saveItem(item): void {

    let newcalendarDetails = this.getSelectedMealDetails();

    let getStartTime = this.twofourHoursformat(item['startTime'].toLocaleTimeString());
    let getEndTime = this.twofourHoursformat(item['endTime'].toLocaleTimeString());

    let postMealObject = this.createPostMealObject({
      id: item['id'],
      name: item['idName'],
      description: item['description'],
      startTime: getStartTime,
      endTime: getEndTime,
      calendarDetails: newcalendarDetails
    });

    if (this.isNew) {
      this.shiftService
        .save(postMealObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    } else {

      let uncheckedMealsThatWerePreviouslyChecked = 
        this.getUncheckedShiftsThatWerePreviouslyChecked(newcalendarDetails);

        postMealObject['calendarDetails'] = [
          ...uncheckedMealsThatWerePreviouslyChecked, 
          ...newcalendarDetails
        ];

      this.shiftService
        .update(postMealObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    }

    this.mySelectionMeal = [];
    this.previousSelectedMeal = [];

  }

  getSelectedMealDetails() {
    return this.gridViewMealSubject.value
    .filter(meal => this.mySelectionMeal?.includes(meal.id))
    .map(meal => ({ ...meal, calendarId: meal.id }));
  }

  createPostMealObject(
    data: {
      id: number;
      name: string;
      description: string;
      startTime: string;
      endTime: string;
      calendarDetails: any;
    }
  ){
    return {
      Id: data.id,
      Name: data.name,
      Category: 'Shift',
      Description: data.description,
      StartTime: data.startTime,
      EndTime: data.endTime,
      Type: '1',
      createdDate: formatDate(new Date(),'s'),
      calendarDetails: data.calendarDetails,
    };
  }

  getUncheckedShiftsThatWerePreviouslyChecked(currentlySelectedMeals) {
    let currentlySelectedIds = currentlySelectedMeals.map(selected => selected.calendarId);

    let previouslyCheckedUncheckedMeals = this.previousSelectedMeal
    .filter(
      previouslySelectedMeal => 
        !currentlySelectedIds.includes(previouslySelectedMeal.calendarId)
    );

    return previouslyCheckedUncheckedMeals.map(meal => ({
        ...meal,
        parentCalendarId: -1,
        name: meal.name?.split('-')[1] ?? ''
      })
    );
  }

  deleteButton(): void {
    console.log(this.mySelection);
    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } else {

      this.editedRowIndex = parseInt(this.mySelection[0]);
      this.customDialog.confirm().subscribe((res) => {
        // Primary (Yes) button is clicked
        if (res.primary) {
          this.removeItem();
        }
      });
    }
  }

  onDeleteClick(event: RemoveEvent): void {
    this.editedRowIndex = event['dataItem'].id;
    this.customDialog.confirm().subscribe((res) => {
      // Primary (Yes) button is clicked
      if (res.primary) {
        this.removeItem();
      }
    });
  }

  removeItem(): void {
    // do you processing and close window
    let items = this.gridDataSubject.value;

    let deletedId = this.editedRowIndex;
    let getdeleteid: any = 0;
    for (var row in items) {
      let curTup = items[row];
      if (curTup['id'] == deletedId) {
        getdeleteid = curTup['id'];
        break;
      }
    }

    items.splice(this.editedRowIndex, 1);

    // array isnt updating
    // Retrieve backend data to update
    const temp = [...items];
    // noinspection JSUnusedAssignment
    items = [];
    items = [...temp];

    // success should be in resolve of subscribe method
    this.shiftService
      .delete(String(getdeleteid))
      .pipe(first())
      .subscribe({
        next: (data) => {
          if (data == -1) {
            this.toastr.error('Shift is used by Day');
          } else {
            this.loadItems();
            this.toastr.success('Your data has been removed sucessfully.');
          }
        },
        error: (error) => {},
      });
    this.mySelectionMeal = [];
    this.isWindowOpened = false;
    this.mySelection = [];
  }

  callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void {
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }
  pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();

    // Optionally, clear the selection when paging
    // this.mySelection = [];
  }
}
