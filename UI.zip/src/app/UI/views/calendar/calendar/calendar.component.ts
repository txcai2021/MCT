import { Component, OnInit, ViewChild } from '@angular/core';

import {
  DataBindingDirective,
  EditEvent,
  RemoveEvent,
  PageChangeEvent,
} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { of, BehaviorSubject, from, Observable } from 'rxjs';
import { ToastService } from '@dis/services/message/toast.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { first } from 'rxjs/operators';
import {
  ShiftService,
  MealService,
  weekService,
  DayService,
  calendarService,
  calendarExceptionService,
} from '@app/_services';
import { Shift, Meal } from '@app/_models';
import { SelectableSettings } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss'],
})
export class CalendarComponent implements OnInit {
  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;
  public min: Date = new Date(2000, 2, 10, 2, 30);
  public max: Date = new Date(2002, 2, 10, 22, 15);
  public value: Date = new Date(2000, 2, 10, 10, 0);
  public idTextFieldDisabled = true;
  public selectableSettings: SelectableSettings;

  public checkboxOnly = true;
  public mode = 'single';
  public drag = false;
  public day2: Array<any> = [
    { text: 'Small', value: 1, calendarid: 1 },
    { text: 'Medium', value: 2, calendarid: 2 },
    { text: 'Large', value: 3, calendarid: 3 },
  ];

  public weekDropDownList: any = [];

  public mealdict: any = {};
  public shiftdict: any = {};
  public daydict: any = {};
  public weekdict: any = {};
  public calendardict: any = {};
  public calendarexceptiondict: any = {};

  public selectedWeek = [];
  resultarr = [];
  resultarrId = [];
  holidayId = [];

  gridDataSubject = new BehaviorSubject<Shift[]>([]);
  gridView = this.gridDataSubject.asObservable();

  gridDataSubjectCalendarException = new BehaviorSubject<Meal[]>([]);
  gridViewCalendarException = this.gridDataSubjectCalendarException.asObservable();

  previousSelectedWeek = [];
  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  editedRowIndex: number;
  isSecondWindowOpened = false;
  isThirdWindowOpened = false;
  isFourthWindowOpened = false;

  mySelectionWeek: any[] = [];
  mySelectionCalendarException: any[] = [];
  previousmySelectionCalendarException = [];

  pageSize = 10;
  skip = 0;

  public data: any = {
    idName: '',
    description: '',
    startTime: '',
    endTime: '',
  };
  constructor(
    private toastr: ToastService,
    private shiftService: ShiftService,
    private mealService: MealService,
    private dayService: DayService,
    private weekService: weekService,
    private calendarService: calendarService,
    private calendarException: calendarExceptionService,
    private customDialog: CustomDialogService
  ) {

    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
      selectedWeek: new FormControl(),
    });

    this.createDayDictionary();
    this.getAndSetCalendarExceptionGridView();

    this.createMealDictionary();
    this.createShiftDictionary();

    let newarr = [];
    for (var i = 0; i < 53; i++) {
      this.resultarrId.push(false);
      let week1 = i + 1;
      let namestr = 'Week ' + week1;
      var obj = {
        id: i,
        name: namestr,
        week: '',
      };
      newarr.push(obj);
      this.resultarr.push(obj);
    }

    this.createWeekDictionary();
  }

  ngOnInit(): void {
    this.loadItems();
  }
  public setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: this.checkboxOnly,
      drag: this.drag,
      mode: 'single',
    };
  }

  applyWindow() {
    if (this.mySelectionWeek.length == 0) 
    {
      this.isSecondWindowOpened = true;
    } 
    else if (this.selectedWeek.length == 0) 
    {
      this.isThirdWindowOpened = true;
    } else 
    {
      for (let i = 0; i < this.mySelectionWeek.length; i++) {
        let curindex = this.mySelectionWeek[i];
        this.resultarr[curindex].week = this.selectedWeek[0].name;
        this.resultarrId[curindex] = this.selectedWeek[0].id;
      }
    }

  }

  loadItems() {
    this.setSelectableSettings();

    this.mySelectionWeek = [];
    this.mySelectionCalendarException = [];
    
    this.getAndSetCalendarGridView();
  }

  createDayDictionary(): void {
    this.dayService.getAll().subscribe((result) => {

      if (result){

        result = orderBy(result, [{ field: 'id', dir: 'desc' }]);

        for (var i = 0; i < result.length; i++) {
          let $id = result[i].id;

          let obj = {
            name: result[i]['name'],
            startTime: result[i]['startTime'],
            endTime: result[i]['endTime'],
            child: []
          };

          for (let j = 0;j < result[i]['calendarChilds'].length; j++) {
            obj['child'].push(result[i]['calendarChilds'][j]['calendarId']);
          }
                                                      
          this.daydict[$id] = [obj];
        }
      }

    });
  }

  createWeekDictionary(): void {
    this.weekService.getAll().subscribe((result) => {

      if (result){

        result = orderBy(result, [{ field: 'id', dir: 'desc' }]);

        for (let i = 0; i < result.length; i++) {

          let $id = result[i]['id'];
          this.weekDropDownList.push(result[i]);
          let obj = {
            name: result[i]['name'],
            child: []
          };

          if(result[i]['calendarChilds']){
            for (let j = 0; j < result[i]['calendarChilds'].length; j++) {
              obj['child'].push(result[i]['calendarChilds'][j]['calendarId']);
            }
          }

          this.weekdict[$id] = [];
          this.weekdict[$id].push(obj);
        }
      }
    });
  }

  createMealDictionary(): void {
    this.mealService.getAll().subscribe((result) => {

      if(result){
        for (var i = 0; i < result.length; i++) {
          let $id = result[i]['id'];
          let obj = {
            name: result[i]['name'],
            startTime: result[i]['startTime'],
            endTime: result[i]['endTime'],
            child: []
          };

          for (let j = 0; j < result[i]['calendarChilds'].length; j++) {
            obj['child'].push(result[i]['calendarChilds'][j]['calendarId']);
          }

          this.mealdict[$id] = [obj];
        }
      }     
    });
  }

  createShiftDictionary(): void {
    this.shiftService.getAll().subscribe((result) => {

      if (result){

        result = orderBy(result, [{ field: 'id', dir: 'desc' }]);

        for (var i = 0; i < result.length; i++) {

          let $id = result[i]['id'];
          let obj = {
            name: result[i]['name'],
            startTime: result[i]['startTime'],
            endTime: result[i]['endTime'],
            child: []
          };

          for (let j = 0; j < result[i]['calendarChilds'].length; j++) {
            obj['child'].push(result[i]['calendarChilds'][j]['calendarId']);
          }
          this.shiftdict[$id] = [obj];
        }
      }

    });
  }

  getAndSetCalendarGridView(): void {

    this.calendarService.getAll().subscribe((result) => {

      if (result){

        result = orderBy(result, [
          { field: 'id', dir: 'desc' },
        ]);

        for (var i = 0; i < result.length; i++) {
          let $id = result[i]['id'];

          let obj = { 
            name: result[i]['name'], 
            child: []
          };

          for (let j = 0; j < result[i]['calendarChilds'].length; j++) {
            obj['child'].push([
              result[i]['calendarChilds'][j]['calendarId'],
              result[i]['calendarChilds'][j]['value'],
            ]);
          }
          this.calendardict[$id] = [];
          this.calendardict[$id].push(obj);
        }

        this.gridDataSubject.next(result);
      }

    });
  }

  getAndSetCalendarExceptionGridView(): void {
    this.calendarException.getAll().subscribe((result) => {

      if (result){
        result = orderBy(result, [{ field: 'id', dir: 'desc' }]);

        let newdatearr = [];

        for (var i in result) {

          let curdatearr = result[i]['startDate'].split('T');
          this.calendarexceptiondict[result[i]['id']] = result[i]['name'];

          let newdate = curdatearr[0].split('-');
          let newyear = parseInt(newdate[0]);

          let newmonth = parseInt(newdate[1]);
          let newday = parseInt(newdate[2]);

          newdatearr.push(new Date(newyear, newmonth - 1, newday));
        }

        for (var i in newdatearr) {
          result[i]['startDate'] = newdatearr[i];
        }
        
        this.gridDataSubjectCalendarException.next(result);
      }
    });
  }

  closeWindowWarning() {
    this.isSecondWindowOpened = false;
    this.isThirdWindowOpened = false;
    this.isFourthWindowOpened = false;
  }
  onFilter(inputValue: string): void {
    console.log(inputValue);
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          },
        ],
      },
    }).data;

    console.log(items);
    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }

  clearData(): void {
    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),

      selectedWeek: new FormControl(),
    });
    this.previousSelectedWeek = [];
  }

  onAddNewClick(): void {
    this.mySelectionWeek = [];
    this.mySelectionCalendarException = [];
    this.isWindowOpened = false;
    for (let i = 0; i < this.resultarr.length; i++) {
      this.resultarr[i]['week'] = '';
      this.resultarrId[i] = false;
    }

    this.idTextFieldDisabled = false;
    this.clearData();
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
    this.previousSelectedWeek = [];
  }

  editButton(event: EditEvent): void {
    this.idTextFieldDisabled = true;
    let newData = {
      idName: '',
      startTime: new Date(2002, 2, 10, 22, 15),
      endTime: new Date(2002, 2, 10, 22, 15),
      description: '',
    };

    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } else {
      let selectedindex = this.mySelection[this.mySelection.length - 1];
      console.log('edit event');
      console.log(this.mySelection);
      console.log(this.gridView);
      console.log(event.dataItem);
      let countindex = 0;
      for (var row in this.gridView) {
        let curTup = this.gridView[row];
        if (curTup['id'] == selectedindex) {
          console.log(curTup);
          let selectedchildarr = curTup['calendarChilds'];
          console.log('length of child');
          console.log(selectedchildarr.length);
          for (var index in selectedchildarr) {
            this.previousSelectedWeek.push(selectedchildarr[index]);
            this.mySelectionCalendarException.push(
              selectedchildarr[index]['calendarId']
            );
          }

          console.log('current selection');
          console.log(this.mySelectionCalendarException);
          console.log('previous selection');
          console.log(this.previousSelectedWeek.length);
          console.log(this.previousSelectedWeek);

          let getstarttime = curTup.startTime;
          let startTimeArray = getstarttime.split(':');
          let startTimeHour = startTimeArray[0];
          let startTimeMinute = startTimeArray[1];
          let getendTime = curTup.endTime;
          let endTimeArray = getendTime.split(':');
          let endTimeHour = endTimeArray[0];
          let endTimeMinute = endTimeArray[1];
          newData.idName = curTup.name;
          newData.startTime = new Date(
            2002,
            2,
            10,
            startTimeHour,
            startTimeMinute
          );
          newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);
          newData.description = curTup.description;

          this.formGroup.reset(newData);
          this.editedRowIndex = countindex;
          this.isWindowOpened = !this.isWindowOpened;
          this.isNew = false;
        }
        countindex += 1;
      }
    }
  }

  onEditClick(event: EditEvent): void {
    console.log('oneditclick');
    let selectedchildarr = event['dataItem']['calendarChilds'];
    console.log('length of child');
    console.log(selectedchildarr.length);
    console.log(this.weekdict);
    console.log(selectedchildarr);

    this.previousSelectedWeek = [];
    let noofcalendarexceptindex = 0;
    for (var index in selectedchildarr) {
      let calendaridchild = selectedchildarr[index]['calendarId'];
      let newindex: any = String(Number(selectedchildarr[index]['value']) - 1);

      if (this.weekdict.hasOwnProperty(calendaridchild)) {
        this.previousSelectedWeek.push(selectedchildarr[index]['calendarId']);
        this.resultarrId[newindex] = selectedchildarr[index]['calendarId'];
        this.resultarr[newindex].week = this.weekdict[calendaridchild][0].name;
      } else {
        noofcalendarexceptindex += 1;
        this.mySelectionCalendarException.push(
          selectedchildarr[index]['calendarId']
        );
        this.previousmySelectionCalendarException.push(
          selectedchildarr[index]['calendarId']
        );
      }
    }
    console.log('previous selected week');
    console.log(this.previousSelectedWeek);

    console.log(event);
    this.idTextFieldDisabled = true;
    let newData = {
      idName: '',
      startTime: new Date(2002, 2, 10, 22, 15),
      endTime: new Date(2002, 2, 10, 22, 15),
      description: '',
    };
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;
    console.log('event');
    console.log(event.dataItem);

    let getstarttime = event.dataItem.startTime;
    let startTimeArray = getstarttime.split(':');
    let startTimeHour = startTimeArray[0];
    let startTimeMinute = startTimeArray[1];
    let getendTime = event.dataItem.endTime;
    let endTimeArray = getendTime.split(':');
    let endTimeHour = endTimeArray[0];
    let endTimeMinute = endTimeArray[1];

    newData.idName = event.dataItem.name;
    newData.startTime = new Date(2002, 2, 10, startTimeHour, startTimeMinute);
    newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);
    newData.description = event.dataItem.description;

    this.formGroup.reset(newData);
    this.editedRowIndex = event.rowIndex;
  }

  closeWindow(): void {
    console.log('close window');
    this.mySelectionWeek = [];
    this.previousmySelectionCalendarException = [];
    console.log(this.mySelectionCalendarException);
    this.mySelectionCalendarException = [];
    this.isWindowOpened = false;
    for (let i = 0; i < this.resultarr.length; i++) {
      this.resultarr[i]['week'] = '';
      this.resultarrId[i] = false;
    }
  }
  submitWindow(item): void {
    let all53weekdefined = false;
    for (let i = 0; i < this.resultarr.length; i++) {
      if (this.resultarrId[i] == false) {
        all53weekdefined = true;
        break;
      }
    }

    if (all53weekdefined) {
      this.isFourthWindowOpened = true;
    } else {
      this.isWindowOpened = false;

      if (!this.isNew) {
        const items = this.gridDataSubject.value;
        item.id = items[this.editedRowIndex].id;
      }

      this.saveItem(item);
    }
  }

  twofourHoursformat(time): string {
    var hours = Number(time.match(/^(\d+)/)[1]);
    var minutes = Number(time.match(/:(\d+)/)[1]);
    var AMPM = time.match(/\s(.*)$/)[1];
    if (AMPM == 'PM' && hours < 12) hours = hours + 12;
    if (AMPM == 'AM' && hours == 12) hours = hours - 12;
    var sHours = hours.toString();
    var sMinutes = minutes.toString();
    if (hours < 10) sHours = '0' + sHours;
    if (minutes < 10) sMinutes = '0' + sMinutes;
    return sHours + ':' + sMinutes;
  }

  // public saveItem(item): void {
  //   console.log('mySelectionCalendarException');
  //   console.log(this.mySelectionCalendarException);
  //   console.log('mealdetail');
  //   console.log(this.gridViewCalendarException);
  //   console.log('griddatasubject');
  //   console.log(this.gridDataSubjectMeal);
  //   let newcalendarDetails: any = [];
  //   for (var i in this.mySelectionCalendarException) {
  //     let elem = this.mySelectionCalendarException[i];
  //     console.log('elem ' + elem);
  //     for (var index in this.gridViewCalendarException) {
  //       let curTup = this.gridViewCalendarException[index];
  //       if (curTup['id'] == elem) {
  //         curTup['calendarId'] = elem;
  //         console.log('insidedetail');
  //         newcalendarDetails.push(curTup);
  //         console.log('outsidedetail');
  //       }
  //     }
  //   }
  //   console.log('newcalendar');
  //   console.log(newcalendarDetails);
  //   console.log(item);
  //   var options = { hour12: false };

  //   let getName = item['idName'];
  //   let getStartTime = this.twofourHoursformat(
  //     item['startTime'].toLocaleTimeString()
  //   );
  //   console.log('starttime');
  //   console.log(getStartTime);

  //   let getEndTime = this.twofourHoursformat(
  //     item['endTime'].toLocaleTimeString()
  //   );
  //   let getid = item['id'];
  //   let getdescription = item['description'];
  //   let postMealObject = {
  //     Id: getid,
  //     Name: getName,
  //     Category: 'Shift',
  //     Description: getdescription,
  //     StartTime: getStartTime,
  //     EndTime: getEndTime,
  //     Type: '1',
  //     createdDate: '2021-05-28T12:02:37.107Z',
  //     calendarDetails: newcalendarDetails,
  //   };
  //   console.log('postmeal');
  //   console.log(JSON.stringify(postMealObject));
  //   console.log();

  //   if (this.isNew) {
  //     this.shiftService
  //       .save(postMealObject)
  //       .pipe(first())
  //       .subscribe({
  //         next: () => {
  //           this.loadItems();
  //           this.toastr.success('Your data has been saved sucessfully.');
  //         },
  //         error: (error) => {},
  //       });
  //   } else {
  //     let finalnewcalendarDetails = [];
  //     console.log('comparing');
  //     console.log(this.previousSelectedWeek);
  //     console.log(newcalendarDetails);
  //     //remove the unchecked meal that was previously checked
  //     for (var i in this.previousSelectedWeek) {
  //       let flag = 0;
  //       let previousSelectedTupId = this.previousSelectedWeek[i]['calendarId'];
  //       for (var j in newcalendarDetails) {
  //         let curSelectedTupId = newcalendarDetails[j]['calendarId'];
  //         if (previousSelectedTupId == curSelectedTupId) {
  //           flag = 1;
  //         }
  //       }
  //       if (flag == 0) {
  //         this.previousSelectedWeek[i]['parentCalendarId'] = -1;
  //         let curnamearr = this.previousSelectedWeek[i]['name'].split('-');

  //         let curtup = this.previousSelectedWeek[i];
  //         curtup['name'] = curnamearr[1];
  //         finalnewcalendarDetails.push(curtup);
  //       }
  //     }
  //     console.log(finalnewcalendarDetails);
  //     // newly added item
  //     for (var i in newcalendarDetails) {
  //       let flag = 0;
  //       let curSelectedTupId = newcalendarDetails[i]['calendarId'];
  //       for (var j in this.previousSelectedWeek) {
  //         let previousSelectedTupId =
  //           this.previousSelectedWeek[j]['calendarId'];
  //         if (previousSelectedTupId == curSelectedTupId) {
  //           flag = 1;
  //           break;
  //         }
  //       }
  //       if (flag == 0) {
  //         newcalendarDetails[i]['parentCalendarId'] = 0;
  //         let curtup = newcalendarDetails[i];
  //         finalnewcalendarDetails.push(curtup);
  //       }
  //     }
  //     postMealObject['calendarDetails'] = finalnewcalendarDetails;
  //     console.log('getid');
  //     console.log(getid);
  //     console.log(postMealObject);
  //     this.shiftService
  //       .update(postMealObject)
  //       .pipe(first())
  //       .subscribe({
  //         next: () => {
  //           this.loadItems();
  //           this.toastr.success('Your data has been saved sucessfully.');
  //         },
  //         error: (error) => {},
  //       });
  //     finalnewcalendarDetails = [];
  //   }
  //   this.mySelectionCalendarException = [];
  //   this.previousSelectedWeek = [];
  // }

  public saveItem(item) {

    let postCalendarobject = {
      Id: 0,
      Name: item.idName,
      Type: '1',
      Category: 'Calendar',
      Description: item.description,
      createdDate: item.createdDate,
      calendarDetails: [],
    };

    let newobj = [];

    if (this.isNew) {
      
      let newobj = this.createNewCalendarDetailsArray();

      postCalendarobject['calendarDetails'] = newobj.slice();

      this.calendarService
        .save(postCalendarobject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });

    } 
    else {

      postCalendarobject.Id = item.id;
      let newobj = [];

      //add new calendar exception
      for (let i = 0; i < this.mySelectionCalendarException.length; i++) {
        let newCalendarExceptionId = this.mySelectionCalendarException[i];

        if (this.previousmySelectionCalendarException
          .includes(newCalendarExceptionId)) 
        {
          continue;
        }

        newobj.push({
          id: item.id,
          name: this.calendarexceptiondict[newCalendarExceptionId],
          calendarid: newCalendarExceptionId,
          parentCalendarId: 0,
        });

      }
      //delete unselected calendar exception that was previously selected
      for (
        let i = 0;
        i < this.previousmySelectionCalendarException.length;
        i++
      ) {
        let newCalendarExceptionId =
          this.previousmySelectionCalendarException[i];
        console.log(newCalendarExceptionId);
        console.log(typeof newCalendarExceptionId);
        console.log(this.previousmySelectionCalendarException);
        if (
          this.mySelectionCalendarException.includes(newCalendarExceptionId)
        ) {
          continue;
        }
        newobj.push({
          id: newCalendarExceptionId,
          name: this.calendarexceptiondict[newCalendarExceptionId],
          calendarid: newCalendarExceptionId,
          parentCalendarId: -1,
        });
      }
      console.log('inside edit final');
      console.log(newobj);

      //update the weeks for calendar by deleting the parentCalenderid:-1 and setting new calendarid;
      for (let i = 0; i < 53; i++) {
        let stringi = (i + 1).toString();
        if (this.resultarrId[i] != this.previousSelectedWeek[i]) {
          newobj.push({
            id: this.previousSelectedWeek[i],
            name: this.resultarr[i].week,
            parentCalendarId: -1,
            calendarId: this.previousSelectedWeek[i],
            sequence: 0,
            Value: stringi,
            priority: 0,
            interval: 0,

            createdDate: '2021-07-22T10:56:29.508Z',
            modifiedDate: '2021-07-22T10:56:29.508Z',
          });

          newobj.push({
            id: 0,
            name: this.resultarr[i].week,
            parentCalendarId: 0,
            calendarId: this.resultarrId[i],
            sequence: 0,
            Value: stringi,
            priority: 0,
            interval: 0,

            createdDate: '2021-07-22T10:56:29.508Z',
            modifiedDate: '2021-07-22T10:56:29.508Z',
          });
        }
      }

      if (newobj.length != 0) {
        postCalendarobject['calendarDetails'] = newobj.slice();
        console.log('updateeee');
        console.log(newobj);
        this.calendarService
          .update(postCalendarobject)
          .pipe(first())
          .subscribe({
            next: () => {
              this.loadItems();
              this.toastr.success('Your data has been saved sucessfully.');
            },
            error: (error) => {},
          });
      }
      console.log('save edit item');
      console.log(item);
      console.log(postCalendarobject);
      this.previousmySelectionCalendarException = [];
      this.mySelectionCalendarException = [];
    }
  }

  createNewCalendarDetailsArray() {

    const newobj = [];
    const newDate = new Date();

    for (let i = 0; i < 53; i++) {
      newobj.push({
        id: 0,
        name: 'Weeks',
        parentCalendarId: 0,
        calendarId: this.resultarrId[i],
        sequence: 0,
        Value: (i + 1).toString(),
        priority: 0,
        interval: 0,

        createdDate: newDate,
        modifiedDate: newDate,
      });
    }
    for (let i = 0; i < this.mySelectionCalendarException.length; i++) {

      newobj.push({
        id: 0,
        name: 'CalendarException',
        parentCalendarId: 0,
        calendarId: this.mySelectionCalendarException[i],
        sequence: 0,
        Value: '',
        priority: 0,
        interval: 0,
        createdDate: newDate,
        modifiedDate: newDate,
      });
    }

    return newobj;
  }

  public isHierarchyOpened = false;
  public treeNodes = [];
  public expandedKeys = [];

  closeProductHierarchy() {
    this.isHierarchyOpened = false;
    this.treeNodes = [];
    this.expandedKeys = [];
    this.mySelection = [];
  }

  public hasChildren = (item: any) => item.items && item.items.length > 0;
  public fetchChildren = (item: any) => of(item.items);

  calendarHierarchyButton(): void {

    if (this.mySelection.length == 0) 
    {
      this.toastr.error('Please click on one of the checkboxes');
    } 
    else {

      this.isHierarchyOpened = true;
      let calendarNumInt = parseInt(this.mySelection[0]);

      let calendarArr = this.calendardict[calendarNumInt][0];
      let calendarChild = calendarArr.child;

      let root = {
        text: calendarArr.name,
        items: [],
        type: 'calendar',
      };

      let calendarroot = [];

      for (let t = 0; t < calendarChild.length; t++) {

        let singleweekarr = calendarChild[t];
        let singleweek = singleweekarr[0];
        let week_x = singleweekarr[1];

        if (week_x == null) {
          let calendarExceptionStr = this.calendarexceptiondict[singleweek];
          let calendarexceptionobj = {
            text: calendarExceptionStr,
            items: [],
            type: 'calendarexception',
          };
          calendarroot.push(Object.create(calendarexceptionobj));
          continue;
        }

        let weekarr = this.weekdict[singleweek][0];
        let weekchild = weekarr.child;
        let weekstr = 'Week ' + week_x + ' (' + weekarr.name + ')';
        let weekobj = {
          text: weekstr,
          items: [],
          type: 'week',
        };

        for (let i = 0; i < weekchild.length; i++) {

          let singleday = weekchild[i];
          let dayarr = this.daydict[singleday][0];
          let daychild = dayarr.child;
          let dayobj = {
            text: `Day ${i+1} (${dayarr.name})`,
            items: [],
            type: 'day',
          };

          for (let j = 0; j < daychild.length; j++) {
            let singleshift = daychild[j];
            let shiftarr = this.shiftdict[singleshift][0];
            let shiftchild = shiftarr.child;
            let shiftStartTime = shiftarr.startTime;
            let shiftEndTime = shiftarr.endTime;

            let shiftobj = {
              text: `${shiftarr.name} (${shiftStartTime} - ${shiftEndTime})`,
              items: [],
              type: 'shift',
            };

            for (let k = 0; k < shiftchild.length; k++) {
              let singlemeal = shiftchild[k];
              let mealarr = this.mealdict[singlemeal][0];
              let mealStartTime = mealarr.startTime;
              let mealEndTime = mealarr.endTime;
           
              shiftobj.items.push({
                text: `${mealarr.name} (${mealStartTime} - ${mealEndTime})`,
                type: 'meal',
              });
            }
            dayobj.items.push(Object.create(shiftobj));
          }

          weekobj.items.push(Object.create(dayobj));

        }

        root.items.push(Object.create(weekobj));
      }

      for (let t = 0; t < calendarroot.length; t++) {
        root.items.push(calendarroot[t]);
      }

      console.log(calendarroot, this.shiftdict, this.weekdict, this.daydict, this.calendardict);

      this.expandedKeys.push('0');
      this.treeNodes.push(root);

      this.expandedKeys = this.expandedKeys.slice();
      this.treeNodes = this.treeNodes.slice();
    }
  }
  // deleteButton(): void {
  //   console.log(this.mySelection);
  //   if (this.mySelection.length == 0) {
  //     this.toastr.error('Please click on one of the checkboxes');
  //   } else {
  //     this.editedRowIndex = parseInt(this.mySelection[0]);
  //     console.log('inside');
  //     console.log(this.mySelection);
  //     console.log(this.editedRowIndex);
  //     console.log('delete ' + this.editedRowIndex);
  //     this.customDialog.confirm().subscribe((res) => {
  //       // Primary (Yes) button is clicked
  //       if (res.primary) {
  //         console.log('delete if');
  //         this.removeItem();
  //       }
  //     });
  //   }
  // }
  public iconClass({ text, type, items }: any) {
    return {
      calendarexception: type == 'calendarexception',
      calendar: type == 'calendar',
      week: type == 'week',
      day: type == 'day',
      shift: type == 'shift',
      meal: type === 'meal',
      'k-icon': true,
    };
  }

  onDeleteClick(event: RemoveEvent): void {
    this.editedRowIndex = event.rowIndex;
    this.customDialog.confirm().subscribe((res) => {
      if (res.primary) {
        this.removeItem(event);
      }
    });
  }

  removeItem(event): void {

    let items = this.gridDataSubject.value;

    this.calendarService
      .delete(event.dataItem.id)
      .pipe(first())
      .subscribe({
        next: (data) => {
          this.gridDataSubject.next(items);

          if (data == -1){
            this.toastr.error('Error');
          } 
          else {
            this.loadItems();
            this.toastr.success('Your data has been removed sucessfully.');
          }
        },
        error: (error) => {},
      });

  }

  callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void {
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }
  pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();

    // Optionally, clear the selection when paging
    // this.mySelection = [];
  }
  public valueChangeDay1(value: any): void {
    this.selectedWeek = [];
    this.selectedWeek.push(value);
  }
}
