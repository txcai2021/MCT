import { Component, OnInit, ViewChild } from '@angular/core';
import {
  DataBindingDirective,
  EditEvent,
  RemoveEvent,
} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable } from 'rxjs';
import { ToastService } from '@dis/services/message/toast.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { CustomMessageService } from '@dis/services/message/custom-message.service';

import { MealService } from '@app/_services';
import { first } from 'rxjs/operators';
import { Meal } from '@app/_models';
import { SelectableSettings } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-meal',
  templateUrl: './meal.component.html',
  styleUrls: ['./meal.component.scss'],
})
export class MealComponent implements OnInit {

  @ViewChild(DataBindingDirective) dataBinding: DataBindingDirective;

  public min: Date = new Date(2000, 2, 10, 2, 30);
  public max: Date = new Date(2002, 2, 10, 22, 15);
  public value: Date = new Date(2000, 2, 10, 10, 0);
  
  public selectableSettings: SelectableSettings;

  public checkboxOnly = true;
  public mode = 'single';
  public drag = false;

  gridDataSubject = new BehaviorSubject<Meal[]>([]);
  gridView = this.gridDataSubject.asObservable();;

  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  idTextFieldDisabled = false;
  editedRowIndex: number;
  isSecondWindowOpened = false;

  public data: any = {
    idName: '',
    startTime: '',
    endTime: '',
  };

  constructor(
    private toastr: ToastService,
    private mealService: MealService,
    private customDialog: CustomDialogService,
    private customMessage: CustomMessageService
  ) {
    this.setSelectableSettings();

    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      startTime: new FormControl(this.data.startTime, Validators.required),
      endTime: new FormControl(this.data.endTime, Validators.required),
    });
  }

  ngOnInit(): void {
    this.loadItems();
  }

  public setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: this.checkboxOnly,
      drag: this.drag,
      mode: 'single',
    };
  }

  loadItems() {
    this.mealService.getAll().subscribe((result) => {
      if (result){
        result = orderBy(result, [{ field: 'id', dir: 'desc' }]);
        this.gridDataSubject.next(result);
      }
    });
  }

  onFilter(inputValue: string): void {
    console.log(inputValue);
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          },
        ],
      },
    }).data;

    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }

  clearData(): void {
    this.formGroup.reset(this.data);
  }

  onAddNewClick(): void {
    this.clearData();
    this.idTextFieldDisabled = false;
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
  }

  editButton(event: EditEvent): void {
    let newData = {
      idName: '',
      startTime: new Date(2002, 2, 10, 22, 15),
      endTime: new Date(2002, 2, 10, 22, 15),
    };
    this.idTextFieldDisabled = true;
    console.log(this.mySelection.length);
    console.log(this.gridView);
    console.log(event.dataItem);

    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } 
    else {

      let selectedindex = this.mySelection[0];
      let countindex = 0;

      for (var row in this.gridView) {

        let curTup = this.gridView[row];
        
        if (curTup['id'] == selectedindex) {

          this.isNew = false;
          let getstarttime = curTup.startTime;
          let startTimeArray = getstarttime.split(':');
          let startTimeHour = startTimeArray[0];
          let startTimeMinute = startTimeArray[1];
          let getendTime = curTup.endTime;
          let endTimeArray = getendTime.split(':');
          let endTimeHour = endTimeArray[0];
          let endTimeMinute = endTimeArray[1];

          newData.idName = curTup.name;
          newData.startTime = new Date(
            2002,
            2,
            10,
            startTimeHour,
            startTimeMinute
          );
          newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);

          this.formGroup.reset(newData);
          this.isWindowOpened = !this.isWindowOpened;
          this.editedRowIndex = countindex;
          break;
        }
        countindex += 1;
      }
    }
  }

  onEditClick(event: EditEvent): void {
    let newData = {
      idName: '',
      startTime: new Date(2002, 2, 10, 22, 15),
      endTime: new Date(2002, 2, 10, 22, 15),
    };
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;

    let getstarttime = event.dataItem.startTime;
    let startTimeArray = getstarttime.split(':');
    let startTimeHour = startTimeArray[0];
    let startTimeMinute = startTimeArray[1];
    let getendTime = event.dataItem.endTime;
    let endTimeArray = getendTime.split(':');
    let endTimeHour = endTimeArray[0];
    let endTimeMinute = endTimeArray[1];

    newData.idName = event.dataItem.name;
    newData.startTime = new Date(2002, 2, 10, startTimeHour, startTimeMinute);
    newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);
    this.formGroup.reset(newData);
    this.editedRowIndex = event.rowIndex;
  }

  closeWindow(): void {
    this.isWindowOpened = false;
  }
  submitWindow(item): void {
    if (item['startTime'] >= item['endTime']) {
      this.isSecondWindowOpened = true;
    } 
    else {
      this.isWindowOpened = false;

      if (!this.isNew) {
        const items = this.gridDataSubject.value;
        item.id = items[this.editedRowIndex].id;
      }
      this.saveItem(item);
    }
  }

  closeWindowWarning() {
    this.isSecondWindowOpened = false;
  }

  twofourHoursformat(time): string {
    var hours = Number(time.match(/^(\d+)/)[1]);
    var minutes = Number(time.match(/:(\d+)/)[1]);
    var AMPM = time.match(/\s(.*)$/)[1];
    if (AMPM == 'PM' && hours < 12) hours = hours + 12;
    if (AMPM == 'AM' && hours == 12) hours = hours - 12;
    var sHours = hours.toString();
    var sMinutes = minutes.toString();
    if (hours < 10) sHours = '0' + sHours;
    if (minutes < 10) sMinutes = '0' + sMinutes;
    return sHours + ':' + sMinutes;
  }

  public saveItem(item): void {

    this.isSecondWindowOpened = true;

    var options = { hour12: false };

    let getName = item['idName'];
    let getStartTime = this.twofourHoursformat(
      item['startTime'].toLocaleTimeString()
    );

    console.log('starttime');
    console.log(getStartTime);

    let getEndTime = this.twofourHoursformat(
      item['endTime'].toLocaleTimeString()
    );

    let getid = item['id'];

    let postMealObject = {
      Id: getid,
      Name: getName,
      Category: 'Meal',
      Description: 'testdesc',
      StartTime: getStartTime,
      EndTime: getEndTime,
    };

    if (this.isNew) {
      this.mealService
        .save(postMealObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    } else {
      console.log('getid');
      console.log(getid);
      this.mealService
        .update(postMealObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    }
  }

  deleteButton(): void {
    console.log(this.mySelection);
    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } else {
      this.editedRowIndex = parseInt(this.mySelection[0]);
      console.log('delete ' + this.editedRowIndex);
      this.customDialog.confirm().subscribe((res) => {
        // Primary (Yes) button is clicked
        if (res.primary) {
          console.log('delete if');
          this.removeItem();
        }
      });
    }
  }

  onDeleteClick(event: RemoveEvent): void {
    this.editedRowIndex = event['dataItem'].id;
    console.log('delete ' + this.editedRowIndex);
    this.customDialog.confirm().subscribe((res) => {
      // Primary (Yes) button is clicked
      if (res.primary) {
        console.log('delete if');
        this.removeItem();
      }
    });
  }

  removeItem(): void {
    let items = this.gridDataSubject.value;
 
    let deletedId = this.editedRowIndex;
    let getdeleteid: any = 0;
    for (var row in items) {
      let curTup = items[row];
      console.log(curTup);
      if (curTup['id'] == deletedId) {
        getdeleteid = curTup['id'];
        break;
      }
    }
    items.splice(this.editedRowIndex, 1);

    // array isnt updating
    // Retrieve backend data to update
    const temp = [...items];
    // noinspection JSUnusedAssignment
    items = [];
    items = [...temp];

    // success should be in resolve of subscribe method
    this.mealService
      .delete(String(getdeleteid))
      .pipe(first())
      .subscribe({
        next: (data) => {
          if (data == -1) {
            this.toastr.error('Meal is used by Shift');
          } else {
            this.loadItems();
            this.toastr.success('Your data has been removed sucessfully.');
          }
        },
        error: (error) => {},
      });
  }

  callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void {
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }
}
