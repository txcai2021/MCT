import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CalendarExceptionComponent } from './calendar-exception.component';

describe('CalendarExceptionComponent', () => {
  let component: CalendarExceptionComponent;
  let fixture: ComponentFixture<CalendarExceptionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CalendarExceptionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CalendarExceptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
