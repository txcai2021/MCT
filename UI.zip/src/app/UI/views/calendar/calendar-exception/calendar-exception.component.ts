import { Component, OnInit, ViewChild } from '@angular/core';

import {
  DataBindingDirective,
  EditEvent,
  RemoveEvent,
} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable } from 'rxjs';
import { ToastService } from '@dis/services/message/toast.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { first } from 'rxjs/operators';
import { calendarExceptionService } from '@app/_services';
import { CalendarException } from '@app/_models';
import { CustomMessageService } from '@dis/services/message/custom-message.service';
import { SelectableSettings } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-calendar-exception',
  templateUrl: './calendar-exception.component.html',
  styleUrls: ['./calendar-exception.component.scss'],
})
export class CalendarExceptionComponent implements OnInit {
  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;
  public min: Date = new Date(2000, 2, 10, 2, 30);
  public max: Date = new Date(2002, 2, 10, 22, 15);
  public value: Date = new Date(2000, 2, 10, 10, 0);
  public selectableSettings: SelectableSettings;

  public checkboxOnly = true;
  public mode = 'single';
  public drag = false;

  gridDataSubject = new BehaviorSubject<CalendarException[]>([]);
  gridView = this.gridDataSubject.asObservable();

  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  idTextFieldDisabled = false;
  editedRowIndex: number;
  isSecondWindowOpened = false;
  public data: any = {
    idName: '',
    startDate: '',
    description: '',
  };
  constructor(
    private toastr: ToastService,
    private calendarExceptionService: calendarExceptionService,
    private customDialog: CustomDialogService,
    private customMessage: CustomMessageService
  ) {

    this.setSelectableSettings();

    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
      startDate: new FormControl(this.data.startDate),
    });
  }

  ngOnInit(): void {
    this.loadItems();
  }

  public setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: this.checkboxOnly,

      drag: this.drag,
      mode: 'single',
    };
  }
  
  loadItems() {
    this.initializeCalendarExceptionGridView();
  }

  initializeCalendarExceptionGridView(): void {
    this.calendarExceptionService.getAll().subscribe((result) => {

      if (result){

        result = orderBy(result as any, [
          { field: 'id', dir: 'desc' },
        ]);

        let newdatearr = [];

        for (var i in result) {
          let curdatearr = result[i]['startDate'].split('T');
          let newdate = curdatearr[0].split('-');
          let newyear = parseInt(newdate[0]);
          let newmonth = parseInt(newdate[1]);
          let newday = parseInt(newdate[2]);
          
          newdatearr.push(new Date(newyear, newmonth - 1, newday));
        }

        for (var i in newdatearr) {
          result[i]['startDate'] = newdatearr[i];
        }

        this.gridDataSubject.next(result);
      }

    });
  }

  onFilter(inputValue: string): void {
    console.log(inputValue);
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          },
        ],
      },
    }).data;

    console.log(items);
    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }

  clearData(): void {
    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
      startDate: new FormControl(this.data.startDate),
    });
  }

  onAddNewClick(): void {
    this.clearData();
    this.idTextFieldDisabled = false;
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
  }

  editButton(event: EditEvent): void {
    let newData = {
      idName: '',
      description: '',
      startDate: new Date(2002, 2, 10, 22, 15),
    };
    this.idTextFieldDisabled = true;
    console.log(this.mySelection.length);
    console.log(this.gridView);
    console.log(event.dataItem);

    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } else {
      let selectedindex = this.mySelection[0];
      console.log('editbutton');
      console.log(this.mySelection);
      console.log(this.gridView);
      console.log('gridview');
      let countindex = 0;
      for (var row in this.gridView) {
        console.log(this.gridView[row]);
        let curTup = this.gridView[row];
        if (curTup['id'] == selectedindex) {
          console.log('selected tuple');
          console.log(curTup);
          newData.description = curTup.description;
          newData.startDate = curTup.startDate;
          let curdatearr = curTup.startDate.split('T');
          console.log(curdatearr);
          let newdate = curdatearr[0].split('-');
          let newyear = newdate[0];
          let newmonth = newdate[1];
          let newday = newdate[2];
          console.log(newdate);
          newData.startDate = new Date(curdatearr[0]);

          newData.idName = curTup.name;
          // newData.startTime = new Date(
          //   2002,
          //   2,
          //   10,
          //   startTimeHour,
          //   startTimeMinute
          // );
          // newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);

          this.formGroup.reset(newData);
          this.isWindowOpened = !this.isWindowOpened;
          this.editedRowIndex = countindex;
          break;
        }
        countindex += 1;
      }
    }
  }

  onEditClick(event: EditEvent): void {

    this.idTextFieldDisabled = true;

    console.log(event);
    let newData = {
      idName: '',
      description: '',
      startDate: new Date(2002, 2, 10, 22, 15),
    };
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;

    let startdate = event.dataItem.startDate;
   
    let year = parseInt(startdate.getFullYear());
    let month = parseInt(startdate.getMonth());
    let day = parseInt(startdate.getDate());

    newData.idName = event.dataItem.name;
    newData.description = event.dataItem.description;
    newData.startDate = new Date(year, month, day, 0, 0);
    this.formGroup.reset(newData);
    this.editedRowIndex = event.rowIndex;
  }

  closeWindow(): void {
    this.isWindowOpened = false;
  }
  submitWindow(item): void {
    this.isWindowOpened = false;

    if (!this.isNew) {
      console.log(item);
      const items = this.gridDataSubject.value;
      console.log('inside');
      console.log(items);
      console.log('editedrowindex ' + this.editedRowIndex);
      item.id = items[this.editedRowIndex]['id'];
    }
    console.log('submitwindowfunction');
    console.log(item);
    this.saveItem(item);
  }

  closeWindowWarning() {
    this.isSecondWindowOpened = false;
  }
  twofourHoursformat(time): string {
    var hours = Number(time.match(/^(\d+)/)[1]);
    var minutes = Number(time.match(/:(\d+)/)[1]);
    var AMPM = time.match(/\s(.*)$/)[1];
    if (AMPM == 'PM' && hours < 12) hours = hours + 12;
    if (AMPM == 'AM' && hours == 12) hours = hours - 12;
    var sHours = hours.toString();
    var sMinutes = minutes.toString();
    if (hours < 10) sHours = '0' + sHours;
    if (minutes < 10) sMinutes = '0' + sMinutes;
    return sHours + ':' + sMinutes;
  }

  public saveItem(item): void {
    console.log('saveitem');
    console.log(item);

    var options = { hour12: false };

    let getName = item['idName'];
    let getdescription = item['description'];
    let getdate = item['startDate'];
    let getid = item['id'];
    let startYear = getdate.getFullYear();
    let startMonth = getdate.getMonth() + 1;
    let startday = getdate.getDate();
    let startdatestring =
      startYear + '-' + startMonth + '-' + startday + 'T12:02:37.107Z';
    console.log(getdate.getDate());
    console.log('before parse');
    console.log(startdatestring);
    let intstartYear = parseInt(startYear);
    let intstartmonth = parseInt(startMonth);
    let intstartday = parseInt(startday);
    console.log(
      intstartYear + 'month: ' + intstartmonth + 'day ' + intstartday
    );
    let dateobject = new Date(intstartYear, intstartmonth - 1, intstartday + 1);
    console.log(dateobject);
    console.log('before prepare');
    let postCalendarExceptionObject = {
      Id: getid,
      Name: getName,
      Type: '1',
      Description: getdescription,
      Category: 'CalendarException',
      StartDate: dateobject,
    };
    console.log('post calendar exception');
    console.log(postCalendarExceptionObject);

    console.log(postCalendarExceptionObject);
    console.log();

    if (this.isNew) {
      postCalendarExceptionObject['Id'] = 0;
      console.log(JSON.stringify(postCalendarExceptionObject));

      this.calendarExceptionService
        .save(postCalendarExceptionObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    } else {
      console.log('getid');
      console.log(getid);
      this.calendarExceptionService
        .update(postCalendarExceptionObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    }
  }

  deleteButton(): void {
    console.log(this.mySelection);
    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } else {
      this.editedRowIndex = parseInt(this.mySelection[0]);
      console.log('delete ' + this.editedRowIndex);
      this.customDialog.confirm().subscribe((res) => {
        // Primary (Yes) button is clicked
        if (res.primary) {
          console.log('delete if');
          this.removeItem();
        }
      });
    }
  }

  onDeleteClick(event: RemoveEvent): void {
    this.editedRowIndex = event.rowIndex;
    console.log('delete ' + this.editedRowIndex);
    this.customDialog.confirm().subscribe((res) => {
      // Primary (Yes) button is clicked
      if (res.primary) {
        console.log('delete if');
        this.removeItem();
      }
    });
  }

  removeItem(): void {
    // do you processing and close window
    let items = this.gridDataSubject.value;

    this.calendarExceptionService
      .delete(items[this.editedRowIndex].id)
      .pipe(first())
      .subscribe({
        next: (data) => {
          this.gridDataSubject.next(items);
          console.log('delete item');
          console.log(data);
          if (data == -1) {
            this.toastr.error('Calendar Exception is used by Calendar');
          } else {
            this.loadItems();
            this.toastr.success('Your data has been removed sucessfully.');
          }
        },
        error: (error) => {},
      });
    items.splice(this.editedRowIndex, 1);
    const temp = [...items];
    // noinspection JSUnusedAssignment
    items = [];
    items = [...temp];
  }

  callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void {
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }
}
