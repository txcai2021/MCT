import { Component, OnInit, ViewChild } from '@angular/core';

import {
  DataBindingDirective,
  EditEvent,
  RemoveEvent,
  PageChangeEvent,
} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { of, BehaviorSubject, Observable } from 'rxjs';
import { ToastService } from '@dis/services/message/toast.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { first, map } from 'rxjs/operators';
import {
  DayService,
  weekService,
  ShiftService,
  MealService,
} from '@app/_services';
import { Week, Day } from '@app/_models';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { data } from '@dis/services/mocks/sampleDataForGrid';

interface Item {
  text: string;
  value: number;
}
@Component({
  selector: 'app-week',
  templateUrl: './week.component.html',
  styleUrls: ['./week.component.scss'],
})
export class WeekComponent implements OnInit {

  @ViewChild(DataBindingDirective) dataBinding: DataBindingDirective;

  public min: Date = new Date(2000, 2, 10, 2, 30);
  public max: Date = new Date(2002, 2, 10, 22, 15);
  public value: Date = new Date(2000, 2, 10, 10, 0);

  public selectableSettings: SelectableSettings;

  public checkboxOnly = true;
  public mode = 'single';
  public drag = false;

  gridDataSubject = new BehaviorSubject<Week[]>([]);
  gridView = this.gridDataSubject.asObservable();

  gridDataSubjectDay = new BehaviorSubject<Day[]>([]);
  gridViewDay = this.gridDataSubjectDay.asObservable();

  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  editedRowIndex: number;
  isSecondWindowOpened = false;

  mySelectionDay: any[] = [];
  pageSize = 10;
  skip = 0;

  public data: any = {
    idName: '',
    description: '',
    startTime: '',
    endTime: '',
  };

  public defaultItem: { text: string; value: number } = {
    text: 'ddd',
    value: null,
  };

  public hasChildren = (item: any) => item.items && item.items.length > 0;
  public fetchChildren = (item: any) => of(item.items);

  public availableDays: Day[] = [];
  public days: {
    [day: string]: {
      name: string;
      selectedDay: any;
      previousSelectedDay: any;
    }
  } = {};
  public _days = () => Object.keys(this.days);

  public mealdict: any = {};
  public shiftdict: any = {};
  public daydict: any = {};
  public weekdict: any = {};

  constructor (
    private toastr: ToastService,
    private weekService: weekService,
    private dayService: DayService,
    private mealService: MealService,
    private shiftService: ShiftService,
    private customDialog: CustomDialogService
  ) {

    this.setSelectableSettings();

    for(let i=1;i<=7;i++){
      this.days[`day${i}`] = {
        name: `Day ${i}`,
        selectedDay: null,
        previousSelectedDay: null
      };
    }

    const newDaysFormControls = Object.keys(this.days).reduce((prev, cur)=>({
      ...prev, [cur]: new FormControl()
    }), {});

    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName, 
        Validators.compose([
          Validators.required, 
          Validators.minLength(1)
        ])
      ),
      description: new FormControl(this.data.description),
      ...newDaysFormControls
    }); 

  }

  initializeWeekGridView(): Observable<Week[]> {
    return this.weekService.getAll().pipe(
      map(res => {
        const result = res ? orderBy(res, [{ field: 'id', dir: 'desc' }]) : [];
        this.gridDataSubject.next(result);
        return result;
      }
    ));
  }

  initializeWeekDictionary(weeks: Week[]): Week[] {

    if(weeks){

      for (var i = 0; i < weeks.length; i++) {

        let $id = weeks[i]['id'];
        let obj = {
          name: weeks[i]['name'],
          child: []
        };
   
        for (let j = 0; j < weeks[i]['calendarChilds'].length; j++) {
          obj['child'].push(weeks[i]['calendarChilds'][j]['calendarId']);
        }
        this.weekdict[$id] = [obj];
      }
    }

    return weeks;

  }

  initializeDayGridView(): Observable<Day[]> {
    return this.dayService.getAll().pipe(
      map(res => {
        const result = res ? orderBy(res, [{ field: 'id', dir: 'desc' }]) : [];
        this.gridDataSubjectDay.next(result);
        return result;
    }));
  }

  initializeDayDictionary(days: Day[]): Day[] {

    if(days){
      for (var i = 0; i < days.length; i++) {
        let $id = days[i]['id'];
        let obj = {
          name: days[i]['name'],
          startTime: days[i]['startTime'],
          endTime: days[i]['endTime'],
          child: []
        };
     
        for (let j = 0; j < days[i]['calendarChilds'].length; j++) {
          obj['child'].push(days[i]['calendarChilds'][j]['calendarId']);
        }
        this.daydict[$id] = [obj];
      }
    }

    return days;

  }

  initializeShiftDictionary(): void {
    this.shiftService.getAll().subscribe((result) => {
      for (var i = 0; i < result.length; i++) {
        let $id = result[i]['id'];
        let obj = {
          name: result[i]['name'],
          startTime: result[i]['startTime'],
          endTime: result[i]['endTime'],
          child: []
        };

        for (let j = 0; j < result[i]['calendarChilds'].length; j++) {
          obj['child'].push(result[i]['calendarChilds'][j]['calendarId']);
        }
        this.shiftdict[$id] = [obj];
      }
    });
  }

  initializeMealDictionary(): void {
    this.mealService.getAll().subscribe((result) => {
      for (var i = 0; i < result.length; i++) {
        let $id = result[i]['id'];
        let obj = {
          name: result[i]['name'],
          startTime: result[i]['startTime'],
          endTime: result[i]['endTime'],
          child: []
        };

        for (let j = 0; j < result[i]['calendarChilds'].length; j++) {
          obj['child'].push(result[i]['calendarChilds'][j]['calendarId']);
        }
        this.mealdict[$id] = [obj];
      }
    });
  }  

  ngOnInit(): void {

    this.loadItems();

    this.initializeShiftDictionary();
    this.initializeMealDictionary();

    this.initializeDayGridView()
      .pipe(map(res=>this.initializeDayDictionary(res)))
      .subscribe(result => {
        this.availableDays = result;
      });
  }
  
  public setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: this.checkboxOnly,
      drag: this.drag,
      mode: 'single',
    };
  }

  loadItems() {
    this.initializeWeekGridView()
      .pipe(map(res=>this.initializeWeekDictionary(res)))
      .subscribe();
  }

  closeWindowWarning() {
    this.isSecondWindowOpened = false;
  }

  onFilter(inputValue: string): void {
    console.log(inputValue);
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          },
        ],
      },
    }).data;

    this.callHttpRequest(items);
    this.dataBinding.skip = 0;

  }

  clearData(): void {
    this.formGroup.reset();
    this.formGroup.patchValue(this.data);
  }

  onAddNewClick(): void {
    this.clearData();
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
  }


  onEditClick(event: EditEvent): void {

    const initializeDays = Object.keys(this.days)
      .reduce((prev, cur) => ({ ...prev, [cur]: {} }), {});

    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;
   
    let calendarChilds = event['dataItem']['calendarChilds'];

    calendarChilds = calendarChilds.map(day => {
      // This assumes that the existing name will always look like this, E.g. XXXX-XXXX
      const nameToUseInstead = day.name?.split('-')[1] ?? day.name;
      return { ...day, name: nameToUseInstead };
    });

    this.getAndSetSelectedDropdownValuesBasedOnExistingCalendarChilds(calendarChilds);

    let newData = {
      idName: event.dataItem.name,
      startTime: new Date(event.dataItem.startTime),
      endTime: new Date(event.dataItem.endTime),
      description: event.dataItem.description,
      ...initializeDays
    };

    Object.keys(this.days).forEach(day => {
      newData[day] = this.days[day].selectedDay;
    })

    this.formGroup.reset(newData);
    this.editedRowIndex = event.rowIndex;
  }

  getAndSetSelectedDropdownValuesBasedOnExistingCalendarChilds(calendarChilds){

    const dayNames = Object.keys(this.days);

    for (let i = 0; i < calendarChilds.length; i++) {

      const indexOfWeekChildInDayNames = 
        dayNames.findIndex(day => this.days[day].name === calendarChilds[i].value);

      if(indexOfWeekChildInDayNames<=-1) continue;

      const positionOfDay = 
        this.availableDays.findIndex(day => day.id === calendarChilds[i].calendarId);

      if(positionOfDay<=-1) continue;

      const dayNumber = dayNames[indexOfWeekChildInDayNames];
      let nameOfDay: any = this.availableDays
        .find(day => day.id === calendarChilds[i].calendarId) ?? {};

      if(nameOfDay.hasOwnProperty("name")) nameOfDay = { name: nameOfDay.name };
      
      this.days[dayNumber].selectedDay = { ...calendarChilds[i], ...nameOfDay };
      this.days[dayNumber].previousSelectedDay = { ...calendarChilds[i], ...nameOfDay };

    }
  } 

  closeWindow(): void {
    this.mySelectionDay = [];
    this.isWindowOpened = false;
  }

  submitWindow(item): void {

    if (item['startTime'] >= item['endTime']) {
      console.log('submit button');
      this.isSecondWindowOpened = true;
    } 
    else {
      this.isWindowOpened = false;

      if (!this.isNew) {
        const items = this.gridDataSubject.value;
        item.id = items[this.editedRowIndex].id;
      }
 
      this.saveItem(item);
    }
  }

  public saveItem(item) {

    let calendarDetailObjects = Object.keys(this.days).reduce((prev, day) => {

      const dayName = this.days[day].name;

      const selectedDay = this.days[day].selectedDay;
      const previousSelectedDay = this.days[day].previousSelectedDay;

      // This Condition ensures that unchanged values are not added for PUT Requests
      if(selectedDay?.id === previousSelectedDay?.id) return prev;

      const calendarObject = this.createCalendarDetailObject({
        id: 0,
        name: selectedDay.name,
        calendarId: selectedDay.id,
        parentCalendarId: 0,
        Value: dayName
      });

      return [ ...prev, calendarObject ];
      
    }, []);

    let postWeekobject = {
      Id: item.id,
      Name: item.idName,
      Type: '1',
      Category: 'Week',
      Description: item.description,
      calendarDetails: calendarDetailObjects,
    };

    if (this.isNew) {
      this.weekService
        .save(postWeekobject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    } 
    else {

      const calendarObjectsToRemoveIfAny = this.getPreviousChangedDaysToRemoveForPutRequest();

      postWeekobject.calendarDetails = [ ...calendarObjectsToRemoveIfAny, ...postWeekobject.calendarDetails ];

      this.weekService
        .update(postWeekobject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    }
  }

  getPreviousChangedDaysToRemoveForPutRequest() {
    return Object.values(this.days)
    .filter(day => day.selectedDay.id !== day.previousSelectedDay.id)
    .map(day => this.createCalendarDetailObject({
      id: day.previousSelectedDay.id,
      name: day.previousSelectedDay.name,
      parentCalendarId: -1,
      calendarId: day.previousSelectedDay.calendarId,
      Value: day.name
    }));
  }

  createCalendarDetailObject(
    data: {
      id: number;
      name: string;
      parentCalendarId: number;
      calendarId: number;
      Value: string;
      sequence?: number;
      priority?: number;
      interval?: number;
    }
  ) {
    return {
      sequence: 0,
      priority: 0,
      interval: 0,
      ...data
    }
  }

  public isHierarchyOpened = false;
  public treeNodes = [];
  public expandedKeys = [];

  closeProductHierarchy() {
    this.isHierarchyOpened = false;
    this.treeNodes = [];
    this.expandedKeys = [];
    this.mySelection = [];
  }

  deleteButton(): void {

    if (this.mySelection.length === 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } 
    else {

      this.isHierarchyOpened = true;
      let weekNumInt = parseInt(this.mySelection[0]);
      let weekarr = this.weekdict[weekNumInt][0];
      let weekchild = weekarr.child;
      let root = {
        text: weekarr.name,
        items: [],
        type: 'week',
      };

      for (let i = 0; i < weekchild.length; i++) {

        let singleday = weekchild[i];
        let dayarr = this.daydict[singleday][0];
        let daychild = dayarr.child;
        let daystr = 'Day ' + (i + 1) + ' (' + dayarr.name + ')';
        let dayobj = {
          text: daystr,
          items: [],
          type: 'day',
        };
      
        for (let j = 0; j < daychild.length; j++) {

          let singleshift = daychild[j];
 
          let shiftarr = this.shiftdict[singleshift][0];
          let shiftchild = shiftarr.child;
          let shiftStartTime = shiftarr.startTime;
          let shiftEndTime = shiftarr.endTime;
          let shifttext =
            shiftarr.name + ' (' + shiftStartTime + ' - ' + shiftEndTime + ')';
          let shiftobj = {
            text: shifttext,
            items: [],
            type: 'shift',
          };

          for (let k = 0; k < shiftchild.length; k++) {
            let singlemeal = shiftchild[k];
            let mealarr = this.mealdict[singlemeal][0];
            let mealStartTime = mealarr.startTime;
            let mealEndTime = mealarr.endTime;
            let mealtext =
              mealarr.name + ' (' + mealStartTime + ' - ' + mealEndTime + ')';
            shiftobj.items.push({
              text: mealtext,
              type: 'meal',
            });

          }
          dayobj.items.push(Object.create(shiftobj));
        }
        root.items.push(Object.create(dayobj));
      }

      this.expandedKeys.push('0');

      this.treeNodes.push(root);
      this.expandedKeys = this.expandedKeys.slice();
      this.treeNodes = this.treeNodes.slice();

    }
  }

  onDeleteClick(event: RemoveEvent): void {
    this.editedRowIndex = event.rowIndex;
    this.customDialog.confirm().subscribe((res) => {
      // Primary (Yes) button is clicked
      if (res.primary) {
        console.log('delete if');
        this.removeItem();
      }
    });
  }

  removeItem(): void {

    let items = this.gridDataSubject.value;

    this.weekService
      .delete(items[this.editedRowIndex].id)
      .pipe(first())
      .subscribe({
        next: (data) => {

          if (data === -1) {
            this.toastr.error('Week is used by Calendar');
            return;
          } 

          this.loadItems();
          this.toastr.success('Your data has been removed sucessfully.');
          
        },
        error: (error) => {},
      });
  }

  public iconClass({ text, type, items }: any): any {
    console.log('iconclass');
    console.log(type);
    return {
      week: type === 'week',
      day: type === 'day',
      shift: type === 'shift',
      meal: type === 'meal',
      'k-icon': true,
    };
  }

  callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void {
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }
  pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }

  public dropdownValueChange(dayToChange, value) {
    if(!this.days[dayToChange]){
      this.toastr.error(`Variable ${dayToChange} does not exist`);
      return;
    }
    this.days[dayToChange].selectedDay = value;
  }
}
