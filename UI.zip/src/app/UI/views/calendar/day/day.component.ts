import { Component, OnInit, ViewChild } from '@angular/core';

import {
  DataBindingDirective,
  EditEvent,
  RemoveEvent,
  PageChangeEvent,
} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable } from 'rxjs';
import { ToastService } from '@dis/services/message/toast.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { first } from 'rxjs/operators';
import { ShiftService, DayService } from '@app/_services';
import { Shift, Day } from '@app/_models';
import { SelectableSettings } from '@progress/kendo-angular-grid';

import { formatDate } from '@telerik/kendo-intl';

@Component({
  selector: 'app-day',
  templateUrl: './day.component.html',
  styleUrls: ['./day.component.scss'],
})
export class DayComponent implements OnInit {
  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;
  public min: Date = new Date(2000, 2, 10, 2, 30);
  public max: Date = new Date(2002, 2, 10, 22, 15);
  public value: Date = new Date(2000, 2, 10, 10, 0);
  public idTextFieldDisabled = true;
  public selectableSettings: SelectableSettings;

  public checkboxOnly = true;
  public mode = 'single';
  public drag = false;

  gridDataSubject = new BehaviorSubject<Day[]>([]);
  gridView = this.gridDataSubject.asObservable();

  gridDataShiftSubject = new BehaviorSubject<Shift[]>([]);
  gridViewShift = this.gridDataShiftSubject.asObservable();

  previousSelectedShift = [];
  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  editedRowIndex: number;
  isSecondWindowOpened = false;

  mySelectionShift: any[] = [];
  pageSize = 10;
  skip = 0;

  public data: any = {
    idName: '',
    description: '',
    startTime: '',
    endTime: '',
  };
  constructor(
    private toastr: ToastService,
    private shiftService: ShiftService,
    private dayService: DayService,
    private customDialog: CustomDialogService
  ) {

    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
    });
    
  }

  ngOnInit(): void {
    this.loadItems();
    this.initializeShiftGridView();
  }
  public setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: this.checkboxOnly,
      drag: this.drag,
      mode: 'single',
    };
  }

  loadItems() {
    this.setSelectableSettings();
    this.initializeDayGridView();
  }

  initializeDayGridView(): void {
    this.dayService.getAll().subscribe((result) => {
      if (result){
        result = orderBy(result, [{ field: 'id', dir: 'desc' }]);

        this.gridDataSubject.next(result);
      }
    });
  }

  initializeShiftGridView(): void {
    this.shiftService.getAll().subscribe((result) => {
      if (result){
        result = orderBy(result, [{ field: 'id', dir: 'desc' }]);

        this.gridDataShiftSubject.next(result);
      }
    });
  }

  closeWindowWarning() {
    this.isSecondWindowOpened = false;
  }

  onFilter(inputValue: string): void {
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          },
        ],
      },
    }).data;

    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }

  clearData(): void {
    this.formGroup.reset(this.data);
    this.previousSelectedShift = [];
  }

  onAddNewClick(): void {
    this.idTextFieldDisabled = false;
    this.clearData();
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
    this.previousSelectedShift = [];
  }

  editButton(event: EditEvent): void {
    this.idTextFieldDisabled = true;
    let newData = {
      idName: '',
      startTime: new Date(2002, 2, 10, 22, 15),
      endTime: new Date(2002, 2, 10, 22, 15),
      description: '',
    };

    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } 
    else {

      let selectedindex = this.mySelection[this.mySelection.length - 1];
      let countindex = 0;

      for (var row in this.gridView) {
        let curTup = this.gridView[row];
        if (curTup['id'] == selectedindex) {
          let selectedchildarr = curTup['calendarChilds'];

          for (var index in selectedchildarr) {
            this.previousSelectedShift.push(selectedchildarr[index]);
            this.mySelectionShift.push(selectedchildarr[index]['calendarId']);
          }

          let getstarttime = curTup.startTime;
          let startTimeArray = getstarttime.split(':');
          let startTimeHour = startTimeArray[0];
          let startTimeMinute = startTimeArray[1];
          let getendTime = curTup.endTime;
          let endTimeArray = getendTime.split(':');
          let endTimeHour = endTimeArray[0];
          let endTimeMinute = endTimeArray[1];
          newData.idName = curTup.name;
          newData.startTime = new Date(
            2002,
            2,
            10,
            startTimeHour,
            startTimeMinute
          );
          newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);
          newData.description = curTup.description;

          this.formGroup.reset(newData);
          this.editedRowIndex = countindex;
          this.isWindowOpened = !this.isWindowOpened;
          this.isNew = false;
        }
        countindex += 1;
      }
    }
  }

  onEditClick(event: EditEvent): void {

    let selectedchildarr = event['dataItem']['calendarChilds'];
 
    for (var index in selectedchildarr) {
      this.previousSelectedShift.push(selectedchildarr[index]);
      this.mySelectionShift.push(selectedchildarr[index].calendarId);
    }

    this.idTextFieldDisabled = true;

    let newData = {
      idName: '',
      startTime: new Date(2002, 2, 10, 22, 15),
      endTime: new Date(2002, 2, 10, 22, 15),
      description: '',
    };
  
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;

    let getstarttime = event.dataItem.startTime;
    let startTimeArray = getstarttime.split(':');
    let startTimeHour = startTimeArray[0];
    let startTimeMinute = startTimeArray[1];
    let getendTime = event.dataItem.endTime;
    let endTimeArray = getendTime.split(':');
    let endTimeHour = endTimeArray[0];
    let endTimeMinute = endTimeArray[1];

    newData.idName = event.dataItem.name;
    newData.startTime = new Date(2002, 2, 10, startTimeHour, startTimeMinute);
    newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);
    newData.description = event.dataItem.description;

    this.formGroup.reset(newData);
    this.editedRowIndex = event.rowIndex;

  }

  closeWindow(): void {
    this.mySelectionShift = [];
    this.isWindowOpened = false;
  }
  submitWindow(item): void {
    if (item['startTime'] >= item['endTime']) {
      this.isSecondWindowOpened = true;
    } 
    else {
      this.isWindowOpened = false;
      if (!this.isNew) {
        const items = this.gridDataSubject.value;
        item.id = items[this.editedRowIndex].id;
      }
      this.saveItem(item);
    }
  }

  twofourHoursformat(time): string {
    var hours = Number(time.match(/^(\d+)/)[1]);
    var minutes = Number(time.match(/:(\d+)/)[1]);
    var AMPM = time.match(/\s(.*)$/)[1];
    if (AMPM == 'PM' && hours < 12) hours = hours + 12;
    if (AMPM == 'AM' && hours == 12) hours = hours - 12;
    var sHours = hours.toString();
    var sMinutes = minutes.toString();
    if (hours < 10) sHours = '0' + sHours;
    if (minutes < 10) sMinutes = '0' + sMinutes;
    return sHours + ':' + sMinutes;
  }

  public saveItem(item): void {

    let newcalendarDetails = this.getSelectedShiftDetails();

    let postDayObject = this.createPostShiftObject({
      name: item['idName'],
      id: item['id'],
      description: item['description'],
      calendarDetails: newcalendarDetails
    });

    if (this.isNew) {
      this.shiftService
        .save(postDayObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    } 
    else {

      let uncheckedShiftsThatWerePreviouslyChecked = 
        this.getUncheckedShiftsThatWerePreviouslyChecked(newcalendarDetails);

      postDayObject['calendarDetails'] = [
        ...uncheckedShiftsThatWerePreviouslyChecked, 
        ...newcalendarDetails
      ];

      this.dayService
        .update(postDayObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been saved sucessfully.');
          },
          error: (error) => {},
        });
    }

    this.mySelectionShift = [];
    this.previousSelectedShift = [];

  }

  getSelectedShiftDetails() {
    return this.gridDataShiftSubject.value
      .filter(shift => this.mySelectionShift?.includes(shift.id))
      .map(shift => ({ ...shift, calendarId: shift.id }));  
  }

  createPostShiftObject(
    data: {
      id: number;
      name: string;
      description: string;
      calendarDetails: any;
    }
  ) {
    return {
      Id: data.id,
      Name: data.name,
      Category: 'Day',
      Description: data.description,
      Type: '1',
      createdDate: formatDate(new Date(),'s'),
      calendarDetails: data.calendarDetails
    }
  }

  getUncheckedShiftsThatWerePreviouslyChecked(currentlySelectedShifts) {

    let currentlySelectedIds = currentlySelectedShifts.map(selected => selected.calendarId);

    let previouslyCheckedUncheckedShifts = this.previousSelectedShift
      .filter(
        previouslySelectedShift => 
          !currentlySelectedIds.includes(previouslySelectedShift.calendarId)
      );

    return previouslyCheckedUncheckedShifts.map(shift => ({ 
        ...shift ,
        parentCalendarId: -1,
        name: shift.name?.split('-')[1] ?? ''
      })
    );
  }

  deleteButton(): void {
    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } else {
      this.editedRowIndex = parseInt(this.mySelection[0]);

      this.customDialog.confirm().subscribe((res) => {
        // Primary (Yes) button is clicked
        if (res.primary) {
          console.log('delete if');
          this.removeItem();
        }
      });
    }
  }

  onDeleteClick(event: RemoveEvent): void {
    this.editedRowIndex = event['dataItem'].id;
    this.customDialog.confirm().subscribe((res) => {
      // Primary (Yes) button is clicked
      if (res.primary) {
        this.removeItem();
      }
    });
  }

  removeItem(): void {
    // do you processing and close window
    let items = this.gridDataSubject.value;
    let deletedId = this.editedRowIndex;
    let getdeleteid: any = 0;

    for (var row in items) {
      let curTup = items[row];
      if (curTup['id'] == deletedId) {
        getdeleteid = curTup['id'];
        break;
      }
    }

    items.splice(this.editedRowIndex, 1);

    // array isnt updating
    // Retrieve backend data to update
    const temp = [...items];
    // noinspection JSUnusedAssignment
    items = [];
    items = [...temp];
    console.log('after');
    console.log(items);
    // success should be in resolve of subscribe method
    this.shiftService
      .delete(String(getdeleteid))
      .pipe(first())
      .subscribe({
        next: (data) => {
          if (data == -1) {
            this.toastr.error('Day is used by Week');
          } else {
            this.loadItems();
            this.toastr.success('Your data has been removed sucessfully.');
          }
        },
        error: (error) => {},
      });
    this.mySelectionShift = [];
    this.isWindowOpened = false;
    this.mySelection = [];
  }

  callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void {
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }
  pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }
}
