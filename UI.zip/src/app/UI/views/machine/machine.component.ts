import { Component, OnInit, ViewChild } from '@angular/core';
import {
  DataBindingDirective,
  EditEvent,
  RemoveEvent,
} from '@progress/kendo-angular-grid';
import { orderBy, process } from '@progress/kendo-data-query';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Observable } from 'rxjs';
import { ToastService } from '@dis/services/message/toast.service';
import { CustomDialogService } from '@dis/services/message/custom-dialog.service';
import { CustomMessageService } from '@dis/services/message/custom-message.service';

import {
  LocationService,
  calendarService,
  MachineService,
} from '@app/_services';
import { first } from 'rxjs/operators';
import { Machine } from '@app/_models';
import { SelectableSettings } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-machine',
  templateUrl: './machine.component.html',
  styleUrls: ['./machine.component.scss'],
})
export class MachineComponent implements OnInit {
  @ViewChild(DataBindingDirective)
  dataBinding: DataBindingDirective;
  public min: Date = new Date(2000, 2, 10, 2, 30);
  public max: Date = new Date(2002, 2, 10, 22, 15);
  public value: Date = new Date(2000, 2, 10, 10, 0);
  public selectableSettings: SelectableSettings;

  public checkboxOnly = true;
  public mode = 'single';
  public drag = false;

  gridDataSubject: BehaviorSubject<Machine[]>;
  gridView: Observable<Machine[]>;

  mySelection: string[] = [];
  isWindowOpened = false;
  isDialogOpen = false;
  isNew = false;
  formGroup: FormGroup;
  idTextFieldDisabled = false;
  editedRowIndex: number;
  isSecondWindowOpened = false;
  public data: any = {
    idName: '',
    description: '',
    calenderID: 0,
    email: '',
    phone: '',
    fax: '',
    site: '',
    regNo: '',
    gstRegno: '',
    address: '',
    pictureId: '',
  };
  public editId: any;
  public editCustomerId: any;
  public day1: Array<any> = [];
  public selectedItemDay1: any;
  public previousSelectedDay1: any;
  public changedDay1 = { name: '', id: 0 };

  calendardicts = new Object();

  public day2: Array<any> = [
    { name: 'InHouse', id: 1 },
    { name: 'QC', id: 2 },
    { name: 'SubCon', id: 3 },
  ];
  public selectedItemDay2: any;
  public previousSelectedDay2: any;

  constructor(
    private toastr: ToastService,
    private locationService: LocationService,
    private customDialog: CustomDialogService,
    private customMessage: CustomMessageService,
    private calendarService: calendarService,
    private machineService: MachineService
  ) {
    this.setSelectableSettings();
    // description: '',
    // calenderID: 0,
    // email :'',
    // phone: '',
    // fax : '',
    // site: '',
    // regNo: '',
    // gstRegno: '',
    // address: '',
    // pictureId: ''
    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
      calenderID: new FormControl(),
      type: new FormControl(),

      category: new FormControl(),
      string1: new FormControl(),
      cost: new FormControl(0, [
        Validators.required,
        Validators.pattern('^[0-9]*$'),
      ]),
    });

    this.calendardicts[''] = '';

    this.calendarService.getAll().subscribe((result) => {

      if (result){
        result = orderBy(result, [
          { field: 'id', dir: 'desc' },
        ]);
      }

      this.day1.push({ name: '', id: 0 });
      for (var i = 0; i < result.length; i++) {
        this.day1.push(result[i]);
        this.calendardicts[result[i].id] = result[i].name;
      }

      console.log('calendardicts');
      console.log(this.calendardicts);

      this.machineService.getAll().subscribe((newresult) => {
        console.log('machine service dhhfdsshdf');
        //not consistent
        let result = {};
        let nlength = newresult.length;
        for (let i = 0; i < nlength; i++) {
          if (String(newresult[i]['type']) == '1') {
            newresult[i]['type'] = 'InHouse';
          } else if (String(newresult[i]['type']) == '2') {
            newresult[i]['type'] = 'QC';
          } else if (String(newresult[i]['type']) == '3') {
            newresult[i]['type'] = 'SubCon';
          }
          for (var key in this.calendardicts) {
            var value = this.calendardicts[key];
            console.log('DICTVAL');
            console.log(key);
            console.log(value);
            // do something with "key" and "value" variables
          }
          if (this.calendardicts.hasOwnProperty(newresult[i]['calendarId'])) {
            newresult[i]['calendarName'] =
              this.calendardicts[newresult[i]['calendarId']];
          } else {
            newresult[i]['calendarName'] = '';
          }
        }

        result['$id'] = 1;
        result['$values'] = newresult;
        console.log(result);
        console.log(result);
        if (result['$values']) {
          console.log('inside man');
          result['$values'] = orderBy(result['$values'] as any, [
            { field: 'id', dir: 'desc' },
          ]);
        }
        console.log('constructor');
        console.log(JSON.stringify(result['$values']));
        this.gridDataSubject = new BehaviorSubject<Machine[]>(
          result['$values']
        );
        console.log('grideview');
        console.log(this.gridDataSubject);
        this.gridView = result['$values'];
        console.log(this.gridView);

        // this.gridView = JSON.stringify(result['$values']);
      });
    });
  }

  ngOnInit(): void {
    this.loadItems();
  }

  public setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: this.checkboxOnly,

      drag: this.drag,
      mode: 'single',
    };
  }
  loadItems() {
    this.machineService.getAll().subscribe((newresult) => {
      console.log('machine service dhhfdsshdf');
      //not consistent
      let result = {};
      let nlength = newresult.length;
      console.log('calendardicts');
      console.log(this.calendardicts);
      for (let i = 0; i < nlength; i++) {
        if (String(newresult[i]['type']) == '1') {
          newresult[i]['type'] = 'InHouse';
        } else if (String(newresult[i]['type']) == '2') {
          newresult[i]['type'] = 'QC';
        } else if (String(newresult[i]['type']) == '3') {
          newresult[i]['type'] = 'SubCon';
        }
        console.log('current calendarid');
        console.log(newresult[i]['calendarId']);
        let curCalendarId = newresult[i]['calendarId'];
        console.log('type');
        console.log(typeof this.calendardicts);

        console.log(Object.keys(this.calendardicts));
        for (var key in this.calendardicts) {
          var value = this.calendardicts[key];
          console.log('DICTVAL');
          console.log(key);
          console.log(value);
          // do something with "key" and "value" variables
        }

        if (this.calendardicts.hasOwnProperty(curCalendarId)) {
          console.log('211 man');
          newresult[i]['calendarName'] = this.calendardicts[curCalendarId];
        } else {
          newresult[i]['calendarName'] = '';
        }
      }
      result['$id'] = 1;
      result['$values'] = newresult;
      console.log(result);
      console.log(result);
      if (result['$values']) {
        console.log('inside man');
        result['$values'] = orderBy(result['$values'] as any, [
          { field: 'id', dir: 'desc' },
        ]);
      }
      console.log('constructor');
      console.log(JSON.stringify(result['$values']));
      this.gridDataSubject = new BehaviorSubject<Machine[]>(result['$values']);
      console.log('grideview');
      console.log(this.gridDataSubject);
      this.gridView = result['$values'];
      console.log(this.gridView);

      // this.gridView = JSON.stringify(result['$values']);
    });
  }

  onFilter(inputValue: string): void {
    console.log(inputValue);
    const items = process(this.gridDataSubject.value, {
      filter: {
        logic: 'or',
        filters: [
          {
            field: 'code',
            operator: 'contains',
            value: inputValue,
          },
          {
            field: 'name',
            operator: 'contains',
            value: inputValue,
          },
        ],
      },
    }).data;

    console.log(items);
    this.callHttpRequest(items);
    this.dataBinding.skip = 0;
  }

  clearData(): void {
    this.formGroup = new FormGroup({
      idName: new FormControl(
        this.data.idName,
        Validators.compose([Validators.required, Validators.minLength(1)])
      ),
      description: new FormControl(this.data.description),
      calenderID: new FormControl(),
      type: new FormControl(),

      category: new FormControl(),
      string1: new FormControl(),
      cost: new FormControl(0, [
        Validators.required,
        Validators.pattern('^[0-9]*$'),
      ]),
    });
  }

  onAddNewClick(): void {
    this.clearData();
    this.idTextFieldDisabled = false;
    this.changedDay1 = { name: '', id: 0 };
    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = true;
  }

  editButton(event: EditEvent): void {
    let newData = {
      idName: '',
      startTime: new Date(2002, 2, 10, 22, 15),
      endTime: new Date(2002, 2, 10, 22, 15),
    };
    this.idTextFieldDisabled = true;
    console.log(this.mySelection.length);
    console.log(this.gridView);
    console.log(event.dataItem);

    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } else {
      let selectedindex = this.mySelection[0];
      console.log('editbutton');
      console.log(this.mySelection);
      console.log(this.gridView);
      console.log('gridview');
      let countindex = 0;
      for (var row in this.gridView) {
        console.log(this.gridView[row]);
        let curTup = this.gridView[row];
        if (curTup['$id'] == selectedindex) {
          console.log('selected tuple');
          console.log(curTup);
          this.isNew = false;
          let getstarttime = curTup.startTime;
          let startTimeArray = getstarttime.split(':');
          let startTimeHour = startTimeArray[0];
          let startTimeMinute = startTimeArray[1];
          let getendTime = curTup.endTime;
          let endTimeArray = getendTime.split(':');
          let endTimeHour = endTimeArray[0];
          let endTimeMinute = endTimeArray[1];

          newData.idName = curTup.name;
          newData.startTime = new Date(
            2002,
            2,
            10,
            startTimeHour,
            startTimeMinute
          );
          newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);

          console.log(newData);
          this.formGroup.reset(newData);
          this.isWindowOpened = !this.isWindowOpened;
          this.editedRowIndex = countindex;
          break;
        }
        countindex += 1;
        console.log('break');
      }
      // console.log(JSON.stringify(this.gridView));
    }
  }

  onEditClick(event: EditEvent): void {
    console.log(event);
    this.idTextFieldDisabled = true;
    // this.editId = event.dataItem.id;
    // this.editCustomerId = event.dataItem.customer.id;
    // description: new FormControl(this.data.description),
    // calenderID: new FormControl(),
    // email: new FormControl(this.data.email),
    // phone: new FormControl(this.data.phone),
    // fax: new FormControl(this.data.fax),
    // site: new FormControl(this.data.site),
    // regNo: new FormControl(this.data.regNo),
    // gstRegno: new FormControl(this.data.gstRegno),
    // address: new FormCoidNamentrol(this.data.address),

    // description: new FormControl(this.data.description),
    // calenderID: new FormControl(),
    // type: new FormControl(),

    // category: new FormControl(),
    // string1: new FormControl(),
    // costBasisType: new FormControl(),

    let newData = {
      id: event.dataItem.id,
      idName: event.dataItem.name,
      type: { name: '', id: 0 },
      calenderID: { name: '', id: 0 },
      description: event.dataItem.description,
      category: event.dataItem.category,
      string1: event.dataItem.string1,
      cost: event.dataItem.cost,
    };

    let curCalendarID = event.dataItem.calendarId;
    let curType = event.dataItem.type;
    this.changedDay1 = { name: '', id: 0 };
    this.changedDay2 = { name: '', id: 0 };
    console.log('eddit');
    console.log(curCalendarID);

    console.log(this.day1);
    for (let i = 0; i < this.day1.length; i++) {
      let curtup = this.day1[i];
      if (curtup.id == curCalendarID) {
        this.changedDay1.name = curtup.name;
        this.changedDay1.id = curtup.id;
        newData.calenderID.name = curtup.name;
        newData.calenderID.id = curtup.id;
      }
    }

    if (curType == 'InHouse') {
      this.changedDay2 = { name: 'InHouse', id: 1 };
      newData.type.id = 1;
      newData.type.name = 'InHouse';
    } else if (curType == 'QC') {
      this.changedDay2 = { name: 'QC', id: 2 };
      newData.type.id = 2;
      newData.type.name = 'QC';
    } else if (curType == 'SubCon') {
      this.changedDay2 = { name: 'SubCon', id: 3 };
      newData.type.id = 3;
      newData.type.name = 'SubCon';
    }

    this.isWindowOpened = !this.isWindowOpened;
    this.isNew = false;
    console.log('event');
    console.log(this.mySelection);
    console.log(newData);
    console.log(event.dataItem);

    // let getstarttime = event.dataItem.startTime;
    // let startTimeArray = getstarttime.split(':');
    // let startTimeHour = startTimeArray[0];
    // let startTimeMinute = startTimeArray[1];
    // let getendTime = event.dataItem.endTime;
    // let endTimeArray = getendTime.split(':');
    // let endTimeHour = endTimeArray[0];
    // let endTimeMinute = endTimeArray[1];

    newData.idName = event.dataItem.name;
    // newData.startTime = new Date(2002, 2, 10, startTimeHour, startTimeMinute);
    // newData.endTime = new Date(2002, 2, 10, endTimeHour, endTimeMinute);
    this.formGroup.reset(newData);
    this.editedRowIndex = event.rowIndex;
  }

  closeWindow(): void {
    this.loadItems();
    this.isWindowOpened = false;
  }

  submitWindow(item): void {
    this.isWindowOpened = false;
    this.saveItem(item);
  }

  addMore(item): void {

    let machineObject = this.createMachineObjectForDBOperation(item);

    this.postToDB({
      params: machineObject,
      next: () => {
        this.toastr.success('Your data has been saved sucessfully.');
      }
    });
  }

  closeWindowWarning() {
    this.isSecondWindowOpened = false;
  }

  twofourHoursformat(time): string {

    var hours = Number(time.match(/^(\d+)/)[1]);
    var minutes = Number(time.match(/:(\d+)/)[1]);
    var AMPM = time.match(/\s(.*)$/)[1];

    if (AMPM == 'PM' && hours < 12) hours = hours + 12;
    if (AMPM == 'AM' && hours == 12) hours = hours - 12;

    var sHours = hours.toString();
    var sMinutes = minutes.toString();

    if (hours < 10) sHours = '0' + sHours;
    if (minutes < 10) sMinutes = '0' + sMinutes;

    return sHours + ':' + sMinutes;
  }

  public saveItem(item): void {

    let machineObject = this.createMachineObjectForDBOperation(item);

    if (this.isNew) {
      this.postToDB({
        params: machineObject,
        next: (res) => {
          this.loadItems();
          this.toastr.success('Your data has been saved sucessfully.');
        }
      });
    } 
    else {

      const items = this.gridDataSubject.value;
      machineObject.id = items[this.editedRowIndex].id;

      this.machineService
        .update(machineObject.id , machineObject)
        .pipe(first())
        .subscribe({
          next: () => {
            this.loadItems();
            this.toastr.success('Your data has been updated sucessfully.');
          },
          error: (error) => {},
        });
    }
  }

  createMachineObjectForDBOperation(item){

    let getName = item['idName'];
    let getid = item['id'];

    return {
      id: getid,
      name: getName,
      parentResourceId: 0,
      type: item['type']['id'],
      category: item['category'],
      subcategory: '',
      locationId: 0,
      calendarId: this.changedDay1.id,
      skillLevel: 0,
      cost: item.cost,
      costBasisType: '',
      description: item.description,
      string1: item['string1'],
      createdDate: '2021-10-22T11:02:22.246Z',
      modifiedDate: '2021-10-22T11:02:22.246Z',
      locationName: 'string',
      calendarName: this.changedDay1.name,
      typeName: 'string',
      parentName: 'string',
      operations: 0,
      operationNames: 'string',
      parameters: 0,
    };
  }

  postToDB(data: {
    params: any,
    next: (res) => void,
    error?: (error) => void
  }){
    this.machineService
      .save(data.params)
      .pipe(first())
      .subscribe({
        next: data.next,
        error: data.error ?? ((error) => {})
      });
  }

  deleteButton(): void {
    console.log(this.mySelection);

    if (this.mySelection.length == 0) {
      this.toastr.error('Please click on one of the checkboxes');
    } else {
      this.editedRowIndex = parseInt(this.mySelection[0]);
      console.log('delete ' + this.editedRowIndex);
      this.customDialog.confirm().subscribe((res) => {
        // Primary (Yes) button is clicked
        if (res.primary) {
          console.log('delete if');
          this.removeItem();
        }
      });
    }
  }

  onDeleteClick(event: RemoveEvent): void {
    console.log('ondelete click');
    console.log(event);
    let newevent = event.dataItem;
    console.log(newevent);

    if (newevent.operations > 0) {
      console.log('inside');
      this.isSecondWindowOpened = true;
    } else {
      this.editedRowIndex = event.rowIndex;
      console.log('delete ' + this.editedRowIndex);
      this.customDialog.confirm().subscribe((res) => {
        // Primary (Yes) button is clicked
        if (res.primary) {
          console.log('delete if');
          this.removeItem();
        }
      });
    }
  }

  removeItem(): void {
    // do you processing and close window
    let items = this.gridDataSubject.value;
    console.log('removeItem');
    console.log(items);
    console.log(items[this.editedRowIndex].id);
    console.log(this.editedRowIndex);

    // success should be in resolve of subscribe method
    this.machineService
      .delete(items[this.editedRowIndex].id)
      .pipe(first())
      .subscribe({
        next: (data) => {
          this.gridDataSubject.next(items);
          console.log('delete item');
          console.log(data);
          if (data == -1) {
            this.toastr.error('Meal is used by Shift');
          } else {
            this.loadItems();
            this.toastr.success('Your data has been removed sucessfully.');
          }
        },
        error: (error) => {},
      });
  }

  callHttpRequest(items): void {
    this.gridDataSubject.next(items);
  }

  onViewClick(dataItem): void {
    // Do some action with view
    this.toastr.info(`You have selected record:  ${dataItem.firstName}`);
  }

  // public changedDay1 = { name: '', id: -2 };

  public valueChangeDay1(value: any): void {
    this.changedDay1 = value;
    console.log(this.changedDay1);
    // this.log('valueChange', JSON.stringify(value));
  }

  public changedDay2 = { name: '', id: 0 };
  public valueChangeDay2(value: any): void {
    this.changedDay2 = value;
    console.log(value);
    // this.log('valueChange', JSON.stringify(value));
  }
}
