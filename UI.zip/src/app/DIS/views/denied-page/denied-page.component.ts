import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-denied-page',
  templateUrl: './denied-page.component.html',
  styleUrls: ['./denied-page.component.scss']
})
export class DeniedPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
