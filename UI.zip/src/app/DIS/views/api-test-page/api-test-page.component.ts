import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin/admin.service';

@Component({
  selector: 'app-api-test-page',
  templateUrl: './api-test-page.component.html',
  styleUrls: ['./api-test-page.component.scss']
})
export class ApiTestPageComponent implements OnInit {
  eventsRes: any[] = [];

  constructor(private adminService: AdminService) { }

  ngOnInit(): void {
  }

  testAPI() {
    this.adminService.testAPI()
      .subscribe((res: any) => {
        console.log(res);
        this.eventsRes = res;
      },
      err => {
        console.log(err);
        this.eventsRes = [];
        this.eventsRes.unshift(err);
      });
  }

}
