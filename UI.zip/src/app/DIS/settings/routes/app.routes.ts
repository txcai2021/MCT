import { AppRoutes as routes } from '../routes.config';

export const AppRoutes = routes;
