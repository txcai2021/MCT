import { RoleTypes } from '@dis/auth/roles.enum';
// Will allow show/hide of links in sidebar when sign-on flow is implemented

export const config = [
  {
    group: 'Security',
    // Add navigation items here
    items: [
      {
        name: 'User',
        icon: 'crosstab',
        link: './user',
        elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_RPS_ADMIN],
      },
    ],
  },
  {
    group: 'Product',
    items: [
      {
        name: 'Customer',
        icon: 'crosstab',
        link: './customer',

        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_ENGINEERING,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR,
        ],
      },
      {
        name: 'Supplier',
        icon: 'crosstab',
        link: './supplier',

        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_ENGINEERING,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR,
        ],
      },
      {
        name: 'Raw Material',
        icon: 'crosstab',
        link: './raw_material',

        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_ENGINEERING,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR,
        ],
      },
      {
        name: 'Part',
        icon: 'crosstab',
        link: './parts',

        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_ENGINEERING,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR,
        ],
      },
      {
        name: 'Assembly',
        icon: 'crosstab',
        link: './assembly',

        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_ENGINEERING,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR,
        ],
      },
    ],
  },
  {
    group: 'Resource',
    items: [
      {
        name: 'Machine',
        icon: 'crosstab',
        link: './machine',
        elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
      },
      {
        name: 'Operation',
        icon: 'crosstab',
        link: './operation',
        elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
      },
      {
        name: 'Location',
        icon: 'crosstab',
        link: './location',
        elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
      },
    ],
  },
  {
    group: 'Process',
    items: [
      {
        name: 'Routing',
        icon: 'crosstab',
        link: './routing',

        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_ENGINEERING,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR],

      },
    ],
  },
  {
    group: 'Order',
    items: [
      {
        name: 'Sale Order',
        icon: 'crosstab',
        link: './sale_order',

        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR,
        ],
      },
      {
        name: 'Work Order',
        icon: 'crosstab',
        link: './work_order',

        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR,
        ],
      },
      {
        name: 'Settings',
        icon: 'crosstab',
        link: './order_settings',
        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR,
        ],
      },
    ],
  },
  {
    group: 'Calendar',
    items: [
      {
        name: 'Meal',
        icon: 'crosstab',
        link: './meal',
        elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
      },
      {
        name: 'Shift',
        icon: 'crosstab',
        link: './shift',
        elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
      },
      {
        name: 'Day',
        icon: 'crosstab',
        link: './day',
        elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
      },
      {
        name: 'Week',
        icon: 'crosstab',
        link: './week',
        elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
      },
      {
        name: 'Calendar',
        icon: 'crosstab',
        link: './calendar',
        elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
      },
      {
        name: 'CalendarException',
        icon: 'crosstab',
        link: './calendarexception',
        elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
      },
    ],
  },
  {
    group: 'Scheduling',
    items: [
      {
        name: 'Scheduling',
        icon: 'crosstab',
        link: './scheduling',
        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR,
        ],
      },
      {
        name: 'Reports',
        icon: 'crosstab',
        link: './scheduling_reports',
        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR,
        ],
      }, 
      {
        name: 'Settings',
        icon: 'crosstab',
        link: './scheduling_settings',
        elevation: [
          RoleTypes.ROLE_ADMIN,
          RoleTypes.ROLE_USER,
          RoleTypes.ROLE_RPS_ADMIN,
          RoleTypes.ROLE_RPS_MASTERPLANNER,
          RoleTypes.ROLE_RPS_SUPERVISOR,
        ],
      },  
    ]
  }
];
