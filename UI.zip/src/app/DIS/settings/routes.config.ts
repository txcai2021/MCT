import { Routes } from '@angular/router';
import { AppTemplateRoutes } from '@dis/settings/routes/routes.template.config';
import { AuthGuardService } from '@dis/services/auth/auth-guard.service';
import { UserListComponent } from '@app/views/users/user-list/user-list.component';
import { CustomerListComponent } from '@app/views/customer/customer-list/customer-list.component';
import { SupplierListComponent } from '@app/views/supplier/supplier-list/supplier-list.component';
import { PartListComponent } from '@app/views/part/part-list/part-list.component';
import { AssemblyListComponent } from '@app/views/assembly/assembly-list/assembly-list.component';
import { RawMaterialListComponent } from '@app/views/raw-material/raw-material-list/raw-material-list.component';
import { SaleOrderListComponent } from '@app/views/sale_order/sale-order-list/sale-order-list.component';
import { AssemblyResolve } from '@app/views/assembly/assembly.resolve';
import { AuthGuard } from '@dis/services/keycloak-auth/auth.guard';

import { MealComponent } from '@app/views/calendar/meal/meal.component';
import { DayComponent } from '@app/views/calendar/day/day.component';
import { ShiftComponent } from '@app/views/calendar/shift/shift.component';
import { WeekComponent } from '@app/views/calendar/week/week.component';
import { CalendarExceptionComponent } from '@app/views/calendar/calendar-exception/calendar-exception.component';
import { RoutingComponent } from '@app/views/routing/routing/routing.component';
import { CalendarComponent } from '@app/views/calendar/calendar/calendar.component';
import { LocationComponent } from '@app/views/location/location.component';
import { WorkOrderListComponent } from '@app/views/order/work-order-list/work-order-list.component';
import { MachineComponent } from '@app/views/machine/machine.component';

import { OperationComponent } from '@app/views/operation/operation.component';
import { OrderSettingsComponent } from '@app/views/order/order-settings/order-settings.component';
import { SchedulingSettingsComponent } from '@app/views/scheduling/scheduling-settings/scheduling-settings.component';
import { SchedulingComponent } from '@app/views/scheduling/scheduling/scheduling.component';
import { SchedulingReportsComponent } from '@app/views/scheduling/scheduling-reports/scheduling-reports.component';
import { SchedulingGanttChartComponent } from '@app/views/scheduling/scheduling-gantt-chart/scheduling-gantt-chart.component';
import { RoleTypes } from '@dis/auth/roles.enum';

// Import your app views below and add the array below
// For reference, see routes.template.config.js

export const AppRoutes: Routes = [
  // Define a default redirect
  {
    path: 'meal',
    component: MealComponent,
    canActivate: [AuthGuard],
    data: {
      elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
    },
  },
  {
    path: 'location',
    component: LocationComponent,
    canActivate: [AuthGuard],
    data: {
      elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
    },
  },
  {
    path: 'operation',
    component: OperationComponent,
    canActivate: [AuthGuard],
    data: {
      elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
    },
  },
  {
    path: 'day',
    component: DayComponent,
    canActivate: [AuthGuard],
    data: {
      elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
    },
  },
  {
    path: 'machine',
    component: MachineComponent,
    canActivate: [AuthGuard],
    data: {
      elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
    },
  },
  {
    path: 'shift',
    component: ShiftComponent,
    canActivate: [AuthGuard],
    data: {
      elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
    },
  },
  {
    path: 'week',
    component: WeekComponent,
    canActivate: [AuthGuard],
    data: {
      elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
    },
  },
  {
    path: 'calendarexception',
    component: CalendarExceptionComponent,
    canActivate: [AuthGuard],
    data: {
      elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
    },
  },
  {
    path: 'calendar',
    component: CalendarComponent,
    canActivate: [AuthGuard],
    data: {
      elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_USER],
    },
  },
  {
    path: 'user',
    component: UserListComponent,

    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [RoleTypes.ROLE_ADMIN, RoleTypes.ROLE_RPS_ADMIN],
    },
  },
  {
    path: 'customer',
    component: CustomerListComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_ENGINEERING,
        RoleTypes.ROLE_RPS_MASTERPLANNER,
        RoleTypes.ROLE_RPS_SUPERVISOR,
      ],
    },
  },
  {
    path: 'supplier',
    component: SupplierListComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_ENGINEERING,
        RoleTypes.ROLE_RPS_MASTERPLANNER,
        RoleTypes.ROLE_RPS_SUPERVISOR,
      ],
    },
  },
  {
    path: 'parts',
    component: PartListComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_ENGINEERING,
        RoleTypes.ROLE_RPS_MASTERPLANNER,
        RoleTypes.ROLE_RPS_SUPERVISOR,
      ],
    },
  },
  {
    path: 'raw_material',
    component: RawMaterialListComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_ENGINEERING,
        RoleTypes.ROLE_RPS_MASTERPLANNER,
        RoleTypes.ROLE_RPS_SUPERVISOR,
      ],
    },
  },
  {
    path: 'assembly',
    component: AssemblyListComponent,

    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    // resolve:{
    //   assemblyData: AssemblyResolve
    // },
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_ENGINEERING,
        RoleTypes.ROLE_RPS_MASTERPLANNER,
        RoleTypes.ROLE_RPS_SUPERVISOR,
      ],
    },
  },
  {
    path: 'sale_order',
    component: SaleOrderListComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_MASTERPLANNER,
        RoleTypes.ROLE_RPS_SUPERVISOR,
      ],
    },
  },
  {
    path: 'work_order',
    component: WorkOrderListComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_MASTERPLANNER,
        RoleTypes.ROLE_RPS_SUPERVISOR,
      ],
    },
  },
  {
    path: 'order_settings',
    component: OrderSettingsComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_MASTERPLANNER,
        RoleTypes.ROLE_RPS_SUPERVISOR,
      ],
    },
  },
  {
    path: 'routing',
    component: RoutingComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_ENGINEERING,
        RoleTypes.ROLE_RPS_MASTERPLANNER
      ]
    }
  },
  {
    path: 'scheduling',
    component: SchedulingComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_ENGINEERING,
        RoleTypes.ROLE_RPS_MASTERPLANNER
      ]
    }
  },
  {
    path: 'scheduling_reports',
    component: SchedulingReportsComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_ENGINEERING,
        RoleTypes.ROLE_RPS_MASTERPLANNER
      ]
    }
  },
  {
    path: 'scheduling_gantt',
    component: SchedulingGanttChartComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_ENGINEERING,
        RoleTypes.ROLE_RPS_MASTERPLANNER
      ]
    }
  },
  {
    path: 'scheduling_settings',
    component: SchedulingSettingsComponent,
    canActivate: [AuthGuard], // To accept ALL access after login, use AuthGuardService
    data: {
      elevation: [
        RoleTypes.ROLE_ADMIN,
        RoleTypes.ROLE_USER,
        RoleTypes.ROLE_RPS_ADMIN,
        RoleTypes.ROLE_RPS_ENGINEERING,
        RoleTypes.ROLE_RPS_MASTERPLANNER
      ]
    }
  },
  { path: '', pathMatch: 'full', redirectTo: '/user' },
  ...AppTemplateRoutes,
];
