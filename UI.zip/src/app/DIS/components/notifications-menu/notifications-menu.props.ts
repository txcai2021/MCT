export interface Notification {
  id: string;
  status?: string;
  content: string;
}
