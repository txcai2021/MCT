import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'event-log',
  templateUrl: './event-log.component.html',
  styleUrls: ['./event-log.component.scss']
})
export class EventLogComponent implements OnInit {
  @Input() public title: string;
  @Input() public events: any[];

  constructor() { }

  ngOnInit(): void {
  }

  public logEvents(event: any, i: number): string {
    if(event['date']) {
      return `${i + 1}. { 
        date: ${event.date}, 
        temperatureC: ${event.temperatureC}, 
        temperatureF: ${event.temperatureF}, 
        summary: ${event.summary} }`;
    }
    return event.message;
  }

}
