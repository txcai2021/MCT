import { Component, Input, Output, EventEmitter,
  ViewChild, ElementRef } from '@angular/core';
import {
  Validators, FormGroup, FormControl,
  AbstractControl, ValidationErrors, ValidatorFn
} from '@angular/forms';
import { AdminService } from '@dis/services/admin/admin.service';

@Component({
  selector: 'kendo-grid-role-mapping-form',
  templateUrl: './role-mapping-form.component.html',
  styleUrls: ['./role-mapping-form.component.scss']
})
export class RoleMappingFormComponent {
  public active = false;
  public listItems: Array<{ text: string; value: string }> = [];

  @Input() public set roleMappingActive(isActive: boolean) {
    this.active = isActive;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<any> = new EventEmitter();

  public selectGroupForm: FormGroup = new FormGroup({
    group: new FormControl('', Validators.required)
  });

  constructor(private adminService: AdminService) { }

  ngOnInit(): void {
    this.adminService.getAllGroups()
      .subscribe((response: any) => {
        this.mapToGroupData(response);
      });
  }

  public onSave(e): void {
    e.preventDefault();
    this.active = false;
    this.save.emit(this.selectGroupForm.value);
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.active = false;
    this.cancel.emit();
  }

  mapToGroupData(response: any) {
    response.forEach((group: any) => {
      this.listItems.push({text: group['name'], value: group['name']});
    });
    return true;
  }

}
