import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Validators, FormGroup, FormControl, 
  AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { User } from '@dis/models/user';
import { AdminService } from '@dis/services/admin/admin.service';

export function createPasswordValidator(): ValidatorFn {
  return (control:AbstractControl) : ValidationErrors | null => {
    const value = control.value;
    if (value === '' || !value) {
        return null;
    }

    const passwordValid = (value.length >= 10);

    return passwordValid ? null: {passwordInvalid:true};
  }
}

@Component({
  selector: 'kendo-grid-edit-form',
  templateUrl: './edit-form.component.html',
  styleUrls: ['./edit-form.component.scss']
})
export class GridEditFormComponent {

  public listItems: Array<{ text: string; value: string }> = [];
  public active = false;
  public editForm: FormGroup = new FormGroup({
    _id: new FormControl(''),
    username: new FormControl('', Validators.required),
    group: new FormControl('', Validators.required),
    fullname: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, 
      Validators.email]),
    mobile: new FormControl('', [Validators.required, 
      Validators.minLength(8),
      Validators.maxLength(8),
      Validators.pattern("^[0-9]*$")]),
    password: new FormControl('', createPasswordValidator())
  });
  inputGroup: string;

  @Input() public isNew = false;
  @Input() public set model(user: User) {
    if(user.group === 'New') user.group = 'New User Group';
    this.editForm.reset(user);
    this.editForm.controls['mobile'].setValue(
      user.mobile ? user.mobile.substr(user.mobile.length-8, 8) : ''
    );
    console.log(user.mobile);
    this.active = user !== undefined;
    console.log(user);
    this.inputGroup = user.group;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<any> = new EventEmitter();

  constructor(private adminService: AdminService) { }

  ngOnInit(): void {
    this.adminService.getAllGroups()
      .subscribe((response: any) => {
        this.mapToGroupData(response);
      });
  }

  public onSave(e): void {
    e.preventDefault();
    var temp = {
      originGroup: this.inputGroup
    };
    this.save.emit({...this.editForm.value, ...temp});
    this.active = false;
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.active = false;
    this.cancel.emit();
  }

  mapToGroupData(response: any) {
    response.forEach((group: any) => {
      this.listItems.push({text: group['name'], value: group['name']});
    });
    return true;
  }

}
