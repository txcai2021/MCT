import { Component, Input, Output, EventEmitter,
  ViewChild, ElementRef } from '@angular/core';
import * as XLSX from 'xlsx';

@Component({
  selector: 'kendo-grid-import-form',
  templateUrl: './import-form.component.html',
  styleUrls: ['./import-form.component.scss']
})
export class ImportFormComponent {

  public active = false;
  fileData: any;
  fileDataReady: boolean = false;
  isExcelFile: boolean;
  @ViewChild('inputFile') inputFile: ElementRef;

  @Input() public set importActive(isActive: boolean) {
    this.active = isActive;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }

  public onSave(e): void {
    e.preventDefault();
    this.active = false;
    this.save.emit(this.fileData);
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.active = false;
    this.cancel.emit();
  }

  private onFileChange(event) {
    const target: DataTransfer = <DataTransfer>event.target;
    this.isExcelFile = !!target.files[0].name.match(/(.xls|.xlsx)/);
    if (target.files.length > 1) {
      this.inputFile.nativeElement.value = '';
    }
    if (this.isExcelFile) {
      const reader: FileReader = new FileReader();
      reader.onload = (e: any) => {
        /* read workbook */
        const bstr: string = e.target.result;
        const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

        /* grab first sheet */
        const wsname: string = wb.SheetNames[0];
        const ws: XLSX.WorkSheet = wb.Sheets[wsname];

        /* save data */
        this.fileData = XLSX.utils.sheet_to_json(ws);
        
      };

      reader.readAsBinaryString(target.files[0]);

      reader.onloadend = (e) => {
        this.formatFileData(this.fileData);
        console.log(this.fileData);
      };
    }
    else {
      this.inputFile.nativeElement.value = '';
      confirm("Please import the Excel file");
    }
  }

  formatFileData(data: any) {
    if(data.length > 0) {
      let keys: string[] = Object.keys(data[0]);
      console.log(keys);
      if (keys.includes('Username') &&
        keys.includes('Group') &&
        keys.includes('Full Name') &&
        keys.includes('Email') &&
        keys.includes('Contact Number')) {
        data.forEach((user: any) => {
          user['Created Time'] = new Date();
          if (user['Contact Number'] !== null && user['Contact Number'] !== "") {
            user['Contact Number'] =
              user['Contact Number'].toString().substr(user['Contact Number'].length - 8, 8);
          }
          else {
            user['Contact Number'] = '';
          }
          let nameArray = user['Full Name'].split(' ');
          let fName = "";
          nameArray.forEach(element => {
            if (element !== "" && element !== " ") {
              fName += (element + " ");
            }
          });
          user['Full Name'] = fName;
          user['Group'] = (user['Group'].includes('Admin')) ? 'Admin Group' 
            : (user['Group'].includes('New')) ? 'New User Group' : 'User Group'
        });
        this.fileData = data;
        this.fileDataReady = true;
      }
      else {
        confirm("Error !! Please make sure the excel file include the fields below: \n" 
          + " Username\n Group\n Full Name\n Email\n Contact Number");
        this.inputFile.nativeElement.value = '';
      }
    }
    else {
      this.inputFile.nativeElement.value = '';
      confirm("This is an empty file");
    }
    
  }

}
