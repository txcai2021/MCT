export class Group {
    id: string;
    name: string;
}