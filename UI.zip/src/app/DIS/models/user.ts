export class User {
    _id: string;
    username: string;
    role: string;
    group: string;
    fullname: string;
    email: string;
    mobile: string;
    createdTimestamp: string;
}