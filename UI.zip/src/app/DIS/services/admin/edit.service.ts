// import { Injectable } from '@angular/core';
// import { Observable, BehaviorSubject } from 'rxjs';
// import { HttpClient } from '@angular/common/http';

// import { tap, map } from 'rxjs/operators';

// const CREATE_ACTION = 'create';
// const UPDATE_ACTION = 'update';
// const DELETE_ACTION = 'delete';

// @Injectable({
//   providedIn: 'root'
// })
// export class EditService extends BehaviorSubject<any[]> {

//   constructor(private http: HttpClient) {
//     super([]);
//   }

  
// }
