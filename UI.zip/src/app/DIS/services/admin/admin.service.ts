import { Injectable } from '@angular/core';
import { SharedService } from '../shared/shared.service';
import { KeycloakApiService } from '../keycloak-api/keycloak-api.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(
    private sharedService: SharedService,
    private keycloakApiService: KeycloakApiService
  ) { }

  testAPI() {
    return this.sharedService.get("/WeatherForecast");
  }

  getAllUsers() {
    return this.keycloakApiService.getAllUsers();
  }

  getUserRealmRoles(userId: string) {
    return this.keycloakApiService.getUserRealmRoles(userId);
  }

  getUserGroups(userId: string) {
    return this.keycloakApiService.getUserGroups(userId);
  }

  getAllGroups() {
    return this.keycloakApiService.getAllGroups();
  }

  getRealmRolesByGroupId(groupId: string) {
    return this.keycloakApiService.getRealmRolesByGroupId(groupId);
  }

  getAllRequiredActions() {
    return this.keycloakApiService.getAllRequiredActions();
  }

  updateRequiredActionByAlias(data: any, alias: string) {
    return this.keycloakApiService.updateRequiredActionByAlias(data, alias);
  }

  removeCredentialByUser(userId: string, creId: string) {
    return this.keycloakApiService.removeCredentialByUser(userId, creId);
  }

  getCredentialByUser(userId: string) {
    return this.keycloakApiService.getCredentialByUser(userId);
  }

  getAllClients() {
    return this.keycloakApiService.getAllClients();
  }
}
