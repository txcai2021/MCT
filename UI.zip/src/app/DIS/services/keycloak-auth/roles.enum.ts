export enum RoleTypes {
    ROLE_ADMIN = 'admin',
    ROLE_USER = 'user',
    ROLE_PENDING = 'pending',
    ROLE_RPS_ADMIN= 'rps-administrator',
    ROLE_RPS_ENGINEERING= 'rps-engineering',
    ROLE_RPS_MASTERPLANNER= 'rps-masterplanner',
    ROLE_RPS_PRODUCTION= 'rps-production',
    ROLE_RPS_SUPERVISOR= 'rps-supervisor'
  }