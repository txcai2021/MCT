import { Injectable } from '@angular/core';
import { KeycloakService } from 'keycloak-angular';
import { User } from '@dis/components/profile-menu/profile-menu.props';

@Injectable({
  providedIn: 'root'
})
export class AuthKeycloakService {

  constructor(private keycloakService: KeycloakService) { }

  logout() {
    //var logoutOptions = { redirectUri : 'http:localhost:8080/' };
    this.keycloakService.logout();
  }

  async isLoggedIn(): Promise<boolean> {
    //return this.keycloakService.isLoggedIn();
    console.log("Check is login user");
    let isLogIn = await this.keycloakService.isLoggedIn();
    return isLogIn;
  }

  getUserDetails = async(): Promise<User> => {
    if (await this.isLoggedIn()) {
      let userDetails = await this.keycloakService.loadUserProfile();
      let token = await this.keycloakService.getToken();
      let userRole = this.keycloakService.isUserInRole('admin') ? 'admin' : 'user';

      //  console.log(userDetails['attributes'].mobile[0]);
       console.log(userDetails);
      return {
        id: userDetails.username,
        role: userRole,
        email: userDetails.email,
        contact: userDetails['attributes'] ? 
          (userDetails['attributes'].mobile ? userDetails['attributes'].mobile[0] : '') : ''
      };
    }
    else {
      console.log("Not Logged In !");
      return {} as User;
    }
  }
}
