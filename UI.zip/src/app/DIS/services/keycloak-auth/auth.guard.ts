import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { KeycloakAuthGuard, KeycloakService } from 'keycloak-angular';
import { AuthKeycloakService } from './auth-keycloak.service';
import { RoleTypes } from './roles.enum';
import { KeycloakLoginOptions } from 'keycloak-js';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard extends KeycloakAuthGuard {

  constructor(
    protected readonly router: Router,
    protected readonly keycloak: KeycloakService,
    protected readonly _authService: AuthKeycloakService
  ) {
    super(router, keycloak);
  }

  async isAccessAllowed(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Promise<boolean | UrlTree> {
    
    if (!await this._authService.isLoggedIn()) {
      let loginOptions: KeycloakLoginOptions = {
        redirectUri: environment.APP_ROOT + '/sample'
      };
      await this.keycloak.login(loginOptions);
    }
    else {
      console.log(this.roles);
      const requiredRoles = route.data.elevation;
      if(!requiredRoles || requiredRoles.length === 0) {
        return true;
      }
      else {
        for(const role of requiredRoles) {
          console.log(this.roles.indexOf(role));
          if(this.roles.indexOf(role) > -1) {
            return true;
          }
        }
        // below code indicates the origin page of each role
        if(this.roles.indexOf(RoleTypes.ROLE_ADMIN) > -1) {
          this.router.navigate(['sample']);
        }
        else if(this.roles.indexOf(RoleTypes.ROLE_USER) > -1) {
          this.router.navigate(['sample']);
        }
        else if(this.roles.indexOf(RoleTypes.ROLE_PENDING) > -1) {
          this.router.navigate(['not-approved']);
        }
        return false;
      }
    }

    return this.authenticated;
  }

}
