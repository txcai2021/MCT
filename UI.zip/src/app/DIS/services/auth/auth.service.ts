import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { JwtHelperService } from '@auth0/angular-jwt';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { StorageService } from '../storage/storage.service';
import { User } from '@dis/components/profile-menu/profile-menu.props';
import { KeycloakService } from 'keycloak-angular';

@Injectable({
  providedIn: 'root'
})

// This class is not used currently
export class AuthService {
  constructor(
    private _http: HttpClient,
    private _jwt: JwtHelperService,
    private _router: Router,
    private _storage: StorageService,
    private keycloakService: KeycloakService
  ) {}

  login(email, password) {
    return this._http
      .post<{ token: string }>(environment.SSO_ENDPOINT, {
        email: email,
        password: password
      })
      .pipe(
        map(result => {
          // Use storage service instead for broadcast
          this._storage.setItem('access_token', result.token);
          // localStorage.setItem('access_token', result.token);
          return true;
        })
      );
  }

  logout(): boolean {
    localStorage.removeItem('access_token');
    window.location.reload();
    return true;
  }

  isLoggedIn() {
    // TODO: Auth flow in progress
    if (!environment.TEST_AUTH_FLOW_COMPLETE) return true;
    else {
      const token = localStorage.getItem('access_token');
      if (token && !this._jwt.isTokenExpired(token)) {
        return true;
      } else return false;
    }
  }

}
