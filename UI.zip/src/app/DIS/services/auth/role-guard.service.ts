import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { RoleTypes } from '../keycloak-auth/roles.enum';
import { AuthKeycloakService } from '../keycloak-auth/auth-keycloak.service';
import { KeycloakService } from 'keycloak-angular';

@Injectable({
  providedIn: 'root'
})
export class RoleGuardService implements CanActivate {
  constructor(
    private _router: Router, 
    private _authService: AuthKeycloakService,
    private keycloakService: KeycloakService
  ) {}


  //This function is not used currently
  canActivate(route: ActivatedRouteSnapshot): boolean {
    const { elevation } = route.data; // Array of acceptable elevations

    if (!this.isAuthenticated() || !this.isAuthorized(elevation)) {
      this._router.navigate(['login']);
      return false;
    }
    return true;
  }

  async isAuthenticated(): Promise<boolean> {
    return this._authService.isLoggedIn();
  }

  isAuthorized(elevation: Array<RoleTypes>): boolean {
    let currentRoles = this.keycloakService.getUserRoles();
    // const { role } = this._authService.getUserDetails() || {};

    // return (
    //   (role as RoleTypes) === RoleTypes.ROLE_ADMIN ||
    //   elevation.includes(role as RoleTypes)
    // );
    for(const role of currentRoles) {
      if(elevation.includes(role as RoleTypes)) {
        return true;
      }
    }
    return false;
  }

  isApprovedUser() {
    let currentRoles = this.keycloakService.getUserRoles();
    return ! (currentRoles.includes(RoleTypes.ROLE_PENDING) || 
      currentRoles === undefined || currentRoles.length === 0);
  }
}
