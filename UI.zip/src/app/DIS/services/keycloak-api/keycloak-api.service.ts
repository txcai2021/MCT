import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class KeycloakApiService {

  constructor(private http: HttpClient) { }

  getAllUsers(): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_ALL_USERS_API);
  }

  createNewUsers(data: any): Observable<any> {
    return this.http.post<any>(environment.KEYCLOAK_CREATE_NEW_USER_API, data);
  }  

  updateUser(data: any, userId: string): Observable<any> {
    return this.http.put<any>(environment.KEYCLOAK_UPDATE_USER_API + userId, data);
  }

  deleteUser(userId: string): Observable<any> {
    return this.http.delete<any>(environment.KEYCLOAK_DELETE_USER_API + userId);
  }

  getUserRealmRoles(userId: string): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_USER_REALM_ROLE_1 + userId + 
      environment.KEYCLOAK_GET_USER_REALM_ROLE_2);
  }

  getUserGroups(userId: string): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_USER_GROUPS_1 + userId +
      environment.KEYCLOAK_GET_USER_GROUPS_2);
  }

  getAllGroups(): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_ALL_GROUPS);
  }

  getRealmRolesByGroupId(groupId: string): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_REALMROLES_BY_GROUPID_1
      + groupId + environment.KEYCLOAK_GET_REALMROLES_BY_GROUPID_2);
  }

  deleteGroupForUser(groupId: string, userId: string) {
    return this.http.delete<any>(environment.KEYCLOAK_DELETE_GROUP_FOR_USER_1 + 
      userId + environment.KEYCLOAK_DELETE_GROUP_FOR_USER_2 + groupId);
  }

  addGroupForUser(groupId: string, userId: string) {
    return this.http.put<any>(environment.KEYCLOAK_DELETE_GROUP_FOR_USER_1 + 
      userId + environment.KEYCLOAK_DELETE_GROUP_FOR_USER_2 + groupId, null);
  }

  getAllRequiredActions(): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_REQUIRED_ACTION_URL);
  }

  updateRequiredActionByAlias(data:any, alias: string) {
    return this.http.put<any>(environment.KEYCLOAK_UPDATE_REQUIRED_ACTION + alias, data);
  }

  removeCredentialByUser(userId: string, creId: string) {
    return this.http.delete<any>(environment.KEYCLOAK_DELETE_CREDENTIAL_FOR_USER_1 + 
      userId + environment.KEYCLOAK_DELETE_CREDENTIAL_FOR_USER_2 + creId);
  }

  getCredentialByUser(userId: string): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_CREDENTIAL_BY_USER_1 +
      userId + environment.KEYCLOAK_GET_CREDENTIAL_BY_USER_2);
  }

  getAllClients(): Observable<any> {
    return this.http.get<any>(environment.KEYCLOAK_GET_ALL_CLIENTS);
  }
}
