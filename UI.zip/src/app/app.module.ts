// Angular
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClient, HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Environment
import { environment } from 'src/environments/environment';

// Addon
import { ClickOutsideModule } from 'ng-click-outside';
import { JwtModule } from '@auth0/angular-jwt';
import 'hammerjs';

// Kendo
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import {
  GridModule,
  PDFModule,
  ExcelModule
} from '@progress/kendo-angular-grid';
import { ChartsModule } from '@progress/kendo-angular-charts';
import { MenuModule } from '@progress/kendo-angular-menu';
import { IndicatorsModule } from '@progress/kendo-angular-indicators';
import { LabelModule } from '@progress/kendo-angular-label';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { SortableModule } from '@progress/kendo-angular-sortable';
import { BarcodesModule } from "@progress/kendo-angular-barcodes";
import { PDFExportModule } from "@progress/kendo-angular-pdf-export";
import { TreeViewModule } from '@progress/kendo-angular-treeview';
import { TooltipsModule } from "@progress/kendo-angular-tooltip";

// Components
import { NotificationsMenuComponent } from './DIS/components/notifications-menu/notifications-menu.component';
import { ProfileMenuComponent } from './DIS/components/profile-menu/profile-menu.component';
import { SidebarComponent } from './DIS/components/sidebar/sidebar.component';
import { LayoutComponent } from './DIS/components/layout/layout.component';
import { GridEditFormComponent } from './DIS/components/edit-form/edit-form.component';
import { ImportFormComponent } from './DIS/components/import-form/import-form.component';
import { RoleMappingFormComponent } from './DIS/components/role-mapping-form/role-mapping-form.component';
import { EventLogComponent } from './DIS/components/event-log/event-log.component';

// App
import { AppRoutingModule } from './DIS/settings/routes/app-routing.module';
import { AppComponent } from './app.component';
import { ViewHeadingComponent } from './DIS/components/view-heading/view-heading.component';
import { ViewFilterComponent } from './DIS/components/view-filter/view-filter.component';
import { IndicatorCustomSampleComponent } from './DIS/components/indicator-custom-sample/indicator-custom-sample.component';

// Views
import { LoginComponent } from './DIS/views/login/login.component';
import { SamplePageComponent } from './DIS/views/sample-page/sample-page.component';
import { EditedPageComponent } from './DIS/views/edited-page/edited-page.component';
import {GaugesModule} from '@progress/kendo-angular-gauges';
import {TranslateLoader, TranslateModule} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import {BlockUIModule } from 'ng-block-ui';
import { BlockUIHttpModule } from 'ng-block-ui/http';
import { CustomUiBlockerComponent } from './DIS/components/custom-ui-blocker/custom-ui-blocker.component';
import { NotificationModule } from '@progress/kendo-angular-notification';
import {HttpInterceptorService} from '@dis/services/http/http-interceptor.service';
import { DashboardOneComponent } from './DIS/views/dashboard-one/dashboard-one.component';
import { DashboardTwoComponent } from './DIS/views/dashboard-two/dashboard-two.component';
import { DashboardThreeComponent } from './DIS/views/dashboard-three/dashboard-three.component';
import { InputFieldsComponent } from './DIS/views/input-fields/input-fields.component';
import { TablesComponent } from './DIS/views/tables/tables.component';
import { DialogModule, WindowModule } from '@progress/kendo-angular-dialog';
import {
  DatePickerModule,
  DateTimePickerModule,
  DateInputsModule,
} from '@progress/kendo-angular-dateinputs';

import { UserListComponent } from './UI/views/users/user-list/user-list.component';
import { CustomerListComponent } from './UI/views/customer/customer-list/customer-list.component';
import { SupplierListComponent } from './UI/views/supplier/supplier-list/supplier-list.component';
import { PartListComponent } from './UI/views/part/part-list/part-list.component';
import { AssemblyListComponent } from './UI/views/assembly/assembly-list/assembly-list.component';
import { RawMaterialListComponent } from './UI/views/raw-material/raw-material-list/raw-material-list.component';
import { SaleOrderListComponent } from './UI/views/sale_order/sale-order-list/sale-order-list.component';
import { ActionButtonsComponent } from './UI/views/menu/action-buttons/action-buttons.component';
import { RoutingComponent } from './UI/views/routing/routing/routing.component';
import { WorkOrderStatusPipe } from './UI/_helpers/work-order-status.pipe';
import { DefineProcessTimeComponent } from './UI/views/routing/define-process-time/define-process-time.component';
import { WorkOrderTypePipe } from './UI/_helpers/work-order-type.pipe';
import { AssignRawMaterialComponent } from './UI/views/assign-raw-material/assign-raw-material.component';
import { SalesOrderStatusPipe } from './UI/_helpers/sales-order-status.pipe';
import { WorkOrderTravellerComponent } from './UI/views/order/work-order-traveller/work-order-traveller.component';
import { OrderSettingsComponent } from './UI/views/order/order-settings/order-settings.component';
import { SchedulingSettingsComponent } from './UI/views/scheduling/scheduling-settings/scheduling-settings.component';
import { SchedulingComponent } from './UI/views/scheduling/scheduling/scheduling.component';
import { SchedulingReportsComponent } from './UI/views/scheduling/scheduling-reports/scheduling-reports.component';
import { SchedulingGanttChartComponent } from './UI/views/scheduling/scheduling-gantt-chart/scheduling-gantt-chart.component';
import { SchedulerModule } from '@progress/kendo-angular-scheduler';
//import { FormFillingComponent } from './DIS/views/form-filling/form-filling.component';
import { AssemblyResolve } from './UI/views/assembly/assembly.resolve';
import { SalesOrderLineStatusPipe } from './UI/_helpers/sales-order-line-status.pipe';

import { MealComponent } from './UI/views/calendar/meal/meal.component';
import { ShiftComponent } from './UI/views/calendar/shift/shift.component';
import { DayComponent } from './UI/views/calendar/day/day.component';
import { WeekComponent } from './UI/views/calendar/week/week.component';
import { CalendarComponent } from './UI/views/calendar/calendar/calendar.component';
import { CalendarExceptionComponent } from './UI/views/calendar/calendar-exception/calendar-exception.component';
import { MachineComponent } from './UI/views/machine/machine.component';
import { OperationComponent } from '@app/views/operation/operation.component';

import { LocationComponent } from './UI/views/location/location.component';
import { AssignRoutingToProductComponent } from './UI/views/routing/assign-routing-to-product/assign-routing-to-product.component';
import { CreateWorkOrderComponent } from './UI/views/sale_order/create-work-order/create-work-order.component';
import { WorkOrderListComponent } from './UI/views/order/work-order-list/work-order-list.component';
import { WorkOrderReleaseComponent } from './UI/views/order/work-order-release/work-order-release.component';
import { GanttChartNavigation } from '@app/views/scheduling/scheduling-gantt-chart/gantt-chart-navigation';
import { AfterValueChangedDirective } from '@app/_components/after-value-changed.directive';


import { FormFillingComponent } from './DIS/views/form-filling/form-filling.component';
import {UploadModule} from '@progress/kendo-angular-upload';

//Keycloak configuration
import { KeycloakAngularModule } from 'keycloak-angular';
import { initializeKeycloak } from './DIS/init/keycloak-init.factory';
import { KeycloakService } from 'keycloak-angular';
import {MockedKeycloakService} from '@dis/services/mocks/mock-authentication';
import { HorizontalMenuComponent } from './DIS/components/horizontal-menu/horizontal-menu.component';
import { ReceiveRawMaterialsComponent } from './UI/views/raw-material/receive-raw-materials/receive-raw-materials.component';
import { AllocateRawMaterialsComponent } from './UI/views/raw-material/allocate-raw-materials/allocate-raw-materials.component';
import { ShowSchedulingResultsComponent } from './UI/views/scheduling/show-scheduling-results/show-scheduling-results.component';

// Sort
// @ts-ignore
@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    LayoutComponent,
    NotificationsMenuComponent,
    ProfileMenuComponent,
    LoginComponent,
    SamplePageComponent,
    ViewHeadingComponent,
    ViewFilterComponent,
    IndicatorCustomSampleComponent,
    EditedPageComponent,
    CustomUiBlockerComponent,
    DashboardOneComponent,
    DashboardTwoComponent,
    DashboardThreeComponent,
    InputFieldsComponent,
    TablesComponent,
    UserListComponent,
    CustomerListComponent,
    SupplierListComponent,
    PartListComponent,
    AssemblyListComponent,
    RawMaterialListComponent,
    SaleOrderListComponent,
    //FormFillingComponent,
    ActionButtonsComponent,
    MealComponent,
    ShiftComponent,
    DayComponent,
    WeekComponent,
    CalendarComponent,
    CalendarExceptionComponent,
    RoutingComponent,
    LocationComponent,
    AssignRoutingToProductComponent,
    CreateWorkOrderComponent,
    WorkOrderListComponent,
    WorkOrderReleaseComponent,
    SalesOrderLineStatusPipe,
    WorkOrderStatusPipe,
    MachineComponent,
    OperationComponent,
    DefineProcessTimeComponent,
    WorkOrderTypePipe,
    AssignRawMaterialComponent,
    SalesOrderStatusPipe,
    WorkOrderTravellerComponent,
    OrderSettingsComponent,
    SchedulingSettingsComponent,
    SchedulingComponent,
    SchedulingReportsComponent,
    SchedulingGanttChartComponent,
    GanttChartNavigation,
    AfterValueChangedDirective,
    FormFillingComponent,
    HorizontalMenuComponent,
    ReceiveRawMaterialsComponent,
    AllocateRawMaterialsComponent,
    ShowSchedulingResultsComponent,
  ],
  imports: [
    JwtModule.forRoot({
      config: {
        tokenGetter: () => localStorage.getItem('access_token'),
        allowedDomains: [environment.API_ROOT],
        disallowedRoutes: [environment.SSO_ENDPOINT],
      },
    }),
    BrowserModule,
    HttpClientModule,
    LabelModule,
    DateInputsModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    ButtonsModule,
    BrowserAnimationsModule,
    ClickOutsideModule,
    NavigationModule,
    IconsModule,
    LayoutModule,
    DropDownsModule,
    NotificationModule,
    GridModule,
    PDFModule,
    ExcelModule,
    ChartsModule,
    MenuModule,
    IndicatorsModule,
    LabelModule,
    InputsModule,
    GaugesModule,
    WindowModule,
    DialogModule,
    UploadModule,
    KeycloakAngularModule,
    TreeViewModule,
    TooltipsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
    BlockUIModule.forRoot({
      template: CustomUiBlockerComponent,
    }), // Import BlockUIModule
    BlockUIHttpModule.forRoot({
      // blockAllRequestsInProgress: false
    }),
    DateTimePickerModule,
    DatePickerModule,
    UploadModule,
    SortableModule,
    BarcodesModule,
    PDFExportModule,
    SchedulerModule,
  ],
  providers: [
    AssemblyResolve,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpInterceptorService,
      multi: true
    },
    // Mock KeyCloakService to override actual KeyCloakService during development
    MockedKeycloakService,
    {
      provide: KeycloakService,
      useClass: environment.production ? KeycloakService : MockedKeycloakService
    },
    {
      provide: APP_INITIALIZER,
      useFactory: initializeKeycloak,
      multi: true,
      deps: [KeycloakService],
    },
  ],
  exports: [ActionButtonsComponent],
  bootstrap: [AppComponent],
})
export class AppModule {}

// required for AOT compilation
export function HttpLoaderFactory(http: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(http, './assets/i18n/');
}
