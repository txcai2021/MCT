import { faker } from '@faker-js/faker';

// https://blog.autify.com/why-id-should-not-be-used
// https://example.cypress.io/commands/querying

function login(){
  cy.visit('/');
  cy.get('#username').should('be.visible').type('admin');
  cy.get('#password').should('be.visible').type('admin');
  cy.get('#kc-login').should('be.visible').click();
}

describe('Users', () => {

  let username, email, password, phone, comments;

  beforeEach(()=>{

    cy.intercept('GET', '/api/user', (req) => {
      delete req.headers['if-none-match'];
    }).as('waitforget');

    login();
  })

  it("Should Add Users Successfully", ()=>{

    cy.visit('/#/user');

    cy.contains('Add New').click();

    username = faker.name.findName();
    email = faker.internet.email().toLowerCase();
    password = faker.internet.password(10);
    phone = faker.phone.phoneNumber('####-####');
    comments = faker.lorem.words();

    cy.intercept('POST', '/api/user', (req) => {
      req.continue();
    }).as('createuser');

    cy.get('[formcontrolname="username"]').type(username);
    cy.get('[formcontrolname="firstName"]').type(username);
    cy.get('[formcontrolname="email"]').type(email);

    cy.get('[formcontrolname="password"]').type(password);
    cy.get('[formcontrolname="confirmPassword"]').type(password);

    cy.get('[formcontrolname="roleID"]').get('[class="k-select"]').click();
    cy.get('[kendodropdownsselectable]').contains('ADMINISTRATOR').click();

    cy.get('[formcontrolname="mobile"]').type(phone);
    cy.get('[formcontrolname="comment"]').type(comments);

    cy.contains('Submit').click();

    cy.wait('@createuser').should(interception => {
      expect(interception.response?.statusCode).to.be.oneOf([200, 201]);
    });

  });

  it('Should Edit User', ()=>{    

    cy.visit('/#/user');

    cy
    .get('[kendogridtablebody]')
    .contains(username)
    .parent()
    .find('[kendogrideditcommand]')
    .click();

    phone = faker.phone.phoneNumber('####-####');
    comments = faker.lorem.words();

    cy.intercept('PUT', '/api/user', (req) => {
      req.continue();
    }).as('edituser');

    cy.get('[formcontrolname="roleID"]').get('[class="k-select"]').click();
    cy.get('[kendodropdownsselectable]').contains('ADMINISTRATOR').click();

    cy.get('[formcontrolname="mobile"]').clear().type(phone);
    cy.get('[formcontrolname="comment"]').clear().type(comments);

    cy.contains('Submit').click();

    cy.wait('@edituser');

    cy.reload(true);

    cy.wait('@waitforget');

    let assert_phone = cy
      .contains(username)
      .parent()
      .contains(phone.replace('-', ''));

    let assert_comments = cy
      .contains(username)
      .parent()
      .contains(comments);

    expect(assert_phone).to.not.be.null;
    expect(assert_comments).to.not.be.null;

  });

  it('Should DELETE User on Click', ()=>{

    cy.visit('/#/user');

    cy.intercept('DELETE', '/api/user/*').as('deleteuser');

    cy.wait('@waitforget');

    cy
    .contains(username)
    .parent()
    .find('[kendogridremovecommand]')
    .click();

    cy
    .get('kendo-dialog-actions')
    .get('[aria-label="Yes"]')
    .click();

    cy.wait('@deleteuser');

    cy.reload(true);

    cy.wait('@waitforget');

    cy.contains(username).should('not.exist');

  });

})
